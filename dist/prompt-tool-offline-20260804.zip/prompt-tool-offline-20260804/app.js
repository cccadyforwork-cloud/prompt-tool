const sourceNotes = {
  purchase: "采购单口径：确认已采购的产品款式；不把下单数量当作产品参数。",
  amazonTemplate: "Amazon listing 主口径：优先提取标题、五点、描述、类目、Child SKU 与变体字段。",
  alibaba: "1688 补充口径：仅补 Amazon listing 未填写的材质、结构、适配、场景、尺寸和卖点。",
  amazon: "参考链接口径：提取图组结构、构图任务与卖点分配，不补写未确认参数。",
};

const productGroups = {
  v02: {
    name: "V02 V形滤纸",
    promptName: "V02 cone coffee filter",
    purchaseVariants: "V02 100片/盒、V02 200片/盒",
    productCountNote: "采购单计 2 个 SKU；基础产品计 1 款",
    alibabaPack: "V02，100片/盒，约 138g/盒，外盒约 130 x 200 x 17 mm，1-4人份",
    specs: ["V02", "1-4人份", "100片/盒 / 200片/盒", "自然棕色原色木浆纸", "侧边压纹与底部折边"],
    promptSpecs: ["V02", "1-4 cups", "100 pcs box / 200 pcs box", "natural unbleached wood pulp paper", "pressed side seam and bottom fold"],
    dimensions: ["Top Width: 16 cm", "Side Length: 12 cm / 11.6 cm", "Weight: 1.12 g/sheet"],
    evidenceNote: "只使用 1688 图中可见规格；100/200 仅作为包装数量。",
  },
  u02: {
    name: "扇形02 / U02 滤纸",
    promptName: "fan-shaped 02 / U02 coffee filter",
    purchaseVariants: "扇形02 100片/盒、扇形U02 200片/盒",
    productCountNote: "采购单计 2 个 SKU；基础产品计 1 款",
    alibabaPack: "#02 / U102，100片/盒，约 142g/盒，外盒约 170 x 200 x 17 mm，2-6人份",
    specs: ["#02 / U102", "2-6人份", "100片/盒 / 200片/盒", "自然棕色原色木浆纸", "侧边压纹与底部折边"],
    promptSpecs: ["#02 / U102", "2-6 cups", "100 pcs box / 200 pcs box", "natural unbleached wood pulp paper", "pressed side seam and bottom fold"],
    dimensions: ["Top Width: 16.5 cm", "Side Length: 9 cm / 9.5 cm", "Bottom Width: 5 cm", "Weight: 1.15 g/sheet"],
    evidenceNote: "采购单中的“扇形02”和“扇形U02”按同一基础规格处理，包装数量分开。",
  },
  u04: {
    name: "扇形04 滤纸",
    promptName: "fan-shaped 04 coffee filter",
    purchaseVariants: "扇形04 100片/盒、扇形04 200片/盒",
    productCountNote: "采购单计 2 个 SKU；基础产品计 1 款",
    alibabaPack: "#04，100片/盒，约 185g/盒，外盒约 230 x 200 x 17 mm，8-12 cups",
    specs: ["#04", "8-12 cups", "100片/盒 / 200片/盒", "自然棕色原色木浆纸", "侧边压纹与底部折边"],
    promptSpecs: ["#04", "8-12 cups", "100 pcs box / 200 pcs box", "natural unbleached wood pulp paper", "pressed side seam and bottom fold"],
    dimensions: [],
    evidenceNote: "资料未明确单片尺寸，不借鉴、不补写；只展示已提取到的规格与包装信息。",
  },
};

const verifiedDimensions = {
  v02: {
    topWidth: "16 cm",
    sideLength: "12 cm / 11.6 cm",
    bottomWidth: "",
    weight: "1.12 g/sheet",
    cupRange: "1-4 cup pour-over brewing",
    source: "1688 详情图可见单片规格",
  },
  u02: {
    topWidth: "16.5 cm",
    sideLength: "9 cm / 9.5 cm",
    bottomWidth: "5 cm",
    weight: "1.15 g/sheet",
    cupRange: "2-6 cup drip or pour-over brewing",
    source: "1688 详情图可见单片规格",
  },
  u04: {
    topWidth: "",
    sideLength: "",
    bottomWidth: "",
    weight: "",
    cupRange: "8-12 cup drip coffee maker",
    source: "资料未明确单片尺寸",
  },
};

const skus = [
  {
    id: "KFLZ-SV02-200",
    label: "KFLZ-SV02-200 | V02 盒装 200 片",
    sourceName: "亚马逊定制V形02盒装200片",
    shape: "V-shaped cone coffee filter, size 02",
    pack: "200 pcs box",
    sizeCode: "V02",
    groupKey: "v02",
    dims: verifiedDimensions.v02,
    fit: "V60-02 style cone dripper and 1-4 cup pour-over brewer",
  },
  {
    id: "KFLZ-SU02-200",
    label: "KFLZ-SU02-200 | 扇形 U02 盒装 200 片",
    sourceName: "亚马逊定制扇形U02盒装200片",
    shape: "fan-shaped trapezoid coffee filter, size 02",
    pack: "200 pcs box",
    sizeCode: "U02 / 02",
    groupKey: "u02",
    dims: verifiedDimensions.u02,
    fit: "#2 fan-shaped dripper, trapezoid filter cup, small drip coffee maker",
  },
  {
    id: "KFLZ-SV02-100",
    label: "KFLZ-SV02-100 | V02 盒装 100 片",
    sourceName: "亚马逊定制V02盒装100片",
    shape: "V-shaped cone coffee filter, size 02",
    pack: "100 pcs box",
    sizeCode: "V02",
    groupKey: "v02",
    dims: verifiedDimensions.v02,
    fit: "V60-02 style cone dripper and 1-4 cup pour-over brewer",
  },
  {
    id: "KFLZ-SU04-100",
    label: "KFLZ-SU04-100 | 扇形 04 盒装 100 片",
    sourceName: "亚马逊定制扇形04盒装100片",
    shape: "fan-shaped trapezoid coffee filter, size 04",
    pack: "100 pcs box",
    sizeCode: "#4 / 04",
    groupKey: "u04",
    dims: verifiedDimensions.u04,
    fit: "#4 cone or fan-shaped drip coffee maker, 8-12 cup brewer",
  },
  {
    id: "KFLZ-SU04-200",
    label: "KFLZ-SU04-200 | 扇形 04 盒装 200 片",
    sourceName: "亚马逊定制扇形04盒装200片",
    shape: "fan-shaped trapezoid coffee filter, size 04",
    pack: "200 pcs box",
    sizeCode: "#4 / 04",
    groupKey: "u04",
    dims: verifiedDimensions.u04,
    fit: "#4 cone or fan-shaped drip coffee maker, 8-12 cup brewer",
  },
  {
    id: "KFLZ-SU02-100",
    label: "KFLZ-SU02-100 | 扇形 02 盒装 100 片",
    sourceName: "亚马逊定制扇形02盒装100片",
    shape: "fan-shaped trapezoid coffee filter, size 02",
    pack: "100 pcs box",
    sizeCode: "#2 / 02",
    groupKey: "u02",
    dims: verifiedDimensions.u02,
    fit: "#2 fan-shaped dripper, trapezoid filter cup, small drip coffee maker",
  },
];

const imageTypes = [
  { id: "1", name: "1. 单款参数 + 场景主图", promptName: "1. Single Specification Hero Image" },
  { id: "2", name: "2. 生活场景图 1", promptName: "2. Lifestyle Image" },
  { id: "3A", name: "3A. 多场景使用图", promptName: "3A. Multi-Scene Usage Image" },
  { id: "3B", name: "3B. 产品使用方法场景图", promptName: "3B. Step-by-Step Usage Image" },
  { id: "4", name: "4. 适用尺寸参数图", promptName: "4. Size Reference Image" },
  { id: "5", name: "5. 多规格可选图", promptName: "5. Multiple Specification Options Image" },
  { id: "6", name: "6. 功能 / 卖点图", promptName: "6. Feature Image" },
  { id: "7", name: "7. 细节放大图", promptName: "7. Close-Up Detail Image" },
  { id: "8", name: "8. 总卖点图", promptName: "8. Summary Infographic" },
];

const templates = [
  {
    id: "spec",
    name: "参数规格模板",
    description: "围绕规格、产品自身数量/套装、适配、范围和已确认尺寸生成 8 张图。",
    imageTypes,
  },
  {
    id: "feature",
    name: "功能展示模板",
    description: "按产品信息字段展示白底、场景、用途、外观、选项、核心功能和卖点总结，生成 8 张图。",
    imageTypes: [
      { id: "1", name: "1. 产品白底主图", promptName: "1. White Background Product Hero" },
      { id: "2", name: "2. 核心使用场景图", promptName: "2. Core Usage Scene Image" },
      { id: "3", name: "3. 多用途 / 多场景展示", promptName: "3. Multi-Use Scenario Image" },
      { id: "4", name: "4. 产品信息展示图", promptName: "4. Product Information Display Image" },
      { id: "5", name: "5. 规格 / 选项展示图", promptName: "5. Specification and Option Image" },
      { id: "6", name: "6. 核心功能展示图", promptName: "6. Core Function Demonstration Image" },
      { id: "7", name: "7. 细节 / 材质卖点图", promptName: "7. Detail and Material Feature Image" },
      { id: "8", name: "8. 功能卖点总结图", promptName: "8. Feature Summary Image" },
    ],
  },
  {
    id: "scene",
    name: "场景展示模板",
    description: "围绕 A/B 主场景、多场景、多角度展示、产品说明、两个卖点和收口生成 8 张图。",
    imageTypes: [
      { id: "1A", name: "1A. 主图 / 产品主体场景图", promptName: "1A. Product-First Main Scene Image" },
      { id: "1B", name: "1B. 主图 / 人物使用场景图", promptName: "1B. Human-Use Main Scene Image" },
      { id: "2", name: "2. 多场景 / 多用途图", promptName: "2. Multi-Scene Usage Image" },
      { id: "3", name: "3. 多角度图", promptName: "3. Multi-Angle Product Image" },
      { id: "4", name: "4. 产品说明图", promptName: "4. Product Explanation Image" },
      { id: "5", name: "5. 卖点图 5", promptName: "5. Selling Point Image 5" },
      { id: "6", name: "6. 卖点图 6", promptName: "6. Selling Point Image 6" },
      { id: "7", name: "7. 卖点总览图", promptName: "7. Feature Summary Image" },
    ],
  },
  {
    id: "plantTie",
    name: "植物绑带模型",
    description: "植物绑带产品专用 5 张图：主场景、白底、多场景、卖点、尺寸材质产品信息详情。",
    imageTypes: [
      { id: "1", name: "1. 主图场景图", promptName: "1. Main Scene Image" },
      { id: "2", name: "2. 白底图", promptName: "2. White Background Product Image" },
      { id: "3", name: "3. 多场景使用图", promptName: "3. Multi-Scene Usage Image" },
      { id: "4", name: "4. 卖点图", promptName: "4. Selling Point Image" },
      { id: "5", name: "5. 尺寸材质产品信息详情图", promptName: "5. Product Detail Information Image" },
    ],
  },
  {
    id: "reference",
    name: "参考链接模板",
    description: "参考链接静态图组的图片顺序、构图任务和卖点分配，代入当前产品信息生成 6 张图。",
    imageTypes: [
      { id: "1", name: "1. 参考图 1 / 主图路线", promptName: "1. Reference Blueprint Image 1" },
      { id: "2", name: "2. 参考图 2 / 结构路线", promptName: "2. Reference Blueprint Image 2" },
      { id: "3", name: "3. 参考图 3 / 细节路线", promptName: "3. Reference Blueprint Image 3" },
      { id: "4", name: "4. 参考图 4 / 功能路线", promptName: "4. Reference Blueprint Image 4" },
      { id: "5", name: "5. 参考图 5 / 场景路线", promptName: "5. Reference Blueprint Image 5" },
      { id: "6", name: "6. 参考图 6 / 收口路线", promptName: "6. Reference Blueprint Image 6" },
    ],
  },
];

const fields = [
  ["productName", "Product Name", "[PRODUCT_NAME]"],
  ["pack", "Product Count / Set", ""],
  ["cupRange", "Size / Range", ""],
  ["material", "Material", ""],
  ["color", "Color", ""],
  ["structure", "Structure / Craft", ""],
  ["surfaceFinish", "Technology / Finish", ""],
  ["detailParameter", "Detail Features", ""],
  ["topWidth", "Dimension 1", ""],
  ["sideLength", "Dimension 2", ""],
  ["bottomWidth", "Dimension 3", ""],
  ["weight", "Weight / Quantity", ""],
  ["scene", "Use Scene", ""],
  ["feature1", "Selling Point 1", ""],
  ["feature2", "Selling Point 2", ""],
];

const multilineFieldKeys = new Set(["feature1", "feature2"]);
const sellingPointFieldKeys = new Set(["feature1", "feature2"]);

let promptStore = [];
let promptLanguageByCard = {};
let extractedProducts = [];
let hasUserSourceAttempt = false;
const emptyExtractedProduct = {
  id: "EXTRACTED-NONE",
  label: "请先解析资料",
  productName: "",
  shape: "",
  pack: "",
  sizeCode: "",
  groupKey: "",
  dims: {},
  fit: "",
};
let sourcePayload = {
  purchase: "",
  amazonTemplate: "",
  supplier: "",
  competitor: "",
};
let fieldOverrides = {};
let fieldOverridesBySku = {};
let appliedSellingPointOverridesBySku = {};
let fieldSnapshot = "";
let sellingPointDraftDirty = false;
const OCR_IMAGE_LIMIT = 32;
const OCR_FALLBACK_IMAGE_LIMIT = 6;
const OCR_SCRIPT_URL = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
const PDFJS_SCRIPT_URL = "./vendor/pdfjs/pdf.min.js";
const PDFJS_WORKER_URL = "./vendor/pdfjs/pdf.worker.min.js";
const XLSX_SCRIPT_URL = "./vendor/xlsx.full.min.js";
const DETAIL_FETCH_TIMEOUT_MS = 15000;
const IMAGE_LOAD_TIMEOUT_MS = 15000;
const OCR_RECOGNIZE_TIMEOUT_MS = 45000;
const PURCHASE_IMAGE_OCR_TIMEOUT_MS = 45000;
const GENERIC_SUPPLIER_SKU_MODEL = "SUPPLIER-SKU";
const scriptLoadPromises = {};

function byId(id) {
  return document.getElementById(id);
}

function loadScriptOnce(src, globalName) {
  if (globalName && window[globalName]) return Promise.resolve(window[globalName]);
  if (scriptLoadPromises[src]) return scriptLoadPromises[src];

  scriptLoadPromises[src] = new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${src}"]`);
    if (existing) {
      existing.addEventListener("load", () => resolve(globalName ? window[globalName] : true));
      existing.addEventListener("error", () => reject(new Error(`Failed to load ${src}`)));
      return;
    }

    const script = document.createElement("script");
    script.src = src;
    script.async = true;
    script.onload = () => resolve(globalName ? window[globalName] : true);
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });

  return scriptLoadPromises[src];
}

async function loadPdfJs() {
  const existing = window.pdfjsLib || window["pdfjs-dist/build/pdf"];
  if (existing) return existing;
  await loadScriptOnce(PDFJS_SCRIPT_URL);
  return window.pdfjsLib || window["pdfjs-dist/build/pdf"];
}

async function loadXlsx() {
  return window.XLSX || await loadScriptOnce(XLSX_SCRIPT_URL, "XLSX");
}

function selectedSku() {
  const allProducts = currentProducts();
  return allProducts.find((sku) => sku.id === byId("skuSelect").value) || allProducts[0];
}

function currentProducts() {
  if (extractedProducts.length) {
    return extractedProducts;
  }
  return [emptyExtractedProduct];
}

function hasExtractedProducts() {
  return extractedProducts.length > 0;
}

function selectedTemplate() {
  const selected = templates.find((item) => item.id === byId("templateSelect").value) || templates[0];
  return selected.disabled ? templates[0] : selected;
}

function defaultProductName(sku) {
  return promptValue(sku.productName, "")
    || promptValue(sku.shape, "")
    || promptValue(sku.sourceName, "")
    || "[PRODUCT_NAME]";
}

function dimensionListForSku(sku, group = {}) {
  const existing = sku.dimensionList || ((group.dimensions || []).length ? `[VERIFIED_DIMENSIONS: ${group.dimensions.join("; ")}]` : "");
  if (existing) return existing;
  const fallbackText = [
    defaultProductName(sku),
    sku.shape,
    sku.specList,
    sku.singleSpec,
    sku.detailParameter,
    sku.structure,
    sku.fit,
    group.promptName,
    ...(group.promptSpecs || []),
    sourcePayload.supplier,
  ].filter(Boolean).join("\n");
  const dimensions = extractDimensions(fallbackText);
  return dimensions.length ? `[VERIFIED_DIMENSIONS: ${dimensions.join("; ")}]` : "";
}

function dimensionFieldsFromDimensionList(dimensionList, context = "") {
  const source = cleanTokenValue(dimensionList);
  if (!source) return {};
  const combined = [context, source].filter(Boolean).join(" ");
  const isUmbrella = /umbrella|伞|canopy|folded|open diameter|open height|rain|sun shade/i.test(combined);
  return {
    topWidth: dimensionValueByLabels(source, isUmbrella ? ["Folded Size", "Top Width", "Length", "Diameter"] : ["Top Width", "Length", "Folded Size", "Diameter"]),
    sideLength: dimensionValueByLabels(source, isUmbrella ? ["Open Diameter", "Side Length", "Width"] : ["Side Length", "Width", "Open Diameter"]),
    bottomWidth: dimensionValueByLabels(source, isUmbrella ? ["Open Height", "Bottom Width", "Height"] : ["Bottom Width", "Height", "Open Height"]),
    weight: dimensionValueByLabels(source, ["Weight", "Weight / Capacity", "Capacity", "Volume", "Quantity"]),
  }
}

function validSizeRangeValue(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean || /^(?:均码|one size|free size)$/i.test(clean)) return "";
  if (/(?:pcs|pieces?|片|pack|包|set|套|qty|quantity|数量)/i.test(clean)) return "";
  if (/(?:ml|mL|l\b|升|毫升|oz|g|kg|克|千克)/i.test(clean)) return "";
  if (/^(?:black|white|gray|grey|blue|green|purple|pink|red|yellow|orange|brown|khaki|silver)$/i.test(clean)) return "";
  return clean;
}

function looksLikeSizeRangeValue(value) {
  const clean = validSizeRangeValue(value);
  if (!clean) return false;
  return /(?:US\s*Size|尺码|鞋码|size|码|号|inch|in\b|cm|mm|厘米|毫米|cups?|人份|#?\d{1,3}|V\d{2}|U\d{2}|[0-9]+\s*-\s*[0-9]+|\b(?:XXL|XL|XS|S|M|L)\b)/i.test(clean);
}

function extractSizeRangeFromOptionText(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return "";
  const parts = clean
    .split(/\s*(?:\/|\||;|,|，)\s*/)
    .map((part) => validSizeRangeValue(part))
    .filter(Boolean);
  return parts.find((part) => looksLikeSizeRangeValue(part)) || (looksLikeSizeRangeValue(clean) ? clean : "");
}

function sizeRangeValueForSku(sku = {}, values = {}) {
  const direct = validSizeRangeValue(sku.dims?.cupRange || sku.cupRange || values.cupRange || sku.size || "");
  if (direct) return direct;
  return extractSizeRangeFromOptionText(sku.outputSizeCode || sku.sizeCode || "")
    || extractFirstMatch(values.specList || "", [/([0-9]+\s*-\s*[0-9]+\s*(?:cups|cup|人份))/i]);
}

function weightOrCapacityValueForSku(sku = {}, values = {}, dimensionFields = {}) {
  return cleanFieldDisplayValue(
    sku.dims?.weight
    || values.weight
    || dimensionFields.weight
    || sku.capacity
    || values.capacity
    || ""
  );
}

function isFootwearSceneLeakText(value) {
  const source = String(value || "").toLowerCase();
  if (!source) return false;
  if (/slipper|flip\s*-?\s*flops?|sandal|footwear|shoe|shoes|拖鞋|凉拖|一字拖|人字拖|沙滩鞋/.test(source)) return true;
  return /beach,\s*hotel,\s*spa,\s*shower,\s*travel,\s*bathroom/.test(source);
}

function categorySceneFieldText(profile) {
  return cleanFieldDisplayValue(String(profile?.scene || "")
    .replace(/^Scene category:\s*/i, "")
    .replace(/\s*;\s*/g, ", "));
}

function identityFactsFromData(data = {}) {
  return {
    productName: data.productName || defaultProductName(data),
    titleSpec: data.titleSpec,
    selectedSpec: data.selectedSpec || data.singleSpec || data.sizeCode || data.shape,
    cupType: data.cupType,
    material: data.material,
    structure: data.structure,
    variants: data.variantList,
    detailParameter: data.detailParameter,
    bundleComponents: data.bundleComponents,
  };
}

function sanitizeUseContextFields(data = {}) {
  const profile = categoryProfile(identityFactsFromData(data));
  const isFootwear = profile.id === "footwear";
  const fit = cleanFieldDisplayValue(data.fit || "");
  const scene = cleanFieldDisplayValue(data.scene || "");
  return {
    fit: !isFootwear && isFootwearSceneLeakText(fit) ? "" : fit,
    scene: !isFootwear && isFootwearSceneLeakText(scene) ? "" : scene,
  };
}

function categoryIdFromSourceText(text) {
  const profile = categoryProfile({
    productName: text,
    detailParameter: text,
  });
  return profile.id || "generic";
}

function categoryIdFromProduct(product) {
  return categoryProfile(identityFactsFromData(product)).id || "generic";
}

function sourceCategoriesConflict(primaryCategoryId, secondaryCategoryId) {
  if (!primaryCategoryId || !secondaryCategoryId) return false;
  if (primaryCategoryId === "generic" || secondaryCategoryId === "generic") return false;
  return primaryCategoryId !== secondaryCategoryId;
}

function valueMap(sku) {
  const isExtractedSku = String(sku.id || "").startsWith("EXTRACTED-");
  const group = productGroups[sku.groupKey] || sku.group || (isExtractedSku ? {} : productGroups.v02);
  const materialFallback = isExtractedSku ? "" : "[MATERIAL: natural wood pulp paper / unbleached brown paper]";
  const colorFallback = isExtractedSku ? "" : "[COLOR: natural brown]";
  const structureFallback = isExtractedSku ? "" : "[STRUCTURE: pressed side seam and bottom fold]";
  const feature1Fallback = isExtractedSku ? "" : "[SELLING_POINT_1: natural unbleached wood pulp paper]";
  const feature2Fallback = isExtractedSku ? "" : "[SELLING_POINT_2: reinforced smooth filtration]";
  const variantFallback = isExtractedSku ? "" : "[VARIANT_LIST: V02 100/200 pcs, fan-shaped 02 or U02 100/200 pcs, fan-shaped 04 100/200 pcs]";
  const dimensionList = dimensionListForSku(sku, group);
  const dimensionFields = dimensionFieldsFromDimensionList(dimensionList, [
    defaultProductName(sku),
    sku.shape,
    sku.fit,
    sku.structure,
    sku.detailParameter,
  ].filter(Boolean).join(" "));
  const useContext = sanitizeUseContextFields(sku);
  return {
    productName: cleanFieldDisplayValue(defaultProductName(sku)),
    pack: cleanFieldDisplayValue(sku.pack || ""),
    material: cleanFieldDisplayValue(sku.material || materialFallback),
    color: cleanFieldDisplayValue(sku.color || colorFallback),
    structure: cleanFieldDisplayValue(sku.structure || structureFallback),
    cupRange: cleanFieldDisplayValue(sizeRangeValueForSku(sku, {})),
    topWidth: sku.dims?.topWidth || dimensionFields.topWidth || "",
    sideLength: sku.dims?.sideLength || dimensionFields.sideLength || "",
    bottomWidth: sku.dims?.bottomWidth || dimensionFields.bottomWidth || "",
    weight: weightOrCapacityValueForSku(sku, {}, dimensionFields),
    fit: useContext.fit,
    scene: useContext.scene,
    feature1: cleanFieldDisplayValue(sku.feature1 || feature1Fallback),
    feature2: cleanFieldDisplayValue(sku.feature2 || feature2Fallback),
    surfaceFinish: cleanFieldDisplayValue(sku.surfaceFinish || ""),
    detailParameter: cleanFieldDisplayValue(sku.detailParameter || ""),
    bundleComponents: cleanFieldDisplayValue(sku.bundleComponents || ""),
    packagingCount: ensureParameterToken("PRODUCT_COUNT_OR_SET", sku.pack || ""),
    singleSpec: sku.singleSpec || `[CURRENT_PRODUCT_OPTION: ${group.promptName || "[PRODUCT_SPEC]"}, ${sku.pack || "[PRODUCT_COUNT_OR_SET]"}]`,
    specList: sku.specList || `[SPEC_LIST: ${(group.promptSpecs || ["[SPECIFICATION_LIST]"]).join(" / ")}]`,
    variantList: sku.variantList || variantFallback,
    dimensionList,
  };
}

function fillSelects() {
  renderProductSelect();
  byId("templateSelect").innerHTML = templates
    .filter((template) => !template.disabled)
    .map((template) => `<option value="${template.id}">${template.name}</option>`)
    .join("");
}

function renderProductSelect(selectedId = byId("skuSelect")?.value) {
  const products = currentProducts();
  byId("skuSelect").innerHTML = products.map((sku) => `<option value="${sku.id}">${escapeHtml(skuDisplayLabel(sku))}</option>`).join("");
  if (selectedId && products.some((sku) => sku.id === selectedId)) {
    byId("skuSelect").value = selectedId;
  }
}

function renderFields(reset = false) {
  const sku = selectedSku();
  const values = valueMap(sku);
  const fieldList = byId("fieldList");
  if (reset) {
    fieldOverrides = { ...(fieldOverridesBySku[sku?.id] || {}) };
    sellingPointDraftDirty = false;
  }
  ensureAppliedSellingPointValues(sku);
  if (!hasExtractedProducts()) {
    fieldList.innerHTML = `<p class="empty-state">解析资料后显示可替换参数。</p>`;
    return;
  }
  const fieldControls = fields.map(([key, label, fallback]) => {
    const currentValue = byId(`field-${key}`)?.value ?? fieldOverrides[key] ?? "";
    const value = reset
      ? (values[key] || fallback)
      : (cleanFieldDisplayValue(currentValue) || values[key] || fallback);
    const cleanValue = ["fit", "scene"].includes(key)
      ? sanitizeUseContextFields({ ...values, [key]: cleanFieldDisplayValue(value) })[key]
      : cleanFieldDisplayValue(value);
    const displayValue = multilineFieldKeys.has(key)
      ? formatMultilineSellingPoints(cleanValue)
      : cleanValue;
    const fieldControl = multilineFieldKeys.has(key)
      ? `<textarea id="field-${key}" class="selling-point-input" data-key="${key}" rows="4">${escapeHtml(displayValue)}</textarea>`
      : `<input id="field-${key}" data-key="${key}" value="${escapeHtml(displayValue)}">`;
    return `
      <div>
        <label for="field-${key}">${label}</label>
        ${fieldControl}
      </div>
    `;
  }).join("");
  fieldList.innerHTML = `${fieldControls}
    <div id="sellingPointApplyWrap" class="selling-point-apply-wrap${sellingPointDraftDirty ? "" : " is-hidden"}">
      <button id="applySellingPoints" type="button" class="ghost selling-point-apply">确认生成卖点图提示词</button>
      <p class="selling-point-apply-note">卖点已修改，点击后更新右侧卖点图场景和提示词。</p>
    </div>
  `;
  fieldList.querySelectorAll("input, textarea").forEach((input) => {
    ["input", "change"].forEach((eventName) => input.addEventListener(eventName, handleFieldInput));
  });
  byId("applySellingPoints")?.addEventListener("click", applySellingPointChanges);
  updateSellingPointApplyState();
}

function formatMultilineSellingPoints(value) {
  return splitSellingPointText(value).join("\n");
}

function splitSellingPointText(value) {
  return String(value || "")
    .replace(/\r\n?/g, "\n")
    .split(/\n+|[;；]\s*|\s+\+\s+|\s+\/\s+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function cleanTokenValue(value) {
  return String(value || "")
    .replace(/^\[[A-Z0-9_ ]+:?\s*/i, "")
    .replace(/\]$/g, "")
    .trim();
}

function cleanFieldDisplayValue(value) {
  const raw = String(value || "").trim();
  if (/^\[[A-Z0-9_ ]+\]$/i.test(raw)) return "";
  const clean = cleanTokenValue(raw);
  return isCodeLikeValue(clean) || isInvalidParameterValue(clean) ? "" : clean;
}

function isCodeLikeValue(value) {
  return /<\s*\/?\s*(?:script|style|html|body)|\b(?:body|html)\s*\{|display\s*:|window\.|traceId|polyfill|RegeneratorRuntime|<\/script|src\s*=|PRODUCT_ATTRIBUTE|SKU_OPTION|PRODUCT_TITLE|Source HTML file|Purchase order image OCR|model\s*=|colorEnglish\s*=|[{}]{2,}/i.test(String(value || ""));
}

function isMachineProductText(value) {
  const clean = String(value || "").trim();
  if (!clean) return true;
  if (/^(?:temu|tmall|taobao|1688|alibaba|amazon|source html file)$/i.test(clean)) return true;
  return /SKU_OPTION|PRODUCT_ATTRIBUTE|PRODUCT_TITLE|SUPPLIER-SKU|model\s*=|colorEnglish\s*=|rawSpec\s*=|variantStyle\s*=|traceId|window\.|<\/?[a-z]/i.test(clean);
}

function readableNameFromRawSpec(value) {
  const raw = String(value || "").match(/rawSpec\s*=\s*([^;\n|]+)/i)?.[1] || String(value || "");
  const clean = decodeHtmlEntities(raw)
    .replace(/SKU_OPTION\s*[:;]+/gi, " ")
    .replace(/\bmodel\s*=\s*[^;\n|]+/gi, " ")
    .replace(/\bcolor(?:English)?\s*=\s*[^;\n|]+/gi, " ")
    .replace(/\bvariantStyle\s*=\s*[^;\n|]+/gi, " ")
    .replace(/\bsize\s*=\s*[^;\n|]+/gi, " ")
    .replace(/不送工具|不含工具|送工具|白色|黑色|透明色|透明|颜色\s*[:：]?/gi, " ")
    .replace(/[;|]+/g, " ")
    .replace(/\s*-\s*/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean || isMachineProductText(clean)) return "";
  const match = clean.match(/([\u4e00-\u9fff]{2,}(?:\s*[0-9]+(?:\.[0-9]+)?\s*(?:ml|mL|g|kg|cm|mm|L|升|克|毫升))?)/);
  return (match?.[1] || clean).replace(/\s+/g, " ").trim();
}

function cleanProductDisplayName(value, fallback = "Product") {
  const rawSpecName = readableNameFromRawSpec(value);
  const source = rawSpecName || stripSupplierModelCodes(cleanFieldDisplayValue(value));
  if (!source || isMachineProductText(source)) return fallback;
  return source.length > 60 ? source.slice(0, 60).trim() : source;
}

function isInvalidParameterValue(value) {
  const clean = String(value || "").trim();
  if (!clean) return true;
  if (!/[0-9A-Za-z\u4e00-\u9fff]/.test(clean)) return true;
  if (/^\.\s*g$/i.test(clean)) return true;
  return false;
}

function ensureParameterToken(name, value) {
  const raw = String(value || "").trim();
  const clean = cleanTokenValue(raw);
  if (!clean || /^\[[A-Z0-9_ ]+\]$/i.test(raw)) return `[${name}]`;
  return `[${name}: ${clean}]`;
}

function hasTokenContent(value) {
  return /^\[[A-Z0-9_ ]+:\s*[^\]]+\]$/i.test(String(value || "").trim());
}

function productParameterRows() {
  const groups = new Map();
  const selectedId = selectedSku()?.id;
  currentProducts().forEach((sku) => {
    const isSelected = sku.id === selectedId;
    const values = sku.id === selectedId ? { ...valueMap(sku), ...currentFields() } : valueMap(sku);
    const groupKey = sku.groupKey || sku.sizeCode || sku.shape || sku.id;
    const existing = groups.get(groupKey) || {
      title: sku.sizeCode || sku.shape || "Product Specification",
      productName: cleanFieldDisplayValue(values.productName || defaultProductName(sku)),
      shape: sku.shape || cleanTokenValue(values.singleSpec),
      cupRange: "",
      material: cleanTokenValue(values.material),
      structure: cleanTokenValue(values.structure),
      surfaceFinish: cleanTokenValue(values.surfaceFinish),
      detailParameter: cleanTokenValue(values.detailParameter),
      topWidth: sku.dims?.topWidth || values.topWidth || "",
      sideLength: sku.dims?.sideLength || values.sideLength || "",
      bottomWidth: sku.dims?.bottomWidth || values.bottomWidth || "",
      weight: sku.dims?.weight || values.weight || "",
    };

    if (isSelected || !existing.cupRange) {
      existing.cupRange = validSizeRangeValue(sizeRangeValueForSku(sku, values));
    }
    if (isSelected || !existing.material) existing.material = cleanTokenValue(values.material);
    if (isSelected || !existing.structure) existing.structure = cleanTokenValue(values.structure);
    if (isSelected || !existing.surfaceFinish) existing.surfaceFinish = cleanTokenValue(values.surfaceFinish);
    if (isSelected || !existing.detailParameter) existing.detailParameter = cleanTokenValue(values.detailParameter);
    if (isSelected || !existing.productName) existing.productName = cleanFieldDisplayValue(values.productName || defaultProductName(sku));
    if (isSelected || !existing.topWidth) existing.topWidth = values.topWidth || sku.dims?.topWidth || "";
    if (isSelected || !existing.sideLength) existing.sideLength = values.sideLength || sku.dims?.sideLength || "";
    if (isSelected || !existing.bottomWidth) existing.bottomWidth = values.bottomWidth || sku.dims?.bottomWidth || "";
    if (isSelected || !existing.weight) existing.weight = values.weight || sku.dims?.weight || "";
    groups.set(groupKey, existing);
  });

  return Array.from(groups.values());
}

function validRangeValue(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return "";
  if (isCodeLikeValue(clean)) return "";
  return clean;
}

function renderProductParameters() {
  const list = byId("productParamList");
  if (!list) return;

  const rows = productParameterRows();
  if (!hasExtractedProducts()) {
    list.innerHTML = `<p class="empty-state">解析采购单和 1688 资料后显示产品主参数。</p>`;
    return;
  }
  list.innerHTML = rows.map((row) => {
    const params = [
      ["Product / Option", row.productName || row.title],
      ["Size / Range", row.cupRange],
      ["Use Scene", row.scene],
      ["Material", row.material],
      ["Structure / Craft", row.structure],
      ["Technology", row.surfaceFinish],
      ["Detail Features", row.detailParameter],
      ["Length / Size 1", row.topWidth],
      ["Width / Size 2", row.sideLength],
      ["Height / Size 3", row.bottomWidth],
      ["Weight / Quantity", row.weight],
    ].filter(([, value]) => value && !/^\[[A-Z0-9_ ]+\]$/i.test(value));

    return `
      <article class="product-param-card">
        <h3>${escapeHtml(row.shape || row.title)}</h3>
        <dl>
          ${params.map(([label, value]) => `
            <div>
              <dt>${escapeHtml(label)}</dt>
              <dd>${escapeHtml(value)}</dd>
            </div>
          `).join("")}
        </dl>
      </article>
    `;
  }).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[char]));
}

function highlightPromptVariables(text, facts, typeId = "") {
  const escapedText = escapeHtml(text);
  const sectionPattern = "PRIORITY|VISUAL|TEXT|AVOID|优先级|视觉画面|文字规则|避免事项";
  const subsectionPattern = "PRODUCT FACTS|SCENE &amp; COMPOSITION|SCENE DIRECTION|COMPOSITION \\/ LAYOUT|TEXT \\/ CALLOUTS|ACCURACY GUARDRAILS|OTHER STYLE|产品事实|场景构图|场景方向|构图布局|文字标注|准确性约束|其他风格";
  return escapedText
    .replace(new RegExp(`^(${sectionPattern}):$`, "gm"), '<span class="prompt-section-title">$1</span>')
    .replace(new RegExp(`^(${subsectionPattern}):(.*)$`, "gm"), (_, label, body) => (
      `<span class="prompt-subsection-line"><span class="prompt-subsection-title">${label}</span><span class="prompt-subsection-body">${body.trim()}</span></span>`
    ))
    .replace(/(【[^】\n]{3,600}】)/g, '<span class="variable-token">$1</span>');
}

function promptVariableValues(facts) {
  return uniquePromptItems([
    facts.productName,
    facts.cupType,
    facts.selectedSpec,
    facts.skuOption,
    facts.titleSpec,
    facts.pack,
    facts.cupRange,
    facts.material,
    facts.color,
    facts.scene,
    facts.feature1,
    facts.feature2,
    facts.feature3,
    facts.bundleComponents,
    facts.variants,
    facts.specs,
    facts.dimensions,
    facts.dimension1,
    facts.dimension2,
    facts.dimension3,
    facts.weightOrCapacity,
    facts.structure,
    facts.surfaceFinish,
    facts.detailParameter,
    ...splitSellingPointText(facts.feature1),
    ...splitSellingPointText(facts.feature2),
  ].map((value) => cleanTokenValue(value)).filter(Boolean));
}

function bracketValue(value) {
  const clean = String(value || "").trim();
  return clean ? `【${clean}】` : "";
}

function bracketPromptVariables(text, facts, typeId = "") {
  const values = promptVariableValues(facts)
    .filter(Boolean)
    .map((value) => String(value).trim())
    .filter((value) => value.length >= 3 && !isGenericPromptFallback(value))
    .sort((a, b) => b.length - a.length);
  const seen = new Set();
  const uniqueValues = values.filter((value) => {
    const key = comparablePromptItem(value);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
  if (!uniqueValues.length) return text;
  const pattern = new RegExp(uniqueValues
    .map((value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join("|"), "g");

  return String(text || "")
    .split(/(【[^】]+】)/g)
    .map((segment) => {
      if (/^【[^】]+】$/.test(segment)) return segment;
      return segment.replace(pattern, (match) => bracketValue(match));
    })
    .join("");
}

function readFieldValue(key) {
  const input = byId(`field-${key}`);
  const skuId = selectedSku()?.id || "";
  const scopedOverrides = fieldOverridesBySku[skuId] || fieldOverrides;
  return cleanFieldDisplayValue(input ? input.value : scopedOverrides[key] ?? "");
}

function captureFieldOverrides() {
  const skuId = selectedSku()?.id || "";
  const nextOverrides = { ...(fieldOverridesBySku[skuId] || {}) };
  fields.forEach(([key]) => {
    const input = byId(`field-${key}`);
    if (input) nextOverrides[key] = cleanFieldDisplayValue(input.value);
  });
  if (skuId) fieldOverridesBySku[skuId] = nextOverrides;
  fieldOverrides = nextOverrides;
}

function currentFields() {
  captureFieldOverrides();
  const sku = selectedSku();
  const values = valueMap(sku);
  const data = {};
  fields.forEach(([key]) => {
    const value = fieldOverrides[key] ?? readFieldValue(key);
    data[key] = cleanFieldDisplayValue(value) || values[key] || "";
  });
  const sanitizedUseContext = sanitizeUseContextFields(data);
  data.fit = "";
  data.scene = sanitizedUseContext.scene;
  return data;
}

function hydrateEmptyFieldInputsFromValues() {
  if (!hasExtractedProducts()) return;
  const sku = selectedSku();
  const values = valueMap(sku);
  const skuId = sku?.id || "";
  let changed = false;
  fields.forEach(([key]) => {
    const input = byId(`field-${key}`);
    const value = cleanFieldDisplayValue(values[key]);
    if (!input || !value || cleanFieldDisplayValue(input.value)) return;
    input.value = value;
    fieldOverrides[key] = value;
    if (skuId) {
      fieldOverridesBySku[skuId] = {
        ...(fieldOverridesBySku[skuId] || {}),
        [key]: value,
      };
    }
    changed = true;
  });
  if (changed) fieldSnapshot = currentFieldSignature();
}

function currentFieldSignature() {
  return fields.map(([key]) => `${key}:${readFieldValue(key)}`).join("|");
}

function ensureAppliedSellingPointValues(sku = selectedSku()) {
  const skuId = sku?.id || "";
  if (!skuId || appliedSellingPointOverridesBySku[skuId]) return;
  const values = valueMap(sku);
  appliedSellingPointOverridesBySku[skuId] = {
    feature1: cleanFieldDisplayValue(values.feature1),
    feature2: cleanFieldDisplayValue(values.feature2),
  };
}

function appliedSellingPointValues(sku = selectedSku()) {
  ensureAppliedSellingPointValues(sku);
  const skuId = sku?.id || "";
  return appliedSellingPointOverridesBySku[skuId] || {};
}

function updateSellingPointApplyState() {
  const wrap = byId("sellingPointApplyWrap");
  if (!wrap) return;
  wrap.classList.toggle("is-hidden", !sellingPointDraftDirty);
}

function applySellingPointChanges() {
  captureFieldOverrides();
  const skuId = selectedSku()?.id || "";
  if (skuId) {
    appliedSellingPointOverridesBySku[skuId] = {
      feature1: readFieldValue("feature1"),
      feature2: readFieldValue("feature2"),
    };
  }
  fieldSnapshot = currentFieldSignature();
  sellingPointDraftDirty = false;
  updateSellingPointApplyState();
  renderAll();
}

function handleFieldInput(event) {
  const key = event.currentTarget?.dataset?.key;
  const isSellingPointField = sellingPointFieldKeys.has(key);
  if (key) {
    fieldOverrides[key] = event.currentTarget.value;
    const skuId = selectedSku()?.id || "";
    if (skuId && !isSellingPointField) {
      fieldOverridesBySku[skuId] = {
        ...(fieldOverridesBySku[skuId] || {}),
        [key]: event.currentTarget.value,
      };
    }
  }
  fieldSnapshot = currentFieldSignature();
  if (isSellingPointField) {
    sellingPointDraftDirty = true;
    updateSellingPointApplyState();
    return;
  }
  captureFieldOverrides();
  renderAll();
}

function syncFieldChanges() {
  const nextSnapshot = currentFieldSignature();
  if (nextSnapshot === fieldSnapshot) return;
  captureFieldOverrides();
  fieldSnapshot = nextSnapshot;
  renderAll();
}

function startFieldWatcher() {
  fieldSnapshot = currentFieldSignature();
  window.setInterval(syncFieldChanges, 300);
}

function compactSourceStatus(text) {
  const length = String(text || "").trim().length;
  if (!length) return "待输入";
  if (length >= 1200) return "已读取";
  return "少量文本";
}

function sourceSummaryRows(sku, template) {
  const products = currentProducts();
  const selectedGroup = productGroups[sku.groupKey] || sku.group || {};
  const dimensionStatus = sku.dims?.source || selectedGroup.evidenceNote || "按当前字段生成";
  if (!hasExtractedProducts()) {
    return [
      ["采购单", sourcePayload.purchase ? compactSourceStatus(sourcePayload.purchase) : "待输入", sourceNotes.purchase],
      ["Amazon 模板", sourcePayload.amazonTemplate ? compactSourceStatus(sourcePayload.amazonTemplate) : "未输入", sourceNotes.amazonTemplate],
      ["供应商", sourcePayload.supplier ? compactSourceStatus(sourcePayload.supplier) : "待输入", sourceNotes.alibaba],
      ["参考链接", sourcePayload.competitor ? compactSourceStatus(sourcePayload.competitor) : "未输入", sourceNotes.amazon],
      ["当前输出", `待解析，${template.imageTypes.length} 张图模板`, "解析资料后生成当前产品图组。"],
    ];
  }
  return [
    ["采购单", sourcePayload.purchase ? compactSourceStatus(sourcePayload.purchase) : "待输入", sourceNotes.purchase],
    ["Amazon 模板", sourcePayload.amazonTemplate ? compactSourceStatus(sourcePayload.amazonTemplate) : "未输入", sourceNotes.amazonTemplate],
    ["供应商", sourcePayload.supplier ? compactSourceStatus(sourcePayload.supplier) : "待输入", sourceNotes.alibaba],
    ["参考链接", sourcePayload.competitor ? compactSourceStatus(sourcePayload.competitor) : "未输入", sourceNotes.amazon],
    ["当前输出", `${products.length} 个产品 / 款式，${template.imageTypes.length} 张图`, dimensionStatus],
  ];
}

function renderSourceSummary() {
  const summary = byId("sourceSummary");
  if (!summary) return;

  const sku = selectedSku();
  const template = selectedTemplate();
  summary.innerHTML = sourceSummaryRows(sku, template).map(([label, status, note]) => `
    <article class="source-summary-item">
      <div>
        <strong>${escapeHtml(label)}</strong>
        <span>${escapeHtml(note)}</span>
      </div>
      <mark>${escapeHtml(status)}</mark>
    </article>
  `).join("");
}

function dimensionLabelForData(data, index) {
  const context = [
    data.productName,
    data.singleSpec,
    data.specList,
    data.dimensionList,
    data.structure,
    data.scene,
    data.detailParameter,
  ].filter(Boolean).join(" ");
  if (/umbrella|伞|canopy|folded|open diameter|open height|rain|sun shade/i.test(context)) {
    return ["", "Folded Size", "Open Diameter", "Open Height"][index] || `Dimension ${index}`;
  }
  return ["", "Top Width", "Side Length", "Bottom Width"][index] || `Dimension ${index}`;
}

function buildDimensionListFromFields(data) {
  const dimensions = [
    data.topWidth && `${dimensionLabelForData(data, 1)}: ${cleanTokenValue(data.topWidth)}`,
    data.sideLength && `${dimensionLabelForData(data, 2)}: ${cleanTokenValue(data.sideLength)}`,
    data.bottomWidth && `${dimensionLabelForData(data, 3)}: ${cleanTokenValue(data.bottomWidth)}`,
    data.weight && `Weight: ${cleanTokenValue(data.weight)}`,
  ].filter(Boolean);
  return dimensions.length ? `[VERIFIED_DIMENSIONS: ${dimensions.join("; ")}]` : "";
}

function currentPromptData(sku) {
  const base = valueMap(sku);
  const fieldsData = currentFields();
  const nonEmptyFieldsData = Object.fromEntries(
    Object.entries(fieldsData).filter(([, value]) => cleanFieldDisplayValue(value)),
  );
  const data = {
    ...base,
    ...nonEmptyFieldsData,
    surfaceFinish: fieldsData.surfaceFinish ?? base.surfaceFinish,
    detailParameter: fieldsData.detailParameter ?? base.detailParameter,
    feature3: "",
  };
  if (sellingPointDraftDirty) {
    const appliedSellingPoints = appliedSellingPointValues(sku);
    data.feature1 = appliedSellingPoints.feature1 ?? base.feature1 ?? "";
    data.feature2 = appliedSellingPoints.feature2 ?? base.feature2 ?? "";
  }
  const group = productGroups[sku.groupKey] || sku.group || {};
  const productName = promptValue(data.productName, defaultProductName(sku));
  data.fit = "";
  const liveColor = promptValue(data.color, "");
  const skuColor = promptValue(sku.color || sku.colorEnglish || sku.displayColor, "");
  const baseSpec = promptValue(cleanTokenValue(base.singleSpec), "");
  const optionSpec = liveColor && skuColor
    ? liveColor
    : baseSpec
    || promptValue(sku.shape, "")
    || group.promptName
    || productName
    || "[PRODUCT_SPEC]";
  const productSpec = productName || optionSpec || "[PRODUCT_SPEC]";
  const pack = fieldsData.pack || "";
  const cupRange = validSizeRangeValue(fieldsData.cupRange || sizeRangeValueForSku(sku, base));
  data.productName = productName;
  data.packagingCount = ensureParameterToken("PRODUCT_COUNT_OR_SET", pack);
  data.singleSpec = `[CURRENT_PRODUCT_OPTION: ${[productSpec, pack].filter(Boolean).join(", ")}]`;
  data.bundleComponents = base.bundleComponents || sku.bundleComponents || "";
  data.dimensionList = buildDimensionListFromFields(data) || base.dimensionList || sku.dimensionList || "";
  data.specList = `[SPEC_LIST: ${[productSpec, optionSpec !== productSpec ? optionSpec : "", cupRange, pack, data.material, data.dimensionList].filter(Boolean).join(" / ")}]`;
  return data;
}

function cleanHtmlText(html) {
  const strippedHtml = String(html || "")
    .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, " ");
  const doc = new DOMParser().parseFromString(strippedHtml, "text/html");
  doc.querySelectorAll("script, style, noscript, svg").forEach((node) => node.remove());
  const title = doc.querySelector("title")?.textContent || "";
  const metaDescription = doc.querySelector('meta[name="description"]')?.getAttribute("content") || "";
  const headings = Array.from(doc.querySelectorAll("h1,h2,h3")).map((node) => node.textContent).join(" ");
  const body = doc.body?.innerText || "";
  return [title, metaDescription, headings, body].join("\n").replace(/\s+/g, " ").trim();
}

function normalizeImageUrl(value) {
  const raw = String(value || "")
    .replace(/\\u002F/gi, "/")
    .replace(/\\\//g, "/")
    .replace(/&amp;/g, "&")
    .trim();
  if (!raw || /^data:|^blob:/i.test(raw)) return "";
  if (raw.startsWith("//")) return `https:${raw}`;
  if (/^https?:\/\//i.test(raw)) return raw;
  return "";
}

function imageInfoKeywordScore(text) {
  const source = String(text || "");
  const keywordMatches = source.match(/产品参数|产品信息|产品详情|详细资料|品名|克重|尺码|尺寸|长|宽|高|直径|半径|收纳|折叠|展开|面料|材质|材料|工艺|特殊工艺|厚薄|弹力|拉力|阻力|抗拉|防断|不断裂|不惧断裂|不变形|耐用|全身|针数|柔软|规格|型号|重量|容量|PRODUCT\s*NAME|GRAM\s*WEIGHT|SIZE|MATERIAL|TECHNOLOGY|DETAIL|PARAMETER|diameter|folded|compact|portable|umbrella|stretch|resistance|fracture|tear|durable/gi);
  const largeDetailMatches = source.match(/详情|描述|detail|desc|offer-detail|product-description|商品介绍|产品介绍/gi);
  return (keywordMatches ? keywordMatches.length * 8 : 0) + (largeDetailMatches ? largeDetailMatches.length * 5 : 0);
}

function productDetailLabelScore(text) {
  const source = String(text || "");
  const labels = source.match(/品\s*名|PRODUCT\s*NAME|克\s*重|GRAM\s*WEIGHT|尺\s*码|SIZE|尺\s*寸|规\s*格|重\s*量|直\s*径|收\s*纳|折\s*叠|展\s*开|伞\s*面|面\s*料|MATERIAL|工\s*艺|TECHNOLOGY|特\s*殊\s*工\s*艺|厚\s*薄|弹\s*力|拉\s*力|阻\s*力|抗\s*拉|防\s*断|不\s*断\s*裂|不\s*变\s*形|耐\s*用|针\s*数|柔\s*软|产品参数|产品信息|详细资料|规格参数|diameter|folded|compact|portable|stretch|resistance|durable/gi);
  return labels ? labels.length : 0;
}

function isFactoryOrServiceImageText(text) {
  return /源头厂家|品质保障|为什么选择|工厂面积|厂房面积|生产设备|日发量|日产量|发货员|包装工|仓库面积|仓储能力|行业经验|实力认证|分销代理|代理加盟|网络代销|资质齐全|发货支持|产品支持|运营支持|客服支持|售前咨询|售后指导|来图来样|定制logo|提供精美图片包|48H|48小时|常备库存|快速打样|设计团队|质量保证|厂房|工厂|仓库|物流|发货|退货|开票|服务规则|买家保障|跨境服务|factory|warehouse|production\s+capacity|daily\s+output|shipping|return\s+policy|customer\s+service|distribution\s+agent/i.test(String(text || ""));
}

function isCommerceOrRecommendationText(text) {
  return /店铺推荐|爆款推荐|热卖|严选|¥|￥|价格|起批|拿货|下单|包邮|现货|只做精品|包装可定制|支持混批|一件代发|跨境货源|货源|厂家直销|批发|供应商|seller|price|wholesale|dropshipping/i.test(String(text || ""));
}

function productFeatureTextScore(text) {
  const matches = String(text || "").match(/防滑|硅胶|点胶|抓地|弹力|拉力|阻力|训练|拉伸|抗拉|防断|断裂|不断裂|不惧断裂|不变形|变形|耐用|全身|需求|高弹|柔软|透气|棉|聚酯|氨纶|尺码|克重|重量|尺寸|直径|收纳|折叠|展开|小巧|轻便|便携|防晒|遮阳|防雨|防风|伞骨|晴雨|材质|面料|工艺|厚薄|针数|袜|鞋|服装|衣服|裤|裙|箱包|背包|手提包|杯|滤纸|包装纸|包花纸|花束|鲜花包装|花艺|礼品包装|伞|cotton|spandex|polyester|silicone|tpe|resistance|exercise\s+band|workout\s+band|stretch|fracture|tear|durable|grip|anti.?slip|non.?slip|size|material|weight|texture|umbrella|compact|portable|uv|windproof|waterproof|wrapping\s+paper|flower\s+wrapping|bouquet|floral\s+wrap|gift\s+wrap/gi);
  return matches ? matches.length : 0;
}

function isProductInfoImageText(text) {
  return imageInfoKeywordScore(text) > 0 || productFeatureTextScore(text) > 0;
}

function ocrCompactText(text) {
  return String(text || "").replace(/\s+/g, "");
}

function isProductSellingPointText(text) {
  const source = [String(text || ""), ocrCompactText(text)].join("\n");
  return /9\s*M|9米|不惧断裂|不断裂|防断|抗拉|不变形|均匀拉伸|耐用|安全|全身|便携|轻便|轻巧|小巧|收纳|防滑|止滑|抓地|防水|防雨|防晒|遮阳|防风|加固|柔软|透气|吸汗|抗菌|防臭|高弹|弹力|拉伸|阻力|拉力|容量|承重|省力|稳固|牢固|易清洁|可水洗|多场景|多用途|满足不同需求|fracture|break|tear|deformation|durable|safe|portable|lightweight|compact|non.?slip|anti.?slip|waterproof|windproof|uv|breathable|soft|elastic|stretch|resistance|reinforced|multi.?use|easy.?clean/i.test(source);
}

function urlImageSizeHint(url) {
  const source = String(url || "");
  const candidates = [];
  for (const match of source.matchAll(/(?:^|[._-])([1-9]\d{1,4})x([1-9]\d{1,4})(?:[._-]|$)/gi)) {
    candidates.push({ width: Number(match[1]), height: Number(match[2]) });
  }
  for (const match of source.matchAll(/(?:tps|size)[_-]([1-9]\d{1,4})[_-]([1-9]\d{1,4})/gi)) {
    candidates.push({ width: Number(match[1]), height: Number(match[2]) });
  }
  for (const match of source.matchAll(/[-_]([1-9]\d{1,4})[-_]([1-9]\d{1,4})(?=\.(?:jpe?g|png|webp|gif)(?:[?#]|$))/gi)) {
    candidates.push({ width: Number(match[1]), height: Number(match[2]) });
  }
  const query = source.match(/[?&](?:w|width)=([1-9]\d{1,4})(?:&|$).*?[?&](?:h|height)=([1-9]\d{1,4})(?:&|$)/i)
    || source.match(/[?&](?:h|height)=([1-9]\d{1,4})(?:&|$).*?[?&](?:w|width)=([1-9]\d{1,4})(?:&|$)/i);
  if (query) candidates.push({ width: Number(query[1]), height: Number(query[2]) });
  return candidates.find((size) => Number.isFinite(size.width) && Number.isFinite(size.height)) || null;
}

function isSmallOrThumbnailImageUrl(url) {
  const source = String(url || "");
  if (/alicdn\.com\/cms\/upload\//i.test(source)) return true;
  if (/\.(?:summ|search|icon|small|thumb|avatar|logo)\.(?:jpe?g|png|webp|gif)(?:[?#]|$)/i.test(source)) return true;
  if (/\.(?:jpe?g|png|webp|gif)_(?:[1-9]\d{1,3}x[1-9]\d{1,3}|q\d+)(?:[?#]|$)/i.test(source)) return true;
  if (/(?:^|[._-])(?:16|24|32|40|48|50|58|60|64|80|88|100|120|150|160|180|200|220|240|260|300|310)x(?:16|24|32|40|48|50|58|60|64|80|88|100|120|150|160|180|200|220|240|260|300|310)(?:[._-]|$)/i.test(source)) return true;
  const size = urlImageSizeHint(source);
  if (size && (Math.min(size.width, size.height) < 480 || size.width * size.height < 450000)) return true;
  if (/[?&](?:w|width|h|height)=(?:[1-9]|[1-9]\d|[12]\d\d|3[01]\d)(?:&|$)/i.test(source)) return true;
  return false;
}

function isDetailSource(meta) {
  return String(meta?.source || "").toLowerCase() === "detail";
}

function isDetailDescriptionGifUrl(url, meta = {}) {
  const source = String(url || "");
  return isDetailSource(meta)
    && /\.gif(?:[?#]|$)/i.test(source)
    && /cbu01\.alicdn\.com\/img\/ibank\//i.test(source)
    && !/cms\/upload|(?:logo|icon|avatar|sprite|loading|blank|placeholder|qrcode|qr-code)/i.test(source);
}

function isSupportedProductImageUrl(url, meta = {}) {
  const source = String(url || "");
  if (/\.(?:jpe?g|png|webp)(?:[?#]|$)/i.test(source)) return true;
  return isDetailDescriptionGifUrl(source, meta);
}

function isLikelyProductDetailImageCandidate(candidate) {
  const url = imageCandidateUrl(candidate);
  const context = typeof candidate === "string" ? "" : candidate?.context || "";
  if (!url || isSmallOrThumbnailImageUrl(url)) return false;
  if (isFactoryOrServiceImageText(context) && !isProductInfoImageText(context)) return false;
  if (isCommerceOrRecommendationText(context) && productDetailLabelScore(context) < 2) return false;
  return true;
}

function addImageUrl(urls, seen, value, meta = {}) {
  const normalized = normalizeImageUrl(value);
  if (!normalized || seen.has(normalized)) return;
  if (!isSupportedProductImageUrl(normalized, meta)) return;
  if (!/alicdn|cbu01|itemcdn|taobao|tmall/i.test(normalized)) return;
  if (/\.(?:svg)(?:[?#]|$)/i.test(normalized)) return;
  if (/(?:logo|icon|avatar|sprite|loading|blank|placeholder|qrcode|qr-code)/i.test(normalized)) return;
  if (isSmallOrThumbnailImageUrl(normalized)) return;
  if (isFactoryOrServiceImageText(meta.context || "") && !isProductInfoImageText(meta.context || "")) return;
  seen.add(normalized);
  urls.push({
    url: normalized,
    source: meta.source || "html",
    context: meta.context || "",
    index: Number.isFinite(meta.index) ? meta.index : urls.length,
    score: (meta.score || 0) + imageInfoKeywordScore(meta.context || ""),
  });
}

function extractSrcsetUrls(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim().split(/\s+/)[0])
    .filter(Boolean);
}

function nearbyImageContext(html, index, radius = 500) {
  const source = String(html || "");
  const start = Math.max(0, index - radius);
  const end = Math.min(source.length, index + radius);
  return cleanHtmlText(source.slice(start, end)).slice(0, 600);
}

function extractImageUrlsFromHtml(html, sourceName = "html") {
  const urls = [];
  const seen = new Set();
  const doc = new DOMParser().parseFromString(html, "text/html");
  const imageAttrs = ["src", "data-src", "data-original", "data-lazy-src", "data-img", "original", "imageurl", "imageUrl"];
  const srcsetAttrs = ["srcset", "data-srcset"];

  doc.querySelectorAll("img, source").forEach((node, index) => {
    const context = [node.getAttribute("alt"), node.getAttribute("title"), node.getAttribute("data-title")].filter(Boolean).join(" ");
    imageAttrs.forEach((attr) => addImageUrl(urls, seen, node.getAttribute(attr), { source: sourceName, context, index }));
    srcsetAttrs.forEach((attr) => {
      extractSrcsetUrls(node.getAttribute(attr)).forEach((url) => addImageUrl(urls, seen, url, { source: sourceName, context, index }));
    });
  });

  const urlPattern = /(?:https?:\\?\/\\?\/|\/\/)[^"'<>\s\\]+?\.(?:jpe?g|png|webp|gif)(?:\?[^"'<>\s\\]*)?/gi;
  for (const match of html.matchAll(urlPattern)) {
    addImageUrl(urls, seen, match[0], {
      source: sourceName,
      context: nearbyImageContext(html, match.index || 0),
      index: match.index || urls.length,
    });
  }

  return urls;
}

function extractDetailUrlsFromHtml(html) {
  const urls = [];
  const seen = new Set();
  const patterns = [
    /"detailUrl"\s*:\s*"([^"]+)"/gi,
    /detailUrl['"]?\s*[:=]\s*['"]([^'"]+)['"]/gi,
  ];

  patterns.forEach((pattern) => {
    for (const match of html.matchAll(pattern)) {
      const url = normalizeImageUrl(match[1]);
      if (url && isProductDetailFragmentUrl(url) && !seen.has(url)) {
        seen.add(url);
        urls.push(url);
      }
    }
  });

  return urls.slice(0, 2);
}

function isProductDetailFragmentUrl(url) {
  return /(?:itemcdn\.tmall\.com\/1688offer|desc\.alicdn\.com|cbu01\.alicdn\.com|detail\.1688\.com)/i.test(String(url || ""))
    && !/finance|credit|quota|rule|service|agreement/i.test(String(url || ""));
}

async function fetchDetailHtml(detailUrls, onProgress) {
  const fragments = [];
  for (let index = 0; index < detailUrls.length; index += 1) {
    const url = detailUrls[index];
    const fetchStartedAt = performance.now();
    onProgress?.(`正在读取 1688 详情描述片段... ${index + 1}/${detailUrls.length}`);
    try {
      const response = await withTimeout(fetch(url, { credentials: "omit" }), DETAIL_FETCH_TIMEOUT_MS, "Detail fetch timed out");
      if (!response.ok) {
        onProgress?.(`1688 详情描述片段 ${index + 1}/${detailUrls.length} 读取失败：HTTP ${response.status}，耗时 ${elapsedText(fetchStartedAt)}。`);
        continue;
      }
      fragments.push(await response.text());
      onProgress?.(`1688 详情描述片段 ${index + 1}/${detailUrls.length} 读取完成：${elapsedText(fetchStartedAt)}。`);
    } catch {
      onProgress?.(`1688 详情描述片段 ${index + 1}/${detailUrls.length} 读取超时或失败：${elapsedText(fetchStartedAt)}。`);
      // Detail fragments are optional; OCR can still run against images in the saved HTML.
    }
  }
  return fragments.join("\n");
}

function imageCandidateUrl(candidate) {
  return typeof candidate === "string" ? normalizeImageUrl(candidate) : normalizeImageUrl(candidate?.url);
}

function imageCandidateScore(candidate, fallbackIndex = 0) {
  if (typeof candidate === "string") return fallbackIndex;
  const sourceScore = candidate.source === "detail" ? 100 : candidate.source === "html" ? 10 : 0;
  const context = candidate.context || "";
  const productInfoBoost = productDetailLabelScore(context) * 20 + (isProductInfoImageText(context) ? 12 : 0);
  const factoryPenalty = isFactoryOrServiceImageText(context) ? 80 : 0;
  return sourceScore + (candidate.score || 0) + productInfoBoost - factoryPenalty - Math.min(candidate.index || fallbackIndex, 10000) / 10000;
}

function uniqueImageCandidates(...groups) {
  const candidates = [];
  const seen = new Set();
  groups.flat().forEach((candidate, index) => {
    const normalized = imageCandidateUrl(candidate);
    if (!normalized || seen.has(normalized)) return;
    const normalizedCandidate = typeof candidate === "string"
      ? { url: normalized, source: "html", context: "", index, score: imageCandidateScore(candidate, index) }
      : { ...candidate, url: normalized };
    if (!isLikelyProductDetailImageCandidate(normalizedCandidate)) return;
    seen.add(normalized);
    candidates.push({ ...normalizedCandidate, score: imageCandidateScore(normalizedCandidate, index) });
  });
  const detailCandidates = candidates
    .filter((candidate) => candidate.source === "detail")
    .sort((left, right) => right.score - left.score);
  const keywordCandidates = candidates
    .filter((candidate) => candidate.source !== "detail" && isProductInfoImageText(candidate.context))
    .sort((left, right) => right.score - left.score);
  const fallbackCandidates = candidates
    .filter((candidate) => candidate.source !== "detail" && !isProductInfoImageText(candidate.context))
    .sort((left, right) => right.score - left.score)
    .slice(0, OCR_FALLBACK_IMAGE_LIMIT);
  return uniqueByUrl([
    ...detailCandidates,
    ...keywordCandidates,
    ...fallbackCandidates,
  ]).slice(0, OCR_IMAGE_LIMIT);
}

function uniqueByUrl(candidates) {
  const seen = new Set();
  return candidates.filter((candidate) => {
    const url = imageCandidateUrl(candidate);
    if (!url || seen.has(url)) return false;
    seen.add(url);
    return true;
  });
}

function loadOcrEngine() {
  if (window.Tesseract) return Promise.resolve(window.Tesseract);
  return loadScriptOnce(OCR_SCRIPT_URL, "Tesseract");
}

function cleanOcrText(text) {
  return String(text || "")
    .replace(/[|_~]+/g, " ")
    .split(/\n+/)
    .map((line) => line.replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .join("\n")
    .trim();
}

function hasReadableOcrContent(text, minChars = 12) {
  const clean = cleanOcrText(text);
  const meaningfulChars = (clean.match(/[A-Za-z0-9\u4e00-\u9fff]/g) || []).length;
  return meaningfulChars >= minChars && meaningfulChars / Math.max(clean.length, 1) >= 0.25;
}

function isUsefulOcrText(text, meta = {}) {
  const clean = cleanOcrText(text);
  if (clean.length < 8) return false;
  if (Object.keys(extractProductDetailAttributes(clean)).length) return true;
  if (isProductSellingPointText(clean)) return true;
  if (isDetailSource(meta) && hasReadableOcrContent(clean, 10)) return true;
  if (isFactoryOrServiceImageText(clean) && productDetailLabelScore(clean) < 2) return false;
  if (isCommerceOrRecommendationText(clean) && productDetailLabelScore(clean) < 2) return false;
  if (imageInfoKeywordScore(clean) > 0) return true;
  if (!isProductInfoImageText(clean)) return false;
  return hasReadableOcrContent(clean, 12);
}

function hasEnoughProductDetail(text) {
  const attrs = extractProductDetailAttributes(text);
  return productDetailLabelScore(text) >= 3 || Boolean(attrs.Material && (attrs.Size || attrs.Weight || attrs.Technology || attrs.SpecialCraft));
}

function compactOcrKeyText(text) {
  return String(text || "")
    .replace(/[·•"“”'‘’()[\]{}|_~:：,，.。;；/\\-]+/g, " ")
    .replace(/\s+/g, "")
    .trim();
}

function normalizeDetailValue(value) {
  return cleanFieldDisplayValue(String(value || "")
    .replace(/[-—]{2,}/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s:：,，.。;；/\\-]+|[\s:：,，.。;；/\\-]+$/g, "")
    .trim());
}

function usefulDetailValue(value) {
  const clean = normalizeDetailValue(value);
  if (!clean || !/[0-9A-Za-z\u4e00-\u9fff]/.test(clean)) return "";
  if (isCodeLikeValue(clean)) return "";
  const compact = compactOcrKeyText(clean).toLowerCase();
  const labelOnlyValues = new Set([
    "productname",
    "gramweight",
    "size",
    "material",
    "technology",
    "品名",
    "克重",
    "尺码",
    "面料",
    "工艺",
    "特殊工艺",
  ]);
  return labelOnlyValues.has(compact) ? "" : clean;
}

function isOverlongDetailValue(value) {
  const clean = String(value || "").trim();
  return clean.length > 120 || clean.split(/\s+/).length > 18;
}

function normalizeMaterialPercent(value) {
  const clean = String(value || "").replace(/[^\d.]/g, "");
  if (!clean) return "";
  const numeric = Number(clean);
  if (!Number.isFinite(numeric)) return "";
  if (numeric <= 100) return clean.replace(/\.0+$/, "");
  if (/^\d{3}$/.test(clean) && clean.endsWith("3")) return clean.slice(0, 2);
  if (/^\d{3}$/.test(clean) && Number(clean.slice(0, 2)) <= 100) return clean.slice(0, 2);
  return "";
}

function extractPercentAfterLabel(text, labelPattern) {
  const match = String(text || "").match(new RegExp(`(?:${labelPattern})\\s*([0-9.]+)\\s*%`, "i"));
  return normalizeMaterialPercent(match?.[1] || "");
}

function materialPercentValue(text, labelPattern) {
  const source = String(text || "");
  const beforeMatches = [...source.matchAll(new RegExp(`([0-9.]+)\\s*%\\s*(?:${labelPattern})`, "gi"))]
    .map((match) => normalizeMaterialPercent(match[1]))
    .filter(Boolean);
  return beforeMatches[beforeMatches.length - 1] || extractPercentAfterLabel(source, labelPattern);
}

function translateProductDetailValue(key, value) {
  const clean = usefulDetailValue(value);
  if (!clean) return "";
  const normalized = compactOcrKeyText(clean).toLowerCase();
  if (key === "Material") {
    const hasCombedCotton = /精\s*梳\s*棉|combed\s+cotton/i.test(clean);
    const cotton = materialPercentValue(clean, "精\\s*梳\\s*棉|棉|cotton");
    const spandex = materialPercentValue(clean, "氨\\s*纶|氨\\s*给|各\\s*纶|胺\\s*纶|spandex");
    const polyester = materialPercentValue(clean, "聚\\s*[酯酷醒酮]\\s*纤\\s*维|聚\\s*[酯酷醒酮]|polyester");
    const parts = [
      cotton && `${cotton}% ${hasCombedCotton ? "premium combed cotton" : "cotton"}`,
      spandex && `${spandex}% spandex`,
      polyester && `${polyester}% polyester fiber`,
    ].filter(Boolean);
    if (!parts.length && hasCombedCotton) return "premium combed cotton";
    return parts.length ? parts.join(", ") : "";
  }
  if (key === "Weight") {
    if (!/(?:重量|净重|约重|克重|GRAM\s*WEIGHT|weight|net weight)/i.test(clean)) return "";
    const weight = clean.match(/([0-9]+(?:\.[0-9]+)?)\s*(?:g|克)/i)?.[1];
    return weight ? `${weight} g` : "";
  }
  if (key === "Capacity") {
    const capacity = clean.match(/([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|l|L|oz|毫升|升)/i);
    return capacity ? normalizeDimensionUnit(`${capacity[1]} ${capacity[2]}`) : "";
  }
  if (key === "Size") {
    const explicitSize = clean.match(/(?:尺码|鞋码|SIZE|size)?\s*(US\s*Size\s*[0-9]+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?\s*(?:码|号)|XXL|XL|L|M|S|XS)(?=\s|$|[;；,，/])/i)?.[1];
    if (explicitSize) return explicitSize.replace(/\s+/g, " ").trim();
    const womenSize = clean.match(/(?:WOMAN|WOMEN|女士|女)\s*[\(（]?\s*([0-9]+\s*[-~]\s*[0-9]+)\s*[\)）]?/i)?.[1];
    if (womenSize) return `women's ${womenSize.replace(/\s+/g, "")}`;
    if (/均码|one\s*size|free\s*size/i.test(clean) && !isOverlongDetailValue(clean)) return "one size";
    return "";
  }
  if (key === "Technology") {
    const values = [];
    if (/灵活|flex/.test(clean)) values.push("flexible fit");
    if (/防滑|anti.?slip|non[-\s]?slip|grip|硅胶|点胶|胶印|printed?|print/i.test(clean)) values.push("anti-slip grip sole");
    return values.length ? values.join(", ") : "";
  }
  if (key === "SpecialCraft") {
    const values = [];
    if (hasCrossStrapDesign(clean)) values.push("3D cross-strap design");
    if (hasFiveToeDesign(clean)) values.push("five-toe separated design");
    if (/厚薄|适中|medium/i.test(clean)) values.push("medium thickness");
    if (/柔软|细腻|soft/i.test(clean)) values.push("soft and delicate texture");
    if (/高弹|橡筋|elastic/i.test(clean)) values.push("high-elastic cuff");
    if (/针数|密|dense|knit/i.test(clean)) values.push("dense knit count");
    if (/阻菌|抗菌|防臭|antibacterial|deodor/i.test(clean)) values.push("antibacterial deodorizing");
    if (/受力|均匀|pressure/i.test(clean)) values.push("even pressure distribution");
    return values.length ? values.join(", ") : "";
  }
  if (key === "Product Detail Name") {
    const compact = clean.replace(/\s+/g, "");
    if (/五[指趾].*袜/.test(compact)) {
      const height = /中[筒商]|mid/i.test(compact) ? "mid-calf " : "";
      const antiSlip = /防[滑涓]|anti.?slip|grip/i.test(compact) ? "anti-slip " : "";
      return `solid color five-toe ${height}${antiSlip}socks`.replace(/\s+/g, " ").trim();
    }
    return clean;
  }
  return normalized || clean;
}

function translateAttributeValue(key, value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return "";
  if (/^Material$/i.test(key)) {
    const detailMaterial = translateProductDetailValue("Material", clean);
    if (detailMaterial) return detailMaterial;
    if (/^棉$/i.test(clean)) return "cotton";
    if (/尼龙|锦纶|nylon/i.test(clean)) return "nylon";
    if (/氨纶/.test(clean)) return "spandex";
    if (/聚酯|涤纶/.test(clean)) return "polyester";
  }
  if (/^Size$/i.test(key)) return translateProductDetailValue("Size", clean);
  if (/^Weight$/i.test(key)) return translateProductDetailValue("Weight", clean);
  if (/^Capacity$/i.test(key)) return translateProductDetailValue("Capacity", clean);
  if (/^Technology$/i.test(key)) return translateProductDetailValue("Technology", clean);
  if (/^SpecialCraft$/i.test(key)) return translateProductDetailValue("SpecialCraft", clean);
  if (/^Sock Height$/i.test(key)) {
    if (/中筒|mid/i.test(clean)) return "mid-calf coverage";
    if (/长筒|高筒|over[-\s]?the[-\s]?calf|knee/i.test(clean)) return "long sock coverage";
    if (/短筒|船袜|低帮|no[-\s]?show|low/i.test(clean)) return "low-cut sock profile";
  }
  if (/^Seam$/i.test(key)) {
    if (/无骨|手工|seamless|hand/i.test(clean)) return "seamless hand-linked toe comfort";
  }
  if (/^Weaving$/i.test(key)) {
    if (/单针|single/i.test(clean)) return "single-needle knit texture";
  }
  return clean;
}

function mergeDetailFeatureValues(...values) {
  const seen = new Set();
  return values
    .filter(Boolean)
    .flatMap((value) => String(value).split(/\s*,\s*/))
    .map((value) => value.trim())
    .filter((value) => {
      const key = value.toLowerCase();
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .join(", ");
}

function extractTextureScaleDetails(text) {
  const source = String(text || "");
  const values = [];
  const thickness = extractFirstMatch(source, [
    /(?:厚\s*薄|Thickness)\s*[:：]\s*(薄|适中|厚|thin|medium|thick)/i,
  ]);
  const elasticity = extractFirstMatch(source, [
    /(?:弹\s*力|Elasticity)\s*[:：]\s*(无|微弹|高弹|高|none|low|medium|high)/i,
  ]);
  const knitCount = extractFirstMatch(source, [
    /(?:针\s*数|Knit\s*Count|Needle\s*Count)\s*[:：]\s*(粗|密|coarse|dense)/i,
  ]);
  const softness = extractFirstMatch(source, [
    /(?:柔\s*软|Softness)\s*[:：]\s*(硬|适中|软|hard|medium|soft)/i,
  ]);
  if (/适中|medium/i.test(thickness)) values.push("medium thickness");
  if (/薄|thin/i.test(thickness)) values.push("thin fabric thickness");
  if (/厚|thick/i.test(thickness)) values.push("thick fabric feel");
  if (/高弹|高|high/i.test(elasticity)) values.push("high elasticity");
  if (/微弹|medium|low/i.test(elasticity)) values.push("slight elasticity");
  if (/无|none/i.test(elasticity)) values.push("no stretch");
  if (/密|dense/i.test(knitCount)) {
    values.push("dense knit count");
  }
  if (/粗|coarse/i.test(knitCount)) {
    values.push("coarse knit count");
  }
  if (/软|soft/i.test(softness)) {
    values.push("soft hand feel");
  }
  if (/适中|medium/i.test(softness)) {
    values.push("medium-soft hand feel");
  }
  if (/硬|hard/i.test(softness)) {
    values.push("firm hand feel");
  }
  return values.join(", ");
}

function decodeHtmlEntities(value) {
  return String(value || "")
    .replace(/&gt;/gi, ">")
    .replace(/&lt;/gi, "<")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'");
}

function isSockFamilyText(text) {
  return /瑜伽袜|普拉提袜|五指袜|五趾袜|分趾袜|船袜|短袜|隐形袜|浅口袜|袜子|袜|toe socks|grip socks|no[-\s]?show socks?|liner socks?|ankle socks?|socks/i.test(text);
}

function isYogaSockText(text) {
  return isSockFamilyText(text) && /瑜伽|普拉提|防滑|点胶|硅胶|yoga|pilates|barre|grip|non[-\s]?slip|silicone/i.test(text);
}

function hasFiveToeDesign(text) {
  return /五\s*[指趾]|分\s*[指趾]|toe[-\s]?separated|five[-\s]?toe/i.test(String(text || ""));
}

function hasCrossStrapDesign(text) {
  const clean = String(text || "");
  return /立体|3d|交叉|交织|cross/i.test(clean) && /绑带|带子|strap|strappy/i.test(clean)
    || /cross[-\s]?strap|crossed\s+strap|strappy/i.test(clean);
}

function colorName(rawColor) {
  const clean = String(rawColor || "").replace(/[()（）百人复购\s]/g, "").trim();
  const colorMap = {
    白: "white",
    白色: "white",
    本白: "white",
    本色: "white",
    本全: "white",
    米白: "off white",
    米白色: "off white",
    乳白: "off white",
    奶白: "off white",
    象牙白: "ivory white",
    草绿: "grass green",
    绿: "green",
    绿色: "green",
    蓝: "blue",
    蓝色: "blue",
    水蓝: "light blue",
    淡蓝: "light blue",
    紫: "purple",
    紫色: "purple",
    浅紫: "light purple",
    黑: "black",
    黑色: "black",
    粉: "pink",
    粉色: "pink",
    浅粉: "light pink",
    粉红: "pink",
    红: "red",
    红色: "red",
    灰: "gray",
    灰色: "gray",
    银: "silver",
    银色: "silver",
    银灰: "silver gray",
    深灰: "dark gray",
    灰黑色: "gray black",
    灰绿色: "gray green",
    黄绿色: "yellow green",
    豆绿: "bean green",
    苹果绿: "apple green",
    苹果绿色: "apple green",
    浅卡: "light khaki",
    卡其: "khaki",
    肉粉: "nude pink",
    白红: "white red",
    白紫: "white purple",
    黑紫: "black purple",
    黄: "yellow",
    黄色: "yellow",
    橙: "orange",
    橙色: "orange",
    天蓝: "sky blue",
    天蓝色: "sky blue",
    深蓝: "deep blue",
    深蓝色: "deep blue",
    湖蓝: "lake blue",
    湖蓝色: "lake blue",
    深棕: "dark brown",
    深棕色: "dark brown",
    棕: "brown",
    棕色: "brown",
    咖色: "coffee brown",
    咖啡色: "coffee brown",
    肤色: "nude",
    珊瑚红: "coral red",
    浆果色: "berry",
    蜜桃粉: "peach pink",
    森林绿: "forest green",
    番茄紫: "tomato purple",
    开心果绿: "pistachio green",
    摩卡棕: "mocha brown",
    酒红: "wine red",
    酒红色: "wine red",
    抹茶色: "matcha green",
    薄荷绿: "mint green",
    云彩蓝: "cloud blue",
    云彩粉: "cloud pink",
    云彩紫: "cloud purple",
  };
  return colorMap[clean] || clean;
}

function outputColorName(rawColor) {
  const clean = String(rawColor || "").replace(/[()（）百人复购\s]/g, "").trim();
  if (/^(?:本色|本全|原色|natural)$/i.test(clean)) return "natural";
  return colorName(rawColor);
}

function simpleColorName(rawColor) {
  const colorKey = canonicalColorKey(rawColor);
  const simpleMap = {
    white: "white",
    black: "black",
    gray: "gray",
    blue: "blue",
    green: "green",
    purple: "purple",
    pink: "pink",
    red: "red",
    yellow: "yellow",
    orange: "orange",
    brown: "brown",
    nude: "nude",
    khaki: "khaki",
  };
  return simpleMap[colorKey] || outputColorName(rawColor);
}

function displayColorName(rawColor, fallback = "") {
  const source = String(rawColor || fallback || "")
    .replace(/（[^）]*）|\([^)]*\)/g, "")
    .replace(/[()（）百人复购]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!source) return "";
  const directChinese = colorFromTextSegment(source, []);
  if (directChinese) return directChinese;
  const normalized = source.toLowerCase().replace(/[\s_-]+/g, "");
  const englishMap = {
    white: "白色",
    offwhite: "米白",
    ivorywhite: "象牙白",
    ivory: "象牙白",
    black: "黑色",
    gray: "灰色",
    grey: "灰色",
    silver: "银色",
    silvergray: "银灰",
    darkgray: "深灰",
    blue: "蓝色",
    lightblue: "淡蓝",
    green: "绿色",
    grassgreen: "草绿",
    beangreen: "豆绿",
    purple: "紫色",
    lightpurple: "浅紫",
    pink: "粉色",
    lightpink: "浅粉",
    nudepink: "肉粉",
    red: "红色",
    yellow: "黄色",
    orange: "橙色",
    skyblue: "天蓝",
    deepblue: "深蓝",
    lakeblue: "湖蓝",
    darkbrown: "深棕",
    brown: "棕色",
    coffeebrown: "咖色",
    nude: "肤色",
    coralred: "珊瑚红",
    berry: "浆果色",
    peachpink: "蜜桃粉",
    forestgreen: "森林绿",
    tomatopurple: "番茄紫",
    pistachiogreen: "开心果绿",
    mochabrown: "摩卡棕",
    winered: "酒红色",
    matchagreen: "抹茶色",
    mintgreen: "薄荷绿",
    cloudblue: "云彩蓝",
    cloudpink: "云彩粉",
    cloudpurple: "云彩紫",
    khaki: "卡其",
    lightkhaki: "浅卡",
  };
  return englishMap[normalized] || source;
}

function canonicalColorKey(value) {
  const raw = String(value || "")
    .toLowerCase()
    .replace(/[()（）百人复购\s_-]+/g, "")
    .trim();
  const named = colorName(value).toLowerCase().replace(/\s+/g, "");
  const groups = {
    white: ["白", "白色", "本白", "本色", "本全", "米白", "乳白", "奶白", "象牙白", "white", "offwhite", "ivorywhite", "ivory", "cream"],
    black: ["黑", "黑色", "black"],
    gray: ["灰", "灰色", "银", "银色", "银灰", "深灰", "gray", "grey", "silver", "silvergray", "darkgray"],
    blue: ["蓝", "蓝色", "水蓝", "淡蓝", "天蓝", "天蓝色", "深蓝", "深蓝色", "湖蓝", "湖蓝色", "blue", "lightblue", "skyblue", "deepblue", "lakeblue"],
    green: ["绿", "绿色", "草绿", "豆绿", "苹果绿", "苹果绿色", "green", "grassgreen", "beangreen", "applegreen"],
    purple: ["紫", "紫色", "浅紫", "purple", "lightpurple"],
    pink: ["粉", "粉色", "浅粉", "粉红", "肉粉", "pink", "lightpink", "nudepink"],
    red: ["红", "红色", "red"],
    yellow: ["黄", "黄色", "yellow"],
    orange: ["橙", "橙色", "orange"],
    brown: ["棕", "棕色", "深棕", "深棕色", "咖色", "咖啡色", "摩卡棕", "brown", "darkbrown", "coffeebrown", "mochabrown"],
    nude: ["肤色", "nude"],
    khaki: ["浅卡", "卡其", "khaki", "lightkhaki"],
  };
  const matched = Object.entries(groups).find(([, aliases]) => aliases.includes(raw) || aliases.includes(named));
  return matched ? matched[0] : named || raw;
}

function colorAliasValues(value) {
  const canonical = canonicalColorKey(value);
  const aliases = {
    white: ["白", "白色", "本白", "本色", "本全", "米白", "乳白", "奶白", "象牙白", "white", "off white", "ivory", "cream"],
    black: ["黑", "黑色", "black"],
    gray: ["灰", "灰色", "银", "银色", "银灰", "深灰", "gray", "grey", "silver", "silver gray", "dark gray"],
    blue: ["蓝", "蓝色", "水蓝", "淡蓝", "天蓝", "天蓝色", "深蓝", "深蓝色", "湖蓝", "湖蓝色", "blue", "light blue", "sky blue", "deep blue", "lake blue"],
    green: ["绿", "绿色", "草绿", "豆绿", "苹果绿", "苹果绿色", "green", "grass green", "bean green", "apple green"],
    purple: ["紫", "紫色", "浅紫", "purple", "light purple"],
    pink: ["粉", "粉色", "浅粉", "粉红", "肉粉", "pink", "light pink", "nude pink"],
    red: ["红", "红色", "red"],
    yellow: ["黄", "黄色", "yellow"],
    orange: ["橙", "橙色", "orange"],
    brown: ["棕", "棕色", "深棕", "深棕色", "咖色", "咖啡色", "摩卡棕", "brown", "dark brown", "coffee brown", "mocha brown"],
    nude: ["肤色", "nude"],
    khaki: ["浅卡", "卡其", "khaki", "light khaki"],
  };
  return Array.from(new Set([
    String(value || "").replace(/\s+/g, ""),
    colorName(value),
    ...(aliases[canonical] || []),
  ].filter(Boolean)));
}

function productColorCandidates() {
  return [
    "珊瑚红", "浆果色", "苹果绿", "开心果绿", "蜜桃粉", "森林绿", "番茄紫", "摩卡棕", "酒红色", "酒红", "抹茶色", "薄荷绿",
    "云彩蓝", "云彩粉", "云彩紫", "深蓝色", "深蓝", "天蓝色", "天蓝", "湖蓝色", "湖蓝", "深棕色", "深棕", "米白色", "米白",
    "咖啡色", "咖色", "肤色", "白色", "黑色", "粉色", "蓝色", "绿色", "紫色", "红色", "黄色", "橙色", "银色", "棕色",
    "灰黑色", "灰绿色", "黄绿色", "本白", "本色", "本全", "草绿", "水蓝", "淡蓝", "浅紫", "浅粉", "粉红", "肉粉", "银灰", "深灰", "豆绿", "浅卡", "卡其",
    "白", "黑", "粉", "蓝", "绿", "紫", "红", "黄", "橙", "银", "棕",
  ];
}

function isKnownColorValue(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return false;
  return Boolean(colorAliasValues(clean).length && [
    "white", "black", "gray", "blue", "green", "purple", "pink", "red", "yellow", "orange", "brown", "nude", "khaki",
  ].includes(canonicalColorKey(clean)));
}

function colorsFromPurchaseText(value) {
  const source = compactChineseText(value);
  const matches = [];
  productColorCandidates().forEach((candidate) => {
    const index = source.indexOf(candidate);
    if (index > -1) matches.push({ candidate, index });
  });
  matches.sort((left, right) => left.index - right.index || right.candidate.length - left.candidate.length);
  const seen = new Set();
  return matches
    .map(({ candidate }) => candidate)
    .filter((candidate) => {
      const key = canonicalColorKey(candidate);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function normalizePurchaseText(value) {
  const glyphMap = {
    "⾊": "色",
    "⽩": "白",
    "⿊": "黑",
    "⻩": "黄",
    "⻣": "骨",
    "⻢": "马",
    "⼨": "寸",
    "⾹": "香",
    "⽤": "用",
    "⽣": "生",
    "⼝": "口",
    "⽔": "水",
    "⼤": "大",
    "⼩": "小",
    "⽊": "木",
    "⾍": "虫",
    "⻥": "鱼",
    "⽛": "牙",
    "⼥": "女",
    "⼿": "手",
    "⾦": "金",
    "⼊": "入",
    "⼉": "儿",
    "⼼": "心",
    "⽂": "文",
    "⾃": "自",
    "⾝": "身",
    "⽆": "无",
    "⽑": "毛",
    "⽪": "皮",
    "⾐": "衣",
    "⾜": "足",
    "⽇": "日",
    "⽉": "月",
    "⽅": "方",
    "⻓": "长",
    "⾬": "雨",
    "⼱": "巾",
    "⼼": "心",
  };
  return String(value || "")
    .normalize("NFKC")
    .replace(/[⾊⽩⿊⻩⻣⻢⼨⾹⽤⽣⼝⽔⼤⼩⽊⾍⻥⽛⼥⼿⾦⼊⼉⼼⽂⾃⾝⽆⽑⽪⾐⾜⽇⽉⽅⻓⾬⼱]/g, (char) => glyphMap[char] || char)
    .replace(/亚\s*马\s*逊/g, "亚马逊")
    .replace(/颜\s*色/g, "颜色")
    .replace(/尺\s*寸/g, "尺寸")
    .replace(/尺\s*码/g, "尺码")
    .replace(/规\s*格/g, "规格");
}

function normalizeModelText(text) {
  return normalizePurchaseText(decodeHtmlEntities(text))
    .replace(/(阿里)\s+([A-Z]{1,4}\d{2,5})/gi, "$1$2")
    .replace(/\b([1-9]\d?)\s*[。.,，]\s*(?=(?:阿里\s*)?[A-Z]{1,4}\s*\d{2,5})/g, "$1 ")
    .replace(/\b([A-Z]{1,4})\s+(\d{2,5})\b/gi, "$1$2")
    .replace(/([A-Z]{1,4}\d{2})\s+(\d)(?=[\u4e00-\u9fff])/g, "$1$2")
    .replace(/\b([A-Z]{1,4}\d{2,4})\s+(\d)(?=\s*(?:黑|白|本白|本色|本全|米白|乳白|奶白|粉|蓝|绿|草绿|紫|灰|红|浅卡|卡其|颜色|尺码|均码))/gi, "$1$2")
    .replace(/\s+/g, " ")
    .trim();
}

function splitModelColor(value) {
  const clean = normalizeModelText(value)
    .replace(/（[^）]*）|\([^)]*\)/g, "")
    .replace(/>/g, " ")
    .trim();
  const match = clean.match(/([A-Z]{1,4}\d{3,5})(?:-[A-Z]{1,4}\d{3,5})?\s*([\u4e00-\u9fff]{1,4})?/i);
  if (!match) return {};
  return {
    model: match[1].toUpperCase(),
    color: match[2] || "",
    colorEnglish: colorName(match[2] || ""),
  };
}

function skuModelFromText(value) {
  return extractFirstMatch(value, [/\b([A-Z]{1,4}\d{2,5})\b/i]);
}

function supplierSkuColor(value) {
  const compact = compactChineseText(value);
  const found = productColorCandidates().find((candidate) => compact.includes(candidate));
  return found || extractEnglishColorName(value);
}

function supplierSkuSize(value) {
  const source = normalizePurchaseText(value);
  const dimension = extractFirstMatch(source, [
    /([1-9]\d{2,4}\s*[*x×]\s*[1-9]\d{1,3}\s*[*x×]\s*[0-9.]+\s*mm)/i,
    /([1-9]\d{2,4}\s*[*x×]\s*[1-9]\d{1,3}\s*[*x×]\s*[0-9.]+\s*毫米)/i,
    /([1-9]\d{2,4}\s*[*x×]\s*[1-9]\d{1,3}\s*cm)/i,
  ]);
  if (dimension) return dimension.replace(/\s+/g, "");
  const explicitSize = extractFirstMatch(source, [
    /(?:尺码|鞋码|size)\s*[:：]?\s*(US\s*Size\s*[0-9]+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?\s*(?:码|号)?|XXL|XL|L|M|S|XS)(?=\s|$|[;；,，/])/i,
    /(?:^|[\s;；,，/])([0-9]+(?:\.[0-9]+)?\s*(?:码|号))(?=\s|$|[;；,，/])/i,
  ]);
  return explicitSize ? explicitSize.replace(/\s+/g, " ").trim() : "";
}

function dimensionsFromSkuSize(size) {
  const match = cleanFieldDisplayValue(size).match(/([0-9.]+)\s*[*x×]\s*([0-9.]+)\s*[*x×]\s*([0-9.]+)\s*(mm|毫米|cm|厘米|公分)?/i);
  if (!match) return {};
  const unit = /cm|厘米|公分/i.test(match[4] || "") ? "cm" : "mm";
  return {
    topWidth: `${match[1]} ${unit}`,
    sideLength: `${match[2]} ${unit}`,
    bottomWidth: `${match[3]} ${unit}`,
    source: "1688 SKU option size",
  };
}

function supplierSkuStyle(value) {
  const compact = compactChineseText(value);
  const styles = [];
  if (/加长/.test(compact)) styles.push("加长款");
  if (/加厚/.test(compact)) styles.push("加厚款");
  if (!styles.length && /常规/.test(compact)) styles.push("常规款");
  return styles.join("");
}

function parseSupplierSkuText(value) {
  const text = normalizePurchaseText(value);
  const model = skuModelFromText(text);
  const parsedModelColor = model ? splitModelColor(text) : {};
  const color = parsedModelColor.color || supplierSkuColor(text);
  const size = supplierSkuSize(text);
  const style = supplierSkuStyle(text);
  if (!model && !color && !size && !style) return {};
  const sizeDims = dimensionsFromSkuSize(size);
  return {
    model: (parsedModelColor.model || model || GENERIC_SUPPLIER_SKU_MODEL).toUpperCase(),
    color,
    colorEnglish: colorName(color),
    size,
    variantStyle: style,
    rawSpec: text,
    dims: sizeDims,
  };
}

function supplierOptionIdentity(option) {
  return [
    option.model,
    canonicalColorKey(option.color || ""),
    cleanFieldDisplayValue(option.variantStyle || "").toLowerCase(),
    cleanFieldDisplayValue(option.size || "").toLowerCase(),
    cleanFieldDisplayValue(option.rawSpec || "").toLowerCase(),
  ].filter(Boolean).join("-");
}

function sameSupplierRawSpec(left, right) {
  const leftSpec = cleanFieldDisplayValue(left?.rawSpec || "").toLowerCase();
  const rightSpec = cleanFieldDisplayValue(right?.rawSpec || "").toLowerCase();
  return Boolean(leftSpec && rightSpec && leftSpec === rightSpec);
}

function moreSpecificSupplierColor(current, next) {
  const cleanCurrent = cleanFieldDisplayValue(current);
  const cleanNext = cleanFieldDisplayValue(next);
  if (!cleanNext) return cleanCurrent;
  if (!cleanCurrent) return cleanNext;
  return cleanNext.length > cleanCurrent.length && cleanNext.includes(cleanCurrent) ? cleanNext : cleanCurrent;
}

function mergeSupplierSkuOption(target, next) {
  target.color = moreSpecificSupplierColor(target.color, next.color);
  target.colorEnglish = colorName(target.color) || target.colorEnglish || next.colorEnglish || "";
  target.size = target.size || next.size || "";
  target.material = target.material || next.material || "";
  target.variantStyle = target.variantStyle || next.variantStyle || "";
  target.rawSpec = target.rawSpec || next.rawSpec || "";
  target.dims = {
    topWidth: target.dims?.topWidth || next.dims?.topWidth || "",
    sideLength: target.dims?.sideLength || next.dims?.sideLength || "",
    bottomWidth: target.dims?.bottomWidth || next.dims?.bottomWidth || "",
    weight: target.dims?.weight || next.dims?.weight || "",
    source: target.dims?.source || next.dims?.source || "",
  };
  return target;
}

function addSupplierSkuOption(options, seen, option) {
  if (!option.model) return;
  const existing = options.find((candidate) => (
    candidate.model === option.model
    && (
      sameSupplierRawSpec(candidate, option)
      || (
        candidate.color && option.color && isSameColorName(candidate.color, option.color)
        && cleanFieldDisplayValue(candidate.variantStyle || "") === cleanFieldDisplayValue(option.variantStyle || "")
        && (!candidate.size || !option.size || cleanFieldDisplayValue(candidate.size) === cleanFieldDisplayValue(option.size))
      )
    )
  ));
  if (existing) {
    mergeSupplierSkuOption(existing, option);
    seen.add(supplierOptionIdentity(existing));
    return;
  }
  const key = supplierOptionIdentity(option);
  if (seen.has(key)) return;
  seen.add(key);
  options.push(option);
}

function extractSupplierTitles(html) {
  const titles = [];
  const seen = new Set();
  for (const match of String(html || "").matchAll(/<title[^>]*>([\s\S]*?)<\/title>/gi)) {
    const title = decodeHtmlEntities(match[1]).replace(/\s+/g, " ").trim();
    if (!title || seen.has(title)) continue;
    seen.add(title);
    titles.push(title.replace(/\s*-\s*阿里巴巴\s*$/i, ""));
  }
  return titles;
}

function normalizedSupplierPropValue(value, unit = "") {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return "";
  const cleanUnit = cleanFieldDisplayValue(unit);
  if (!cleanUnit || new RegExp(`${cleanUnit}$`, "i").test(clean)) return clean;
  return `${clean} ${cleanUnit}`;
}

function supplierPropsMap(propsText) {
  const props = {};
  for (const match of String(propsText || "").matchAll(/\{[^{}]*"unit"\s*:\s*"([^"]*)"[^{}]*"name"\s*:\s*"([^"]+)"[^{}]*"value"\s*:\s*"([^"]*)"[^{}]*\}/gi)) {
    props[match[2]] = normalizedSupplierPropValue(match[3], match[1]);
  }
  return props;
}

function detailValueBetween(source, startPattern, endPatterns) {
  const match = source.match(startPattern);
  if (!match) return "";
  const start = (match.index || 0) + match[0].length;
  const tail = source.slice(start, start + 260);
  const endIndexes = endPatterns
    .map((pattern) => {
      const endMatch = tail.match(pattern);
      return endMatch ? endMatch.index : -1;
    })
    .filter((index) => index > 0);
  const end = endIndexes.length ? Math.min(...endIndexes) : tail.length;
  return normalizeDetailValue(tail.slice(0, end));
}

function firstUsefulDetailValue(source, startPatterns, endPatterns) {
  for (const pattern of startPatterns) {
    const value = usefulDetailValue(detailValueBetween(source, pattern, endPatterns));
    if (value) return value;
  }
  return "";
}

function extractProductDetailAttributes(text) {
  const source = decodeHtmlEntities(text || "")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!source) return {};
  const endLabels = [
    /品\s*名\s*(?:[\(（]\s*PRODUCT\s*NAME\s*[\)）])?|PRODUCT\s*NAME/i,
    /克\s*重\s*(?:[\(（]\s*GRAM\s*WEIGHT\s*[\)）])?|GRAM\s*WEIGHT/i,
    /尺\s*码\s*(?:[\(（]\s*SIZE\s*[\)）])?|SIZE/i,
    /面\s*料\s*(?:[\(（]\s*MATERIAL\s*[\)）])?|MATERIAL/i,
    /工\s*艺\s*(?:[\(（]\s*TECHNOLOGY\s*[\)）])?|TECHNOLOGY/i,
    /特\s*殊\s*工\s*艺/i,
    /容\s*量|容量\s*\/\s*容积|CAPACITY|VOLUME/i,
    /厚\s*薄|弹\s*力|针\s*数|柔\s*软/i,
  ];
  const attrs = {};
  const entries = [
    ["Product Detail Name", [
      /品\s*名\s*[\(（]\s*PRODUCT\s*NAME\s*[\)）]\s*[:：]?\s*/i,
      /(?:品\s*名|PRODUCT\s*NAME)\s*[:：]?\s*/i,
    ]],
    ["Weight", [
      /克\s*重\s*[\(（]\s*GRAM\s*WEIGHT\s*[\)）]\s*[:：]?\s*/i,
      /(?:克\s*重|GRAM\s*WEIGHT)\s*[:：]?\s*/i,
    ]],
    ["Size", [
      /尺\s*码\s*[\(（]\s*SIZE\s*[\)）]\s*[:：]?\s*/i,
      /(?:尺\s*码|SIZE)\s*[:：]?\s*/i,
    ]],
    ["Material", [
      /面\s*料\s*[\(（]\s*MATERIAL\s*[\)）]\s*[:：]?\s*/i,
      /(?:面\s*料|MATERIAL)\s*[:：]?\s*/i,
    ]],
    ["Technology", [
      /工\s*艺\s*[\(（]\s*TECHNOLOGY\s*[\)）]\s*[:：]?\s*/i,
      /(?:工\s*艺|TECHNOLOGY)\s*[:：]?\s*/i,
    ]],
    ["SpecialCraft", [
      /特\s*殊\s*工\s*艺\s*[:：]?\s*/i,
    ]],
    ["Capacity", [
      /(?:容\s*量|容积|CAPACITY|VOLUME)\s*[:：]?\s*/i,
    ]],
  ];
  entries.forEach(([key, startPatterns]) => {
    const rawValue = firstUsefulDetailValue(source, startPatterns, endLabels);
    const value = translateProductDetailValue(key, rawValue);
    if (value) attrs[key] = value;
  });

  if (!attrs.Material) {
    const material = translateProductDetailValue("Material", source);
    if (material) attrs.Material = material;
  }
  if (!attrs.Weight) {
    const weight = extractFirstMatch(source, [
      /(?:重量|净重|约重|克\s*重|GRAM\s*WEIGHT|weight|net weight)[^\d]{0,12}([0-9]+(?:\.[0-9]+)?)\s*[gG克]/i,
    ]);
    if (weight) attrs.Weight = `${weight} g`;
  }
  if (!attrs.Capacity) {
    const capacity = extractFirstMatch(source, [
      /(?:容量|容积|capacity|volume)[^\d]{0,12}([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|l|L|oz|毫升|升)/i,
      /([0-9]+(?:\.[0-9]+)?)\s*(ml|mL|l|L|oz|毫升|升)(?=\s|$|[;；,，。])/i,
    ]);
    if (capacity) {
      const unit = source.match(new RegExp(`${capacity.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*(ml|mL|l|L|oz|毫升|升)`, "i"))?.[1] || "";
      attrs.Capacity = normalizeDimensionUnit(`${capacity} ${unit}`);
    }
  }
  if (!attrs.Size) {
    const size = extractFirstMatch(source, [
      /(?:尺码|鞋码|SIZE|size)[^\dA-Z]{0,12}(US\s*Size\s*[0-9]+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?\s*(?:码|号)?|XXL|XL|L|M|S|XS)/i,
      /(?:WOMAN|WOMEN|女士|女)\s*[\(（]?\s*([0-9]+\s*[-~]\s*[0-9]+)\s*[\)）]?/i,
    ]);
    if (size) attrs.Size = /^US/i.test(size) || /码|号|[A-Z]/i.test(size) ? size.replace(/\s+/g, " ").trim() : `women's ${size.replace(/\s+/g, "")}`;
  }
  if (!attrs.Technology && /灵活|防滑|胶印/i.test(source)) {
    attrs.Technology = translateProductDetailValue("Technology", source);
  }
  if (!attrs.SpecialCraft && /厚薄|弹力|针数|柔软|细腻|高弹|橡筋|阻菌|抗菌|防臭|受力|均匀|立体|交叉|绑带|五指|五趾|分趾|strap|toe/i.test(source)) {
    attrs.SpecialCraft = translateProductDetailValue("SpecialCraft", source);
  }
  const textureScaleDetails = extractTextureScaleDetails(source);
  if (textureScaleDetails) {
    attrs.SpecialCraft = mergeDetailFeatureValues(attrs.SpecialCraft, textureScaleDetails);
  }
  return attrs;
}

function normalizeSourceProductTitle(value) {
  return normalizePurchaseText(decodeHtmlEntities(value || ""))
    .replace(/\s*-\s*阿里巴巴\s*$/i, " ")
    .replace(/厂家|工厂|源头|现货|批发|一件代发|跨境|亚马逊|外贸|爆款|新款|热卖|供应|定制|专用|男女款|女款|男款|女士|女|男士|男/g, " ")
    .replace(/颜色\s*[:：][^,，;；\n]+/gi, " ")
    .replace(/尺码\s*[:：][^,，;；\n]+/gi, " ")
    .replace(/\b[A-Z]{1,4}\d{2,5}\b/gi, " ")
    .replace(/[|_~·•"“”'‘’()[\]{}:：,，.。;；/\\]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function descriptiveYogaSockProductName(value, context = "") {
  const source = [value, context].filter(Boolean).join(" ");
  if (!isYogaSockText(source)) return "";
  const gender = /女|女士|women|woman|female/i.test(source) ? "women's" : "";
  const nonSlip = /防滑|止滑|点胶|硅胶|anti[-\s]?slip|non[-\s]?slip|grip|silicone/i.test(source) ? "non-slip" : "";
  const toeDesign = hasFiveToeDesign(source) ? "five-toe" : "";
  const use = /瑜伽|yoga/i.test(source) && /普拉提|pilates/i.test(source)
    ? "yoga pilates"
    : /普拉提|pilates/i.test(source)
      ? "pilates"
      : "yoga";
  const name = [gender, nonSlip, toeDesign, use, "socks"].filter(Boolean).join(" ");
  return name.replace(/\s+/g, " ").trim();
}

function translateProductTitleWords(value, context = "") {
  const descriptiveName = descriptiveYogaSockProductName(value, context);
  if (descriptiveName) return descriptiveName;
  let text = normalizeSourceProductTitle(value);
  if (!text) return "";
  const phraseMap = [
    [/滴漏式手冲咖啡挂耳|手冲咖啡滤纸|咖啡滤纸|滤纸/gi, " coffee filter "],
    [/接粉环|磁吸接粉环/gi, " dosing funnel "],
    [/粉碗/gi, " filter basket "],
    [/生日口水巾|宠物围兜|口水巾|围兜/gi, " pet bandana "],
    [/铃铛项圈|猫咪项圈|宠物猫脖圈|项圈/gi, " cat collar "],
    [/木天蓼猫玩具|木天蓼|猫玩具/gi, " cat toy "],
    [/拉力带|拉力绳|弹力带/gi, " resistance band "],
    [/园艺手套|花园手套/gi, " garden gloves "],
    [/防护手套|手套/gi, " protective gloves "],
    [/瑜伽球|普拉提小球/gi, " yoga ball "],
    [/六折伞|折叠伞|雨伞|伞/gi, " folding umbrella "],
    [/线香|香薰/gi, " incense sticks "],
    [/瑜伽袜|普拉提袜/gi, " yoga socks "],
    [/船袜|隐形袜|浅口袜|短袜/gi, " no-show socks "],
    [/五指袜|五趾袜|分趾袜/gi, " toe socks "],
    [/袜子|袜/gi, " socks "],
    [/瑜伽/gi, " yoga "],
    [/普拉提/gi, " pilates "],
    [/防滑|止滑|点胶|硅胶/gi, " grip "],
    [/五指|五趾|分趾/gi, " toe "],
    [/圆形/gi, " round "],
    [/扇形/gi, " fan shaped "],
    [/原木浆|本色|原色/gi, " natural "],
    [/棉/gi, " cotton "],
  ];
  phraseMap.forEach(([pattern, replacement]) => {
    text = text.replace(pattern, replacement);
  });
  return compactEnglishWords(text, 6);
}

function simplifySupplierTitle(title, context = "") {
  return translateProductTitleWords(title)
    || translateProductTitleWords(context)
    || compactEnglishWords(title, 6);
}

function extractSupplierSkuOptions(text) {
  const decoded = decodeHtmlEntities(text);
  const options = [];
  const seen = new Set();

  const structuredPattern = /SKU_OPTION\s*[:;]+\s*([\s\S]*?)(?=\s+SKU_OPTION\s*[:;]+|\s+PRODUCT_(?:TITLE|ATTRIBUTE)\s*:|\n|$)/gi;
  for (const match of decoded.matchAll(structuredPattern)) {
    const optionText = match[1].replace(/\s+(?=(?:model|color|colorEnglish|variantStyle|size|material|rawSpec|length|width|height|weight)=)/gi, "; ");
    const parts = Object.fromEntries(optionText
      .split(";")
      .map((part) => part.trim())
      .map((part) => {
        const index = part.indexOf("=");
        return index > -1 ? [part.slice(0, index).trim(), part.slice(index + 1).trim()] : ["", ""];
      })
      .filter(([key]) => key));
    addSupplierSkuOption(options, seen, {
      model: parts.model,
      color: parts.color,
      colorEnglish: parts.colorEnglish || colorName(parts.color),
      size: parts.size,
      material: parts.material || "",
      variantStyle: parts.variantStyle || "",
      rawSpec: parts.rawSpec || "",
      dims: {
        topWidth: parts.length || "",
        sideLength: parts.width || "",
        bottomWidth: parts.height || "",
        weight: parts.weight || "",
        source: parts.length || parts.width || parts.height || parts.weight ? "1688 SKU package information" : "",
      },
    });
  }

  for (const match of decoded.matchAll(/"specAttrs"\s*:\s*"([^"]+)"/gi)) {
    const [skuRaw, sizeRaw] = match[1].split(">");
    const parsed = parseSupplierSkuText(skuRaw);
    addSupplierSkuOption(options, seen, {
      ...parsed,
      size: sizeRaw || parsed.size || "",
    });
  }

  const modelSelectionPattern = /"specId"\s*:\s*"[^"]+"[\s\S]{0,500}?"name"\s*:\s*"([^"]+)"[\s\S]{0,500}?"skuId"\s*:\s*\d+\s*,\s*"props"\s*:\s*\[([\s\S]*?)\]\s*\}/gi;
  for (const match of decoded.matchAll(modelSelectionPattern)) {
    const skuRaw = match[1];
    const props = supplierPropsMap(match[2]);
    const parsed = parseSupplierSkuText(skuRaw);
    const color = props["颜色"] || parsed.color || supplierSkuColor(skuRaw);
    const size = props["尺码"] || parsed.size || "";
    const length = props["长度"] || "";
    const material = props["材质"] || "";
    addSupplierSkuOption(options, seen, {
      ...parsed,
      color,
      colorEnglish: colorName(color),
      size,
      rawSpec: parsed.rawSpec || skuRaw,
      material,
      dims: {
        topWidth: parsed.dims?.topWidth || length,
        sideLength: parsed.dims?.sideLength || "",
        bottomWidth: parsed.dims?.bottomWidth || "",
        weight: parsed.dims?.weight || "",
        source: parsed.dims?.source || (length ? "1688 SKU structured properties" : ""),
      },
    });
  }

  const packInfoPattern = /\{[^{}]*(?:"sku2"\s*:\s*"([^"]*)"[^{}]*)?"sku1"\s*:\s*"([^"]*)"[^{}]*"length"\s*:\s*([0-9.]+)[^{}]*"width"\s*:\s*([0-9.]+)[^{}]*"weight"\s*:\s*([0-9.]+)[^{}]*"height"\s*:\s*([0-9.]+)/gi;
  for (const match of decoded.matchAll(packInfoPattern)) {
    const parsed = parseSupplierSkuText(match[2]);
    const length = Number(match[3]);
    const width = Number(match[4]);
    const weight = Number(match[5]);
    const height = Number(match[6]);
    addSupplierSkuOption(options, seen, {
      ...parsed,
      size: match[1] || parsed.size || "",
      dims: {
        topWidth: parsed.dims?.topWidth || (length ? `${length} cm` : ""),
        sideLength: parsed.dims?.sideLength || (width ? `${width} cm` : ""),
        bottomWidth: parsed.dims?.bottomWidth || (height ? `${height} cm` : ""),
        weight: weight ? `${weight} g` : "",
        source: parsed.dims?.source || "1688 SKU package information",
      },
    });
  }

  return options;
}

function extractSupplierStructuredText(html) {
  if (!html) return "";
  const decoded = decodeHtmlEntities(html);
  const titleLines = extractSupplierTitles(decoded).map((title) => `PRODUCT_TITLE: ${simplifySupplierTitle(title, decoded)}`);
  const skuOptions = extractSupplierSkuOptions(decoded);
  const skuLines = skuOptions.map((option) => [
    "SKU_OPTION:",
    `model=${option.model}`,
    option.color && `color=${option.color}`,
    option.colorEnglish && `colorEnglish=${option.colorEnglish}`,
    option.variantStyle && `variantStyle=${option.variantStyle}`,
    option.size && `size=${option.size}`,
    option.material && `material=${option.material}`,
    option.rawSpec && `rawSpec=${option.rawSpec}`,
    option.dims?.topWidth && `length=${option.dims.topWidth}`,
    option.dims?.sideLength && `width=${option.dims.sideLength}`,
    option.dims?.bottomWidth && `height=${option.dims.bottomWidth}`,
    option.dims?.weight && `weight=${option.dims.weight}`,
  ].filter(Boolean).join("; "));

  const attrPairs = [
    ["功能", "Function"],
    ["主面料成分", "Material"],
    ["适用性别", "Gender"],
    ["包装形式", "Packaging"],
    ["风格", "Style"],
    ["筒高", "Sock Height"],
    ["图案", "Pattern"],
    ["织造方法", "Weaving"],
    ["无骨缝制", "Seam"],
  ];
  const attrLines = attrPairs.map(([sourceLabel, targetLabel]) => {
    const value = extractFirstMatch(decoded, [new RegExp(`"${sourceLabel}"\\s*:\\s*"([^"]+)"`, "i")]);
    return value ? `PRODUCT_ATTRIBUTE: ${targetLabel}=${value}` : "";
  }).filter(Boolean);
  const skuMaterial = skuOptions.find((option) => option.material)?.material || "";
  if (skuMaterial && !attrLines.some((line) => /^PRODUCT_ATTRIBUTE:\s*Material=/i.test(line))) {
    attrLines.push(`PRODUCT_ATTRIBUTE: Material=${skuMaterial}`);
  }
  return [...titleLines, ...attrLines, ...skuLines].join("\n");
}

function imageHasEnoughReadableSize(size) {
  if (!size) return false;
  return Math.min(size.width, size.height) >= 480 && size.width * size.height >= 450000;
}

function loadImageMeta(url) {
  return new Promise((resolve) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => resolve({
      ok: true,
      width: image.naturalWidth || image.width || 0,
      height: image.naturalHeight || image.height || 0,
    });
    image.onerror = () => resolve({ ok: false, width: 0, height: 0 });
    image.src = url;
  });
}

function loadImageForCanvas(url) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Image failed to load"));
    image.src = url;
  });
}

async function imageUrlToOcrInput(url) {
  try {
    const image = await loadImageForCanvas(url);
    const width = image.naturalWidth || image.width || 0;
    const height = image.naturalHeight || image.height || 0;
    if (!imageHasEnoughReadableSize({ width, height })) return { input: url, size: { ok: false, width, height } };
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d");
    if (!context) return { input: url, size: { ok: true, width, height } };
    context.drawImage(image, 0, 0, width, height);
    return {
      input: canvas.toDataURL("image/png"),
      size: { ok: true, width, height },
    };
  } catch {
    const size = await loadImageMeta(url);
    return { input: url, size };
  }
}

function withTimeout(promise, timeoutMs, message) {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      window.setTimeout(() => reject(new Error(message)), timeoutMs);
    }),
  ]);
}

function elapsedText(startTime) {
  const elapsedSeconds = (performance.now() - startTime) / 1000;
  return `${elapsedSeconds.toFixed(elapsedSeconds >= 10 ? 0 : 1)}s`;
}

async function ocrImageUrls(imageUrls, onProgress) {
  if (!imageUrls.length) {
    return { text: "", scannedCount: 0, failedCount: 0, acceptedCount: 0, available: false };
  }

  let Tesseract;
  try {
    onProgress?.(`正在加载 OCR 引擎，准备识别 ${imageUrls.length} 张 1688 图片...`);
    Tesseract = await loadOcrEngine();
  } catch {
    return { text: "", scannedCount: 0, failedCount: imageUrls.length, acceptedCount: 0, available: false };
  }

  const texts = [];
  let failedCount = 0;
  let attemptedCount = 0;
  let sellingPointCount = 0;
  for (let index = 0; index < imageUrls.length; index += 1) {
    const candidate = typeof imageUrls[index] === "string" ? { url: imageUrls[index], source: "html" } : imageUrls[index];
    const url = imageCandidateUrl(candidate);
    if (!url) continue;
    attemptedCount += 1;
    const sourceLabel = candidate.source === "detail" ? "详情描述图" : "页面图片";
    const progressPrefix = `正在识别 1688 ${sourceLabel}文字... ${index + 1}/${imageUrls.length}`;
    let loadStartedAt = performance.now();
    let loadElapsed = "";
    onProgress?.(`${progressPrefix}，正在加载图片...`);
    try {
      const ocrInput = await withTimeout(imageUrlToOcrInput(url), IMAGE_LOAD_TIMEOUT_MS, "Image load timed out");
      loadElapsed = elapsedText(loadStartedAt);
      const imageMeta = ocrInput.size;
      if (!imageMeta.ok || !imageHasEnoughReadableSize(imageMeta)) {
        failedCount += 1;
        onProgress?.(`${progressPrefix}，图片加载 ${loadElapsed}，跳过：图片过小或不可读取。`);
        continue;
      }
      const ocrStartedAt = performance.now();
      onProgress?.(`${progressPrefix}，图片加载 ${loadElapsed}，正在 OCR...`);
      const result = await withTimeout(
        Tesseract.recognize(ocrInput.input, "chi_sim+eng"),
        OCR_RECOGNIZE_TIMEOUT_MS,
        "OCR timed out",
      );
      const ocrElapsed = elapsedText(ocrStartedAt);
      const text = cleanOcrText(result?.data?.text || "");
      if (isUsefulOcrText(text, candidate)) {
        texts.push(text);
        if (isProductSellingPointText(text)) sellingPointCount += 1;
        onProgress?.(`${progressPrefix}，图片加载 ${loadElapsed} / OCR ${ocrElapsed}，已提取有效文字。`);
        if (candidate.source !== "detail" && hasEnoughProductDetail(texts.join("\n"))) break;
      } else {
        onProgress?.(`${progressPrefix}，图片加载 ${loadElapsed} / OCR ${ocrElapsed}，未提取到有效产品文字。`);
      }
    } catch (error) {
      failedCount += 1;
      const stageText = loadElapsed
        ? `图片加载 ${loadElapsed} 后失败：${error.message || "OCR 失败"}`
        : `图片加载失败或超时：${elapsedText(loadStartedAt)}`;
      onProgress?.(`${progressPrefix}，${stageText}`);
    }
  }

  return {
    text: texts.join("\n"),
    scannedCount: attemptedCount - failedCount,
    failedCount,
    acceptedCount: texts.length,
    sellingPointCount,
    available: true,
  };
}

async function ocrLocalImageFile(file, onProgress) {
  if (!file) {
    return { text: "", scannedCount: 0, failedCount: 0, available: false };
  }

  let Tesseract;
  try {
    onProgress?.(`正在加载 OCR 引擎，准备识别采购单图片：${file.name}...`);
    Tesseract = await loadOcrEngine();
  } catch {
    return { text: "", scannedCount: 0, failedCount: 1, available: false };
  }

  const ocrStartedAt = performance.now();
  onProgress?.(`正在识别采购单图片文字：${file.name}...`);
  try {
    const result = await withTimeout(
      Tesseract.recognize(file, "chi_sim+eng"),
      PURCHASE_IMAGE_OCR_TIMEOUT_MS,
      "Purchase image OCR timed out",
    );
    const ocrElapsed = elapsedText(ocrStartedAt);
    const text = cleanOcrText(result?.data?.text || "");
    const structuredRows = structuredPurchaseRowsFromOcrResult(result, text);
    onProgress?.(`采购单图片 OCR 完成：${ocrElapsed}。`);
    return {
      text: [text, structuredRows].filter(Boolean).join("\n"),
      scannedCount: text ? 1 : 0,
      failedCount: text ? 0 : 1,
      available: true,
    };
  } catch {
    onProgress?.(`采购单图片 OCR 失败或超时：${elapsedText(ocrStartedAt)}。`);
    return { text: "", scannedCount: 0, failedCount: 1, available: true };
  }
}

function productAttributeLinesFromSource(attributeSource) {
  return Object.entries(extractProductDetailAttributes(attributeSource)).map(([key, value]) => (
    `PRODUCT_ATTRIBUTE: ${key}=${value}`
  ));
}

async function extractSupplierSourceText(html, onProgress) {
  if (!html) {
    return { text: "", imageCount: 0, candidateCount: 0, scannedCount: 0, failedCount: 0, ocrAvailable: false };
  }

  const baseText = cleanHtmlText(html);
  const structuredText = extractSupplierStructuredText(html);
  const detailUrls = extractDetailUrlsFromHtml(html);
  const detailHtml = detailUrls.length ? await fetchDetailHtml(detailUrls, onProgress) : "";
  const htmlImageCandidates = extractImageUrlsFromHtml(html, "html");
  const detailImageCandidates = detailHtml ? extractImageUrlsFromHtml(detailHtml, "detail") : [];
  const allImageCandidates = [...htmlImageCandidates, ...detailImageCandidates];
  const imageUrls = uniqueImageCandidates(detailImageCandidates, htmlImageCandidates);
  if (!imageUrls.length) {
    const attributeSource = productAttributeSourceText(structuredText);
    const detailAttrLines = productAttributeLinesFromSource(attributeSource);
    return { text: [baseText, structuredText, ...detailAttrLines].filter(Boolean).join("\n"), imageCount: 0, candidateCount: allImageCandidates.length, scannedCount: 0, failedCount: 0, ocrAvailable: false };
  }

  onProgress?.(`已找到 ${allImageCandidates.length} 张 1688 图片，全局筛选后优先识别 ${imageUrls.length} 张疑似产品详情/参数图...`);
  const ocr = await ocrImageUrls(imageUrls, onProgress);
  const attributeSource = productAttributeSourceText(structuredText, ocr.text);
  const detailAttrLines = productAttributeLinesFromSource(attributeSource);
  return {
    text: [baseText, structuredText, ...detailAttrLines, attributeSource && `1688 image OCR text: ${attributeSource}`].filter(Boolean).join("\n"),
    imageCount: imageUrls.length,
    candidateCount: allImageCandidates.length,
    scannedCount: ocr.scannedCount,
    failedCount: ocr.failedCount,
    acceptedCount: ocr.acceptedCount,
    sellingPointCount: ocr.sellingPointCount,
    ocrAvailable: ocr.available,
  };
}

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      resolve("");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file);
  });
}

async function readWorkbook(file) {
  if (!file) return null;
  const xlsx = await loadXlsx();
  if (!xlsx) {
    throw new Error("Excel 解析库未加载，请刷新页面后重试，或先只用 PDF/HTML 资料测试。");
  }
  const buffer = await file.arrayBuffer();
  return xlsx.read(buffer, { type: "array", cellDates: false });
}

async function readTextFiles(files, onProgress) {
  const fileList = Array.from(files || []);
  const texts = [];
  for (let index = 0; index < fileList.length; index += 1) {
    const file = fileList[index];
    onProgress?.(`正在读取 HTML 文件... ${index + 1}/${fileList.length}：${file.name}`);
    const text = await readFileAsText(file);
    if (text) texts.push(`Source HTML file: ${file.name}\n${text}`);
  }
  return texts.join("\n");
}

async function readNamedTextFiles(files, onProgress) {
  const fileList = Array.from(files || []);
  const entries = [];
  for (let index = 0; index < fileList.length; index += 1) {
    const file = fileList[index];
    onProgress?.(`正在读取 HTML 文件... ${index + 1}/${fileList.length}：${file.name}`);
    const text = await readFileAsText(file);
    if (text) entries.push({ name: file.name, text });
  }
  return entries;
}

function namedHtmlEntryText(entry) {
  return entry?.text ? `Source HTML file: ${entry.name}\n${entry.text}` : "";
}

function combinedNamedHtmlEntries(entries) {
  return entries.map(namedHtmlEntryText).filter(Boolean).join("\n");
}

function mergeSupplierSourceResults(results) {
  const values = results.filter(Boolean);
  return {
    text: values.map((item) => item.text).filter(Boolean).join("\n"),
    imageCount: values.reduce((sum, item) => sum + (item.imageCount || 0), 0),
    candidateCount: values.reduce((sum, item) => sum + (item.candidateCount || 0), 0),
    scannedCount: values.reduce((sum, item) => sum + (item.scannedCount || 0), 0),
    failedCount: values.reduce((sum, item) => sum + (item.failedCount || 0), 0),
    acceptedCount: values.reduce((sum, item) => sum + (item.acceptedCount || 0), 0),
    sellingPointCount: values.reduce((sum, item) => sum + (item.sellingPointCount || 0), 0),
    ocrAvailable: values.some((item) => item.ocrAvailable),
  };
}

async function extractSupplierSourcesByFile(entries, onProgress) {
  const results = [];
  for (let index = 0; index < entries.length; index += 1) {
    const entry = entries[index];
    onProgress?.(`正在解析第 ${index + 1}/${entries.length} 个 1688 文件：${entry.name}`);
    const source = await extractSupplierSourceText(namedHtmlEntryText(entry), onProgress);
    results.push({
      name: entry.name,
      ...source,
      text: [`Source HTML file: ${entry.name}`, source.text].filter(Boolean).join("\n"),
    });
  }
  return {
    fileSources: results,
    merged: mergeSupplierSourceResults(results),
  };
}

function productsFromSupplierFileSources(fileSources) {
  return fileSources.map((source, index) => {
    const products = inferProductsFromSources("", source.text, "");
    const product = products[0];
    if (!product) return null;
    const rawSpecName = readableNameFromRawSpec([
      product.supplierOption?.rawSpec,
      product.outputSpec,
      product.spec,
      product.label,
      source.text,
    ].filter(Boolean).join(" "));
    const displayName = cleanProductDisplayName(product.productName || product.outputProductName || product.label, rawSpecName || `Product ${index + 1}`);
    const productName = displayName || rawSpecName || `Product ${index + 1}`;
    if (!rawSpecName && /^Product\s+\d+$/i.test(productName)) return null;
    return {
      ...product,
      id: `EXTRACTED-SUPPLIER-FILE-${index + 1}`,
      label: productName,
      displayLabel: productName,
      productName,
      outputProductName: product.outputProductName && !isMachineProductText(product.outputProductName) ? product.outputProductName : productName,
      baseProductName: product.baseProductName && !isMachineProductText(product.baseProductName) ? product.baseProductName : productName,
      shape: cleanProductDisplayName(product.shape || product.outputSpec || product.spec, productName),
      rawSpec: product.supplierOption?.rawSpec || rawSpecName,
      sourceFile: source.name,
    };
  }).filter(Boolean);
}

function pdfTextLines(items) {
  const lines = [];
  const tolerance = 4;
  (items || []).forEach((item) => {
    const text = normalizePurchaseText(item?.str || "").trim();
    if (!text) return;
    const transform = item?.transform || [];
    const x = Number(transform[4]) || 0;
    const y = Number(transform[5]) || 0;
    let line = lines.find((candidate) => Math.abs(candidate.y - y) <= tolerance);
    if (!line) {
      line = { y, items: [] };
      lines.push(line);
    }
    line.items.push({ x, text });
  });
  return lines
    .map((line) => ({
      ...line,
      items: line.items.sort((left, right) => left.x - right.x),
    }))
    .sort((left, right) => right.y - left.y);
}

function ocrWordsToPdfLikeItems(words) {
  return (words || []).map((word) => {
    const bbox = word?.bbox || {};
    const x0 = Number(bbox.x0 ?? word.x0 ?? word.left ?? word.x) || 0;
    const y0 = Number(bbox.y0 ?? word.y0 ?? word.top ?? word.y) || 0;
    const y1 = Number(bbox.y1 ?? word.y1 ?? (y0 + (word.height || 0))) || y0;
    return {
      str: word.text || word.str || "",
      transform: [1, 0, 0, 1, x0, -y1],
    };
  }).filter((item) => String(item.str || "").trim());
}

function pdfLineText(line) {
  return (line?.items || []).map((item) => item.text).join(" ").replace(/\s+/g, " ").trim();
}

function isPurchaseTableHeaderLine(line) {
  const compact = compactChineseText(pdfLineText(line));
  return /序号货号货品名称规格数量/.test(compact)
    || /序号/.test(compact) && /货号|商品编码|货品编号/.test(compact) && /货品名称|商品名称/.test(compact) && /规格/.test(compact) && /数量/.test(compact);
}

function isPurchaseFooterLine(line) {
  return /货品合计|实付款|货品总量|买家留言|https?:|订单详情预览|订单详情单/.test(pdfLineText(line));
}

function purchaseLineRowNumber(line) {
  const first = (line?.items || []).find((item) => item.x < 70 && /^[1-9]\d{0,2}$/.test(item.text));
  if (!first) return "";
  const hasRowContent = (line.items || []).some((item) => item.x > 70 && item.x < 540 && /[0-9A-Za-z\u4e00-\u9fff]/.test(item.text));
  return hasRowContent ? first.text : "";
}

function purchaseLineRowNumberByRatio(line, pageWidth) {
  const firstLimit = Math.max(70, pageWidth * 0.14);
  const contentLimit = Math.max(140, pageWidth * 0.22);
  const first = (line?.items || []).find((item) => item.x < firstLimit && /^[1-9]\d{0,2}$/.test(item.text));
  if (!first) return "";
  const hasRowContent = (line.items || []).some((item) => item.x > firstLimit && item.x < pageWidth * 0.96 && /[0-9A-Za-z\u4e00-\u9fff]/.test(item.text));
  return hasRowContent ? first.text : "";
}

function purchasePdfCellText(lines, minX, maxX) {
  return lines
    .flatMap((line) => line.items || [])
    .filter((item) => item.x >= minX && item.x < maxX)
    .map((item) => item.text)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

function purchaseOcrCellText(lines, startRatio, endRatio, pageWidth) {
  return purchasePdfCellText(lines, pageWidth * startRatio, pageWidth * endRatio);
}

function purchaseHeaderLabelX(line, labels) {
  const items = (line?.items || []).map((item) => ({
    x: item.x,
    text: compactChineseText(item.text).replace(/[()（）]/g, ""),
  })).filter((item) => item.text);
  for (const label of labels) {
    const direct = items.find((item) => item.text.includes(label) || label.includes(item.text) && item.text.length >= 2);
    if (direct) return direct.x;
    for (let index = 0; index < items.length; index += 1) {
      for (let span = 2; span <= 4 && index + span <= items.length; span += 1) {
        const group = items.slice(index, index + span);
        const joined = group.map((item) => item.text).join("");
        if (joined.includes(label)) return Math.min(...group.map((item) => item.x));
      }
    }
  }
  return null;
}

function purchaseHeaderScore(line) {
  const compact = compactChineseText(pdfLineText(line));
  return [
    /序号/.test(compact),
    /货号|商品编码|货品编号/.test(compact),
    /货品名称|商品名称|品名/.test(compact),
    /规格/.test(compact),
    /数量/.test(compact),
    /单价/.test(compact),
    /金额/.test(compact),
  ].filter(Boolean).length;
}

function purchaseColumnBoundsFromLines(lines, pageWidth) {
  const headerLine = (lines || [])
    .map((line) => ({ line, score: purchaseHeaderScore(line) }))
    .filter((entry) => entry.score >= 4)
    .sort((left, right) => right.score - left.score)[0]?.line;
  if (!headerLine) return null;

  const x = {
    index: purchaseHeaderLabelX(headerLine, ["序号"]),
    code: purchaseHeaderLabelX(headerLine, ["货号", "商品编码", "货品编号"]),
    name: purchaseHeaderLabelX(headerLine, ["货品名称", "商品名称", "品名"]),
    spec: purchaseHeaderLabelX(headerLine, ["规格"]),
    quantity: purchaseHeaderLabelX(headerLine, ["数量"]),
    price: purchaseHeaderLabelX(headerLine, ["单价"]),
    discount: purchaseHeaderLabelX(headerLine, ["优惠"]),
    amount: purchaseHeaderLabelX(headerLine, ["金额"]),
  };
  if (![x.code, x.name, x.spec, x.quantity].every((value) => Number.isFinite(value))) return null;

  const midpoint = (left, right) => (Number(left) + Number(right)) / 2;
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const indexCode = Number.isFinite(x.index) ? midpoint(x.index, x.code) : pageWidth * 0.07;
  const codeName = midpoint(x.code, x.name);
  const nameSpec = midpoint(x.name, x.spec);
  const specQuantity = midpoint(x.spec, x.quantity);
  const quantityPrice = Number.isFinite(x.price) ? midpoint(x.quantity, x.price) : pageWidth * 0.62;
  const priceEnd = Number.isFinite(x.price) && Number.isFinite(x.discount)
    ? midpoint(x.price, x.discount)
    : Number.isFinite(x.price) && Number.isFinite(x.amount)
      ? midpoint(x.price, x.amount)
      : pageWidth * 0.85;
  const amountStart = Number.isFinite(x.discount) && Number.isFinite(x.amount)
    ? midpoint(x.discount, x.amount)
    : Number.isFinite(x.amount)
      ? Math.max(priceEnd, x.amount - pageWidth * 0.04)
      : pageWidth * 0.9;

  return {
    code: [clamp(indexCode, 0, pageWidth), clamp(codeName, 0, pageWidth)],
    name: [clamp(codeName, 0, pageWidth), clamp(nameSpec, 0, pageWidth)],
    spec: [clamp(nameSpec, 0, pageWidth), clamp(specQuantity, 0, pageWidth)],
    quantity: [clamp(specQuantity, 0, pageWidth), clamp(quantityPrice, 0, pageWidth)],
    price: [clamp(quantityPrice, 0, pageWidth), clamp(priceEnd, 0, pageWidth + 60)],
    amount: [clamp(amountStart, 0, pageWidth + 60), pageWidth + 80],
  };
}

function purchaseOcrBoundedCellText(lines, bounds, field, pageWidth, startRatio, endRatio) {
  const range = bounds?.[field];
  if (range) return purchasePdfCellText(lines, range[0], range[1]);
  return purchaseOcrCellText(lines, startRatio, endRatio, pageWidth);
}

function sanitizePurchaseRowField(value) {
  return normalizePurchaseText(value)
    .replace(/\s+\d+\s+\d+(?:\.\d+)?\s*元\s*\/?\s*(?:双|件|个|盒|把|条|只)?(?:\s+[-+]?\d+(?:\.\d+)?){0,2}\s*$/i, " ")
    .replace(/\s+\d+(?:\.\d+)?\s*元\s*\/?\s*(?:双|件|个|盒|把|条|只)?(?:\s+[-+]?\d+(?:\.\d+)?){0,2}\s*$/i, " ")
    .replace(/[;\n\r]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function purchaseRowFromTextLine(lineText, fallbackIndex = 1) {
  const source = normalizePurchaseText(lineText)
    .replace(/[|｜]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!source || isPurchaseFooterLine({ items: [{ text: source }] }) || /序号\s*货号\s*货品名称/.test(source)) return null;
  const match = source.match(/^\s*([1-9]\d{0,2})\s+(.+)$/);
  if (!match) return null;
  const index = match[1];
  const rest = match[2].trim();
  if (!/(?:颜色|尺码|尺寸|规格|[1-9]\d*\s*(?:元|\/|件|个|盒|把|条)|[A-Za-z]{1,8}\d{1,6})/i.test(rest)) return null;

  const quantityPricePattern = /\s+([1-9]\d*)\s+([0-9]+(?:\.[0-9]+)?\s*(?:元\s*\/\s*)?(?:件|个|盒|把|条|双|只|\/)?)\s+([-+]?[0-9]+(?:\.[0-9]+)?)?\s+([0-9]+(?:\.[0-9]+)?)\s*$/i;
  const quantityMatch = rest.match(quantityPricePattern);
  const beforeQuantity = quantityMatch ? rest.slice(0, quantityMatch.index).trim() : rest;
  const nonSettlementText = beforeQuantity
    .replace(/[-+]?\d+(?:\.\d+)?/g, " ")
    .replace(/元|双|件|个|盒|把|条|只|单价|数量|优惠|金额|\/|[-—]/g, " ")
    .replace(/\s+/g, "")
    .trim();
  const hasProductSignal = /[A-Za-z]{1,8}\d{1,6}/i.test(beforeQuantity)
    || /颜色|尺码|尺寸|规格/.test(beforeQuantity)
    || /[\u4e00-\u9fff]{2,}/.test(nonSettlementText);
  if (!hasProductSignal) return null;
  const quantity = quantityMatch?.[1] || "";
  const price = quantityMatch?.[2] || "";
  const amount = quantityMatch?.[4] || "";

  const specMatch = beforeQuantity.match(/(?:颜色|尺码|尺寸|规格)\s*[:：]\s*.+$/i);
  const spec = specMatch ? specMatch[0].trim() : "";
  const beforeSpec = specMatch ? beforeQuantity.slice(0, specMatch.index).trim() : beforeQuantity;
  const codeMatch = beforeSpec.match(/^(\S{2,40})(?:\s+|$)([\s\S]*)$/);
  const code = sanitizePurchaseRowField(codeMatch?.[1] || "");
  const name = sanitizePurchaseRowField(codeMatch?.[2] || beforeSpec || `OCR row ${fallbackIndex}`);
  if (!code && !name && !spec) return null;
  return {
    index,
    code,
    name,
    spec: sanitizePurchaseRowField(spec || beforeQuantity),
    quantity: sanitizePurchaseRowField(quantity),
    price: sanitizePurchaseRowField(price),
    amount: sanitizePurchaseRowField(amount),
  };
}

function purchaseRowsFromOcrText(text) {
  const rows = [];
  String(text || "")
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .forEach((line, index) => {
      const row = purchaseRowFromTextLine(line, index + 1);
      if (row) rows.push(row);
    });
  return rows;
}

function purchaseRowsFromOcrWords(words) {
  const items = ocrWordsToPdfLikeItems(words);
  if (!items.length) return [];
  const lines = pdfTextLines(items);
  const allItems = lines.flatMap((line) => line.items || []);
  const maxX = Math.max(...allItems.map((item) => item.x), 0);
  const pageWidth = maxX > 0 ? maxX + 30 : 1000;
  const columnBounds = purchaseColumnBoundsFromLines(lines, pageWidth);
  const rowStarts = lines
    .map((line, index) => ({ line, index, rowNumber: purchaseLineRowNumberByRatio(line, pageWidth) }))
    .filter((entry) => entry.rowNumber);
  const rows = [];

  rowStarts.forEach((entry, rowStartIndex) => {
    const nextStart = rowStarts[rowStartIndex + 1]?.index ?? lines.length;
    const start = entry.index;
    let end = nextStart;
    while (end > start && isPurchaseFooterLine(lines[end - 1])) end -= 1;
    const rowLines = lines.slice(start, Math.max(start + 1, end));
    const row = {
      index: entry.rowNumber,
      code: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "code", pageWidth, 0.07, 0.21)),
      name: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "name", pageWidth, 0.21, 0.43)),
      spec: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "spec", pageWidth, 0.43, 0.58)),
      quantity: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "quantity", pageWidth, 0.58, 0.66).match(/[1-9]\d*/)?.[0] || ""),
      price: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "price", pageWidth, 0.66, 0.78)),
      amount: sanitizePurchaseRowField(purchaseOcrBoundedCellText(rowLines, columnBounds, "amount", pageWidth, 0.88, 1.02)),
    };
    if (!row.code && !row.name && !row.spec) {
      const fromText = purchaseRowFromTextLine(rowLines.map(pdfLineText).join(" "), rows.length + 1);
      if (fromText) rows.push(fromText);
      return;
    }
    rows.push(row);
  });
  return rows;
}

function structuredPurchaseRowsFromOcrResult(result, text) {
  const wordRows = purchaseRowsFromOcrWords(result?.data?.words || result?.words || []);
  if (wordRows.length) return serializePurchaseRows(wordRows);
  return serializePurchaseRows(purchaseRowsFromOcrText(text));
}

function purchaseRowsFromPdfItems(items) {
  const lines = pdfTextLines(items);
  const rowStarts = lines
    .map((line, index) => ({ line, index, rowNumber: purchaseLineRowNumber(line) }))
    .filter((entry) => entry.rowNumber);
  const rows = [];

  rowStarts.forEach((entry, rowStartIndex) => {
    const nextStart = rowStarts[rowStartIndex + 1]?.index ?? lines.length;
    let start = entry.index;
    if (start > 0) {
      const previous = lines[start - 1];
      if (!purchaseLineRowNumber(previous) && !isPurchaseTableHeaderLine(previous) && !isPurchaseFooterLine(previous)) {
        start -= 1;
      }
    }
    let end = nextStart;
    if (nextStart < lines.length) {
      const previousToNext = lines[nextStart - 1];
      if (previousToNext && !purchaseLineRowNumber(previousToNext) && !isPurchaseTableHeaderLine(previousToNext) && !isPurchaseFooterLine(previousToNext)) {
        end = nextStart - 1;
      }
    }
    while (end > start && isPurchaseFooterLine(lines[end - 1])) end -= 1;
    const rowLines = lines.slice(start, Math.max(start + 1, end));
    const index = entry.rowNumber;
    const code = purchasePdfCellText(rowLines, 70, 140);
    const name = purchasePdfCellText(rowLines, 140, 255);
    const spec = purchasePdfCellText(rowLines, 255, 335);
    const quantity = purchasePdfCellText(rowLines, 335, 370).match(/[1-9]\d*/)?.[0] || "";
    const price = purchasePdfCellText(rowLines, 370, 440);
    const amount = purchasePdfCellText(rowLines, 490, 570);
    if (!index || (!code && !name && !spec)) return;
    rows.push({
      index,
      code: sanitizePurchaseRowField(code),
      name: sanitizePurchaseRowField(name),
      spec: sanitizePurchaseRowField(spec),
      quantity: sanitizePurchaseRowField(quantity),
      price: sanitizePurchaseRowField(price),
      amount: sanitizePurchaseRowField(amount),
    });
  });

  return rows;
}

function serializePurchaseRows(rows) {
  return (rows || []).map((row) => [
    "PURCHASE_ROW:",
    `index=${row.index}`,
    `code=${row.code}`,
    `name=${row.name}`,
    `spec=${row.spec}`,
    `quantity=${row.quantity}`,
    row.price && `price=${row.price}`,
    row.amount && `amount=${row.amount}`,
  ].filter(Boolean).join("; ")).join("\n");
}

async function readPdfText(file) {
  if (!file) return "";
  const pdfLib = await loadPdfJs();
  if (!pdfLib) {
    return `Uploaded purchase PDF: ${file.name}`;
  }
  pdfLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER_URL;
  const buffer = await file.arrayBuffer();
  const pdf = await pdfLib.getDocument({ data: buffer }).promise;
  const pages = [];
  const purchaseRows = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const page = await pdf.getPage(pageNumber);
    const content = await page.getTextContent();
    pages.push(content.items.map((item) => item.str).join(" "));
    purchaseRows.push(...purchaseRowsFromPdfItems(content.items));
  }
  const structuredRows = serializePurchaseRows(purchaseRows);
  return [pages.join("\n"), structuredRows].filter(Boolean).join("\n");
}

function extractFirstMatch(text, patterns) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) return match[1].trim();
  }
  return "";
}

function extractDimensions(text) {
  if (hasUmbrellaDimensionSignal(text)) {
    return extractUmbrellaDimensions(text);
  }
  const dimensions = [];
  const sizePatterns = [
    /(?:Top Width|top width|顶部宽度|上宽|Length|length|长(?:度)?|直径|Diameter|diameter)[:：]?\s*([0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米)(?:\s*\/\s*[0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米))?)/i,
    /(?:Side Length|side length|Width|width|宽(?:度)?|高度|侧边)[:：]?\s*([0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米)(?:\s*\/\s*[0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米))?)/i,
    /(?:Bottom Width|bottom width|Height|height|高(?:度)?|底部宽度|底宽)[:：]?\s*([0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米))/i,
    /(?:Weight|weight|单片重量|克重|重量|净重|约重)[:：]?\s*([0-9.]+\s*(?:g\/sheet|g|kg|克\/片|克|千克))/i,
    /(?:Capacity|capacity|Volume|volume|容量|容积)[:：]?\s*([0-9.]+\s*(?:ml|mL|l|L|oz|毫升|升))/i,
  ];
  const labels = ["Length", "Width", "Height", "Weight", "Capacity"];
  sizePatterns.forEach((pattern, index) => {
    const value = normalizeDimensionUnit(extractFirstMatch(text, [pattern]));
    if (value) dimensions.push(`${labels[index]}: ${value}`);
  });
  const composite = normalizeDimensionUnit(extractFirstMatch(text, [
    /(?:尺寸|规格|size|dimensions?|product size)[^\d]{0,12}([0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米)?\s*[x×*]\s*[0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米)?(?:\s*[x×*]\s*[0-9.]+\s*(?:cm|mm|in|厘米|公分|毫米)?)?)/i,
  ]));
  if (composite) {
    const unit = composite.match(/\b(cm|mm|in)\b/i)?.[1] || "cm";
    const parts = composite.match(/[0-9.]+/g) || [];
    if (parts[0] && !dimensions.some((item) => /^Length:/i.test(item))) dimensions.push(`Length: ${parts[0]} ${unit}`);
    if (parts[1] && !dimensions.some((item) => /^Width:/i.test(item))) dimensions.push(`Width: ${parts[1]} ${unit}`);
    if (parts[2] && !dimensions.some((item) => /^Height:/i.test(item))) dimensions.push(`Height: ${parts[2]} ${unit}`);
  }
  dimensions.push(...extractUmbrellaDimensions(text));
  return uniquePromptItems(dimensions);
}

function normalizeDimensionUnit(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .replace(/厘米|公分/gi, " cm")
    .replace(/毫米/gi, " mm")
    .replace(/克/gi, " g")
    .replace(/毫升/gi, " ml")
    .replace(/升/gi, " L")
    .replace(/千克/gi, " kg")
    .replace(/\s*(cm|mm|in|g|kg|ml|mL|L|oz)\b/gi, " $1")
    .trim();
}

function extractUmbrellaDimensions(text) {
  const source = String(text || "");
  if (!hasUmbrellaDimensionSignal(source)) return [];
  const candidates = [
    ["Folded Size", [
      /(?:收纳后|收纳|折叠后|折后|合拢后|折叠尺寸|收纳尺寸)[^\d]{0,12}([0-9.]+\s*(?:cm|厘米|公分|mm|毫米|in)(?:\s*[x×*]\s*[0-9.]+\s*(?:cm|厘米|公分|mm|毫米|in)){0,2})/i,
      /(?:folded|closed|compact)\s*(?:size|length)?[^\d]{0,12}([0-9.]+\s*(?:cm|mm|in)(?:\s*[x×*]\s*[0-9.]+\s*(?:cm|mm|in)){0,2})/i,
    ]],
    ["Open Diameter", [
      /(?:伞面直径|打开直径|展开直径|展开后直径|直径)[^\d]{0,12}([0-9.]+\s*(?:cm|厘米|公分|mm|毫米|in))/i,
      /(?:open|opened|canopy)\s*(?:diameter|width)?[^\d]{0,12}([0-9.]+\s*(?:cm|mm|in))/i,
    ]],
    ["Open Height", [
      /(?:伞高|打开高度|展开高度|总高)[^\d]{0,12}([0-9.]+\s*(?:cm|厘米|公分|mm|毫米|in))/i,
      /(?:open|opened)\s*(?:height|length)[^\d]{0,12}([0-9.]+\s*(?:cm|mm|in))/i,
    ]],
    ["Weight", [
      /(?:重量|净重|约重|克重)[^\d]{0,12}([0-9.]+\s*(?:g|克))/i,
      /(?:weight|net weight)[^\d]{0,12}([0-9.]+\s*g)/i,
    ]],
  ];
  const seen = new Set();
  const dimensions = [];
  candidates.forEach(([label, patterns]) => {
    const value = normalizeDimensionUnit(extractFirstMatch(source, patterns));
    if (!value) return;
    const key = `${label}:${value}`.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    dimensions.push(`${label}: ${value}`);
  });
  return dimensions;
}

function hasUmbrellaDimensionSignal(text) {
  return /伞|umbrella|收纳尺寸|折叠尺寸|折叠后|折后|合拢后|伞面直径|打开直径|展开直径|展开后直径|展开高度|打开高度|伞高|folded size|closed size|compact size|open diameter|canopy diameter|open height|opened height/i.test(String(text || ""));
}

function inferProductName(text) {
  const supplierTitle = extractFirstMatch(text, [/PRODUCT_TITLE:\s*([^\n]+)/i]);
  if (supplierTitle && !isMachineProductText(supplierTitle)) return translateProductTitleWords(supplierTitle) || supplierTitle;
  const rawSpecName = readableNameFromRawSpec(extractFirstMatch(text, [/rawSpec\s*=\s*([^;\n|]+)/i, /SKU_OPTION\s*[:;]+([^\n]+)/i]));
  if (rawSpecName) return rawSpecName;
  const explicit = extractFirstMatch(text, [
    /(?:Product Name|产品名称|品名|商品名称)[:：]\s*([^。；;.\n|]{2,80})/i,
    /(?:Coffee Filters?|coffee filter paper|filter paper)/i,
  ]);
  const translatedExplicit = translateProductTitleWords(explicit);
  if (translatedExplicit) return translatedExplicit;
  const purchaseRowName = purchaseRowFieldValue(String(text || "").match(/PURCHASE_ROW\s*:\s*([^\n]+)/i)?.[1] || "", "name");
  const translatedPurchaseName = translateProductTitleWords(purchaseRowName);
  if (translatedPurchaseName) return translatedPurchaseName;
  return "";
}

function isFlowerWrappingPaperText(text) {
  return /flower\s+wrapping\s+paper|floral\s+wrapping\s+paper|bouquet\s+wrapping|bouquet\s+wrap|floral\s+wrap|gift\s+wrap(?:ping)?\s+paper|wrapping\s+paper|tissue\s+paper|cellophane|包装纸|包花纸|花束包装|鲜花包装|花艺包装|礼品包装纸|花纸|花束纸|雪梨纸|欧雅纸|雾面纸|玻璃纸/i.test(String(text || ""));
}

function inferUseScene(text) {
  const source = String(text || "");
  const explicit = [];
  [
    /(?:Use Scene|Usage Scenario|Use Occasion|Occasion|Recommended Uses? For Product|Scene|场景|使用场景|适用场景|用途场景)[:：]\s*([^\n。；;|]{2,120})/gi,
    /(?:适用于|适合用于|可用于)\s*([^\n。；;|]{2,80})/gi,
  ].forEach((pattern) => {
    Array.from(source.matchAll(pattern)).forEach((match) => {
      const clean = cleanFieldDisplayValue(match[1]);
      if (clean && !/^\d+$/.test(clean)) explicit.push(clean);
    });
  });
  return uniquePromptItems(explicit).slice(0, 4).join(" / ");
}

function umbrellaCompatibleUseText(text) {
  return "";
}

function umbrellaStructureText(text) {
  if (!/伞|umbrella/i.test(text)) return "";
  const parts = [];
  if (/扁|flat/i.test(text)) parts.push("flat compact folded profile");
  if (/([1-9]\d?)骨|rib/i.test(text)) parts.push("reinforced rib frame");
  if (/六折|6-fold|six-fold/i.test(text)) parts.push("six-fold compact construction");
  if (/伞骨|加固|reinforced|windproof|防风/i.test(text)) parts.push("reinforced wind-resistant ribs");
  return compactPromptItems(parts, "compact folding umbrella construction", 4);
}

function genericStructureText(text) {
  const source = String(text || "");
  const parts = [];
  if (/拉力带|拉力片|弹力带|阻力带|resistance\s+band|exercise\s+band/i.test(source)) {
    parts.push("flat resistance band sheet");
  }
  if (/片状|sheet|flat/i.test(source)) parts.push("flat sheet form");
  if (/带状|strap|band/i.test(source)) parts.push("strap-like band form");
  if (/加固|reinforced/i.test(source)) parts.push("reinforced construction");
  if (/一体|integrated|one[-\s]?piece/i.test(source)) parts.push("one-piece construction");
  return compactPromptItems(parts, "", 4);
}

function umbrellaDetailText(text, dimensionList = "") {
  if (!/伞|umbrella/i.test(text)) return "";
  const details = [
    dimensionList && cleanTokenValue(dimensionList),
    /小巧|便携|收纳|compact|portable/i.test(text) && "compact folded body for small-bag storage",
    /防晒|遮阳|UV|UPF|紫外线/i.test(text) && "sun-shade canopy surface",
    /防雨|晴雨|waterproof|rain/i.test(text) && "rain-ready canopy with water-beading surface",
    /伞骨|加固|防风|reinforced|windproof/i.test(text) && "reinforced rib detail",
  ];
  return compactPromptItems(details, "", 5);
}

function sockSellingPointCandidates(text, material, attrs = {}) {
  const source = [
    text,
    material,
    attrs.Function,
    attrs.Material,
    attrs.Technology,
    attrs.SpecialCraft,
    attrs["Sock Height"],
    attrs.Seam,
    attrs.Weaving,
  ].filter(Boolean).join(" ");
  const candidates = [];
  const add = (key, value, priority) => {
    if (value) candidates.push({ key, value, priority });
  };

  if (hasCrossStrapDesign(source) && hasFiveToeDesign(source)) {
    add("design", "3D cross-strap and five-toe separated design", 10);
  } else {
    if (hasCrossStrapDesign(source)) add("cross-strap", "3D cross-strap design", 10);
    if (hasFiveToeDesign(source)) add("five-toe", "five-toe separated design", 9);
  }
  if (/精\s*梳\s*棉|combed\s+cotton/i.test(source)) {
    add("material", "premium combed cotton comfort", 8);
  } else if (/棉|cotton/i.test(source)) {
    add("material", "breathable cotton comfort", 5);
  }
  if (/防滑|硅胶|点胶|胶印|anti.?slip|non[-\s]?slip|grip|printed?\s+grip/i.test(source)) {
    add("grip", "anti-slip grip sole", 7);
  }
  if (/中筒|mid[-\s]?calf/i.test(source)) add("coverage", "mid-calf coverage", 6);
  if (/长筒|高筒|long sock|knee|over[-\s]?the[-\s]?calf/i.test(source)) add("coverage", "long sock coverage", 6);
  if (/无骨|手工无骨|seamless|hand[-\s]?linked/i.test(source)) add("seam", "seamless hand-linked toe comfort", 6);
  if (/吸汗|sweat|moisture/i.test(source)) add("sweat", "sweat-absorbing workout comfort", 4);
  if (/防摩擦|anti[-\s]?friction|friction/i.test(source)) add("friction", "anti-friction comfort", 4);
  if (/单针|single[-\s]?needle/i.test(source)) add("knit", "single-needle knit texture", 3);
  if (/elastic|高弹|橡筋/i.test(attrs.SpecialCraft || source)) add("elastic", "high-elastic comfortable cuff", 4);
  if (/soft|柔软|细腻/i.test(attrs.SpecialCraft || source)) add("soft", "soft and delicate fabric texture", 3);
  if (/antibacterial|deodorizing|阻菌|抗菌|防臭/i.test(attrs.SpecialCraft || source)) add("deodorizing", "antibacterial deodorizing comfort", 2);

  const selected = [];
  const usedKeys = new Set();
  candidates
    .sort((left, right) => right.priority - left.priority)
    .forEach((candidate) => {
      const key = sellingPointKey(candidate.value) || candidate.key;
      if (usedKeys.has(key)) return;
      if (selected.some((item) => promptItemsOverlap(item.value, candidate.value))) return;
      selected.push(candidate);
      usedKeys.add(key);
    });
  return selected.map((candidate) => candidate.value);
}

function umbrellaSellingPointCandidates(text, attrs = {}) {
  const source = [text, attrs.Function, attrs.Technology, attrs.SpecialCraft, attrs.Size].filter(Boolean).join(" ");
  const candidates = [];
  const add = (key, value, priority) => {
    if (value) candidates.push({ key, value, priority });
  };
  if (/收纳|折叠|小巧|迷你|口袋|便携|随身|轻便|轻巧|compact|portable|pocket|travel/i.test(source)) {
    add("compact", "compact portable folded size", 10);
  }
  if (/轻量|轻便|轻巧|重量|净重|约重|lightweight/i.test(source)) {
    add("lightweight", "lightweight carry design", 9);
  }
  if (/防晒|遮阳|防紫外|紫外线|UPF|UV|black胶|黑胶|隔热/i.test(source)) {
    add("uv", "sun and UV protection canopy", 8);
  }
  if (/防雨|雨伞|晴雨|拒水|防水|waterproof|rain/i.test(source)) {
    add("rain", "rain-ready waterproof canopy", 7);
  }
  if (/防风|抗风|加固|伞骨|骨架|windproof|reinforced|ribs?/i.test(source)) {
    add("windproof", "reinforced wind-resistant ribs", 6);
  }
  return candidates
    .sort((left, right) => right.priority - left.priority)
    .map((candidate) => candidate.value);
}

function genericDetailSellingPointCandidates(text) {
  const source = [String(text || ""), ocrCompactText(text)].join("\n");
  const candidates = [];
  const add = (pattern, value) => {
    if (pattern.test(source)) candidates.push(value);
  };
  add(/9\s*M|9米|9\s*米/i, "9 m stretch range");
  add(/不惧断裂|不断裂|防断|抗拉防断|抗拉|fracture|break|tear/i, "break-resistant performance");
  add(/均匀拉伸|不变形|deformation/i, "even stretch without deformation");
  add(/拉伸\s*3\s*倍|3\s*倍|three\s*times/i, "stretches to about 3x length");
  add(/练遍全身|全身|full\s*body/i, "full-body workout coverage");
  add(/安全更耐用|耐用|durable/i, "durable everyday use");
  add(/便携|轻便|轻巧|小巧|收纳|portable|lightweight|compact/i, "portable compact design");
  add(/防滑|止滑|抓地|anti.?slip|non.?slip|grip/i, "anti-slip grip");
  add(/防水|防雨|waterproof|water.?resistant/i, "water-resistant protection");
  add(/防晒|遮阳|紫外线|UV|UPF/i, "sun and UV protection");
  add(/防风|抗风|加固|reinforced|windproof/i, "reinforced stable construction");
  add(/柔软|soft/i, "soft hand feel");
  add(/透气|breathable/i, "breathable comfort");
  add(/吸汗|sweat|moisture/i, "sweat-absorbing comfort");
  add(/抗菌|防臭|antibacterial|deodor/i, "antibacterial deodorizing comfort");
  add(/高弹|弹力|elastic|stretch/i, "high elasticity");
  add(/易清洁|可水洗|easy.?clean|washable/i, "easy-clean washable design");
  add(/稳固|牢固|承重|省力|stable|sturdy|load.?bearing/i, "stable sturdy support");
  add(/多场景|多用途|满足不同需求|multi.?use/i, "multi-use versatility");
  return uniqueSellingPoints(candidates, 8);
}

function isResistanceBandText(text) {
  return /拉力带|拉力片|弹力带|阻力带|resistance\s+band|exercise\s+band|workout\s+band/i.test(String(text || ""));
}

function resistanceBandSellingPointCandidates(text, material) {
  const source = [text, material].filter(Boolean).join(" ");
  const candidates = [];
  if (/TPE|tpe|热塑性弹性体/i.test(source)) {
    candidates.push("TPE thermoplastic elastomer material");
  }
  if (/拉伸|阻力|拉力|弹力|stretch|resistance/i.test(source)) {
    candidates.push("stretching and resistance training use");
  }
  if (/训练|健身|workout|exercise|home\s+gym|strength|therapy|康复|理疗/i.test(source)) {
    candidates.push("fitness and home training use");
  }
  return uniqueSellingPoints(candidates, 6);
}

function categorySpecificSellingPointCandidates(text, material, attrs = {}) {
  return uniqueSellingPoints([
    ...(isSockFamilyText(text) ? sockSellingPointCandidates(text, material, attrs) : []),
    ...(/伞|umbrella/i.test(text) ? umbrellaSellingPointCandidates(text, attrs) : []),
    ...(isResistanceBandText(text) ? resistanceBandSellingPointCandidates(text, material) : []),
  ], 10);
}

function inferSellingPoints(text, material, limit = 2) {
  const attrs = supplierAttributeMap(text);
  const genericDetailPoints = genericDetailSellingPointCandidates(text);
  const categoryPoints = categorySpecificSellingPointCandidates(text, material, attrs);
  const feature1 = /wood pulp|原木浆|unbleached|未漂白|natural/i.test(text)
    ? "natural unbleached material"
    : cleanFieldDisplayValue(material) || "";
  const feature2 = /filter|过滤|smooth|均匀|flow|brewing|萃取/i.test(text) ? "smooth filtration performance" : "";
  const points = uniqueSellingPoints([
    ...genericDetailPoints,
    ...categoryPoints,
    feature1,
    feature2,
    material,
  ], limit);
  return {
    feature1: points[0] || feature1,
    feature2: points[1] || feature2,
    points,
  };
}

function normalizeSkuText(text) {
  return String(text)
    .replace(/亚马逊定制/g, " ")
    .replace(/盒装/g, " box ")
    .replace(/片\/盒|片每包|片包|片/g, " pcs ")
    .replace(/扇形\s*U?\s*02/gi, " fan 02 ")
    .replace(/扇形\s*04/gi, " fan 04 ")
    .replace(/V形\s*02|V02|V 02/gi, " V02 ")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizePackageCount(value) {
  const count = String(value).match(/100|200/)?.[0];
  return count ? `${count} pcs box` : "";
}

function productSpecForToken(token) {
  const normalized = token.toLowerCase();
  if (normalized.includes("v02")) {
    return {
      key: "v02",
      spec: "V02 cone coffee filter",
      sizeCode: "V02",
      cupRange: "1-4 cup pour-over brewing",
      fit: "V60-02 style cone dripper",
    };
  }
  if (normalized.includes("fan 04") || normalized.includes("#04")) {
    return {
      key: "u04",
      spec: "fan-shaped 04 coffee filter",
      sizeCode: "Fan 04",
      cupRange: "8-12 cup drip coffee maker",
      fit: "#4 cone or fan-shaped drip coffee maker",
    };
  }
  return {
    key: "u02",
    spec: "fan-shaped 02 / U02 coffee filter",
    sizeCode: "Fan 02 / U02",
    cupRange: "2-6 cup drip or pour-over brewing",
    fit: "#2 fan-shaped dripper or small drip coffee maker",
  };
}

function normalizeCupRange(value) {
  const match = String(value || "").match(/([0-9]+\s*-\s*[0-9]+)\s*(cups?|人份)/i);
  if (!match) return "";
  return `${match[1].replace(/\s+/g, "")} cups`;
}

function inferCupRangeForSpec(text, item) {
  const normalized = normalizeSkuText(text);
  const candidateTokens = {
    v02: ["V02", "V 02", "V60", "V-shaped 02"],
    u02: ["fan 02", "U02", "U102", "#02"],
    u04: ["fan 04", "#04"],
  }[item.key] || [];

  for (const token of candidateTokens) {
    const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const patterns = [
      new RegExp(`${escaped}[\\s\\S]{0,120}?([0-9]+\\s*-\\s*[0-9]+\\s*(?:cups?|人份))`, "i"),
      new RegExp(`([0-9]+\\s*-\\s*[0-9]+\\s*(?:cups?|人份))[\\s\\S]{0,120}?${escaped}`, "i"),
    ];
    const value = normalizeCupRange(extractFirstMatch(normalized, patterns));
    if (value) return value;
  }

  return item.cupRange || "";
}

function fallbackDimensionsForSpec(item, combinedText) {
  if (!/coffee filters|咖啡滤纸|V02|扇形|U02|#04/i.test(combinedText)) {
    return {};
  }

  const normalizedKey = item.key || productSpecForToken(item.sizeCode || item.spec || "").key;
  if (normalizedKey === "v02") {
    return {
      topWidth: "16 cm",
      sideLength: "12 cm / 11.6 cm",
      bottomWidth: "",
      weight: "1.12 g/sheet",
      dimensionList: "[VERIFIED_DIMENSIONS: Top Width: 16 cm; Side Length: 12 cm / 11.6 cm; Weight: 1.12 g/sheet]",
      source: "1688 detail image confirmed single-filter dimensions",
    };
  }
  if (normalizedKey === "u02") {
    return {
      topWidth: "16.5 cm",
      sideLength: "9 cm / 9.5 cm",
      bottomWidth: "5 cm",
      weight: "1.15 g/sheet",
      dimensionList: "[VERIFIED_DIMENSIONS: Top Width: 16.5 cm; Side Length: 9 cm / 9.5 cm; Bottom Width: 5 cm; Weight: 1.15 g/sheet]",
      source: "1688 detail image confirmed single-filter dimensions",
    };
  }

  return {};
}

function dimensionValueByLabels(dimensionsText, labels) {
  const source = String(dimensionsText || "");
  for (const label of labels) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const value = extractFirstMatch(source, [new RegExp(`${escaped}:\\s*([^;]+)`, "i")]);
    if (value) return value;
  }
  return "";
}

function thirdDimensionLabel(context) {
  return /thickness|厚|0\.[0-9]+\s*mm|片状|sheet|band|strap|拉力带|弹力带|阻力带/i.test(String(context || "")) ? "Thickness" : "Height";
}

function supplierSkuMap(text) {
  const map = new Map();
  extractSupplierSkuOptions(text).forEach((option) => {
    if (!option.model) return;
    const modelKey = option.model.toUpperCase();
    if (!map.has(modelKey)) map.set(modelKey, []);
    map.get(modelKey).push(option);
  });
  return map;
}

function supplierAttributeMap(text) {
  const attrs = {};
  const source = String(text || "");
  for (const match of source.matchAll(/PRODUCT_ATTRIBUTE:\s*([^=\n]+)=([^\n]+)/gi)) {
    const key = match[1].trim();
    const value = translateAttributeValue(key, match[2].trim());
    if (!value) continue;
    if (!attrs[key] || shouldReplaceAttributeValue(key, attrs[key], value)) attrs[key] = value;
  }
  const productDetailText = productAttributeSourceText(
    ...Array.from(source.matchAll(/1688 image OCR text:\s*([\s\S]*?)(?=\n(?:PRODUCT_TITLE|PRODUCT_ATTRIBUTE|SKU_OPTION|Source HTML file|Purchase order image OCR text|1688 image OCR text)\s*:|$)/gi)).map((match) => match[1]),
  );
  Object.entries(extractProductDetailAttributes(productDetailText)).forEach(([key, value]) => {
    if (value && (!attrs[key] || shouldReplaceAttributeValue(key, attrs[key], value))) attrs[key] = value;
  });
  if (!productDetailText) {
    Object.entries(extractProductDetailAttributes(productAttributeSourceText(source))).forEach(([key, value]) => {
      if (value && (!attrs[key] || shouldReplaceAttributeValue(key, attrs[key], value))) attrs[key] = value;
    });
  }
  return attrs;
}

function stripInternalExtractionLines(text) {
  return String(text || "")
    .split(/\n+/)
    .filter((line) => !/^\s*(?:PRODUCT_ATTRIBUTE|SKU_OPTION|PRODUCT_TITLE|Source HTML file|Purchase order image OCR text)\s*:/i.test(line))
    .join("\n");
}

function stripImageOcrBlocks(text) {
  return String(text || "")
    .replace(/\n?1688 image OCR text:\s*[\s\S]*?(?=\n(?:PRODUCT_TITLE|PRODUCT_ATTRIBUTE|SKU_OPTION|Source HTML file|Purchase order image OCR text|1688 image OCR text)\s*:|$)/gi, "\n")
    .trim();
}

function productIdentitySourceText(purchaseText, supplierText) {
  return [
    purchaseText,
    stripImageOcrBlocks(supplierText),
  ].filter(Boolean).join(" ");
}

function productAttributeSourceText(...parts) {
  return parts
    .filter(Boolean)
    .join("\n")
    .split(/\n+/)
    .map((line) => line.trim())
    .filter((line) => {
      if (!line) return false;
      if (/^\s*PRODUCT_ATTRIBUTE\s*:/i.test(line)) return true;
      if (isProductSellingPointText(line)) return true;
      if (productDetailLabelScore(line) >= 2) return true;
      if (isFactoryOrServiceImageText(line) && productDetailLabelScore(line) < 2) return false;
      if (isCommerceOrRecommendationText(line) && productDetailLabelScore(line) < 2 && productFeatureTextScore(line) < 3) return false;
      return isProductInfoImageText(line) && productFeatureTextScore(line) >= 2;
    })
    .join("\n");
}

function shouldReplaceAttributeValue(key, current, next) {
  const currentClean = cleanFieldDisplayValue(current);
  const nextClean = cleanFieldDisplayValue(next);
  if (!nextClean) return false;
  if (!currentClean) return true;
  if (/^Material$/i.test(key)) {
    const currentHasPercent = /%/.test(currentClean);
    const nextHasPercent = /%/.test(nextClean);
    if (nextHasPercent && !currentHasPercent) return true;
  }
  if (/^Weight$/i.test(key)) {
    return /^\.\s*g$/i.test(currentClean) || /[0-9]/.test(nextClean) && !/[0-9]/.test(currentClean);
  }
  return nextClean.length > currentClean.length && !currentClean.includes(nextClean);
}

function genericProductSpecForModel(model, combinedText) {
  const isYogaSock = isYogaSockText(combinedText);
  const isSock = isSockFamilyText(combinedText);
  if (isYogaSock) return `${model} five-toe yoga grip socks`;
  if (isSock) return `${model} socks`;
  return `${model} product`;
}

function extractProductUnitCount(text) {
  const source = String(text || "");
  const value = extractFirstMatch(source, [
    /(?:套装|组合|set|pack)[^\n。；;]{0,24}?([1-9]\d*|[一二两三四五六七八九十])\s*(?:双|pairs?|件|pcs|片|只|个)/i,
    /([1-9]\d*|[一二两三四五六七八九十])\s*(?:双|pairs?|件|pcs|片|只|个)\s*(?:装|套装|组合|set|pack)/i,
    /(?:contains?|includes?|内含|包含)[^\n。；;]{0,24}?([1-9]\d*|[一二两三四五六七八九十])\s*(?:双|pairs?|件|pcs|片|只|个)/i,
  ]);
  if (!value) return "";
  const normalizedValue = chineseCountToNumber(value) || value;
  const unit = extractFirstMatch(source, [
    new RegExp(`${value}\\s*(双|pairs?|件|pcs|片|只|个)`, "i"),
  ]) || "pcs";
  const normalizedUnit = /双|pair/i.test(unit) ? "pairs" : /片/.test(unit) ? "pcs" : /件|只|个|pcs/i.test(unit) ? "pcs" : unit;
  return `${normalizedValue} ${normalizedUnit}`;
}

function chineseCountToNumber(value) {
  const clean = String(value || "").trim();
  if (/^\d+$/.test(clean)) return "";
  const map = {
    一: 1,
    二: 2,
    两: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9,
    十: 10,
  };
  return map[clean] ? String(map[clean]) : "";
}

function isSameColorName(left, right) {
  const leftRaw = String(left || "").trim();
  const rightRaw = String(right || "").trim();
  if (!leftRaw || !rightRaw) return false;
  return leftRaw === rightRaw || canonicalColorKey(leftRaw) === canonicalColorKey(rightRaw);
}

function selectSupplierOption(options, color, usedOptionKeys) {
  if (!options.length) return {};
  if (color) {
    const exact = options.find((option) => option.color && isSameColorName(option.color, color));
    if (exact) return exact;
  }
  const unused = options.find((option) => {
    const key = `${option.model}-${option.color || ""}-${option.size || ""}`;
    return !usedOptionKeys.has(key);
  });
  return unused || options[0] || {};
}

function addGenericPurchaseItem(items, seen, usedSupplierOptions, suppliers, combinedText, {
  model,
  color = "",
  quantity = "",
  size = "",
  price = "",
  rowKey = "",
  unitCount = "",
  allowSupplierColorFallback = false,
}) {
  if (!model) return;
  const normalizedModel = model.toUpperCase();
  const supplierOptions = suppliers.get(normalizedModel) || [];
  const exactOption = color
    ? supplierOptions.find((option) => option.color && isSameColorName(option.color, color))
    : null;
  const fallbackOption = exactOption || selectSupplierOption(supplierOptions, color, usedSupplierOptions);
  const supplierColorIsSafe = allowSupplierColorFallback || supplierOptions.length === 1;
  const finalColor = color || (supplierColorIsSafe ? fallbackOption.color : "") || "";
  const matchedOption = finalColor && fallbackOption.color && isSameColorName(fallbackOption.color, finalColor)
    ? fallbackOption
    : {};
  const finalSize = size || matchedOption.size || "";
  const optionKey = `${matchedOption.model || normalizedModel}-${matchedOption.color || ""}-${matchedOption.size || ""}`;
  const key = rowKey || (finalColor ? `${normalizedModel}-${canonicalColorKey(finalColor)}` : `${normalizedModel}-${items.length}-${quantity || ""}`);
  if (seen.has(key)) return;
  seen.add(key);
  if (matchedOption.model) usedSupplierOptions.add(optionKey);
  const rowLabel = !finalColor && /^row-\d+$/i.test(rowKey) ? `purchase ${rowKey.replace("row-", "row ")}` : "";
  const displayColor = displayColorName(finalColor, matchedOption.colorEnglish);
  const specParts = [displayColor || colorName(finalColor) || finalColor, cleanFieldDisplayValue(finalSize), rowLabel].filter(Boolean);
  items.push({
    key: normalizedModel.toLowerCase(),
    purchaseRowKey: rowKey,
    model: normalizedModel,
    color: finalColor,
    displayColor,
    colorEnglish: finalColor ? colorName(finalColor) || matchedOption.colorEnglish || "" : "",
    spec: specParts.join(" / "),
    sizeCode: specParts.join(" / "),
    pack: unitCount || "",
    productUnitCount: unitCount || "",
    quantity,
    price,
    fit: "",
    dims: matchedOption.dims || {},
    supplierOption: matchedOption,
    inferredColorFromSupplier: !color && Boolean(finalColor),
  });
}

function extractIndexedPurchaseRows(source) {
  const items = [];
  const seenRows = new Set();
  let lastModel = "";
  purchaseOptionRowSegments(source).forEach((segment) => {
    const rowNumber = extractFirstMatch(segment, [/^\s*([1-9]\d?)\s+/]);
    if (!rowNumber || seenRows.has(rowNumber)) return;
    const purchaseOption = purchaseOptionFromSegment(segment);
    const modelMatch = segment.match(/(?:^|\s)(?:[1-9]\d?\s+)?(?:阿里)?\s*([A-Z]{1,4}\d{2,5})(?:-[A-Z]{1,4}\d{2,5})?(?:\s+([A-Z]{1,4}\d{2,5}))?/i);
    const model = (modelMatch?.[2] || modelMatch?.[1] || purchaseOption.model || lastModel || "").toUpperCase();
    if (!model) return;
    lastModel = model;
    seenRows.add(rowNumber);
    items.push({
      rowKey: `row-${rowNumber}`,
      model,
      quantity: extractFirstMatch(segment, [
        /(?:^|\s)([1-9]\d*)\s+[0-9]+(?:\.[0-9]+)?\s*\/\s*[-+]?[0-9]+(?:\.[0-9]+)?/i,
        /(?:数量|Qty|Quantity)\s*[:：]?\s*([1-9]\d*)/i,
      ]),
      unitCount: extractProductUnitCount(segment),
      color: purchaseOption.color,
      size: extractPurchaseSize(segment),
      segment,
    });
  });
  return items;
}

function looseSequencePattern(value) {
  return String(value || "")
    .replace(/\s+/g, "")
    .split("")
    .map((char) => char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join("\\s*");
}

function colorAliasPatterns(value) {
  return colorAliasValues(value)
    .map((alias) => String(alias).replace(/\s+/g, ""))
    .filter(Boolean)
    .map((alias) => looseSequencePattern(alias));
}

function purchaseSegmentQuantity(segment, matchedText) {
  const index = String(segment || "").indexOf(matchedText || "");
  const tail = index > -1 ? String(segment).slice(index + String(matchedText || "").length) : String(segment || "");
  return tail.match(/^\s*([1-9]\d*)\s+[0-9]+(?:\.[0-9]+)?/)?.[1] || "";
}

function extractPurchaseSize(segment) {
  return cleanFieldDisplayValue(extractFirstMatch(segment, [
    /尺码\s*[:：]\s*(one\s+size|free\s+size)(?=\s|$)/i,
    /尺码\s*[:：]\s*([^\s,，;；。]{1,16})/i,
  ]));
}

function purchaseColorWindow(segment) {
  const source = normalizeModelText(segment || "");
  const priceIndex = source.search(/\s[1-9]\d*\s+[0-9]+(?:\.[0-9]+)?\s*(?:元|\/|双|pcs|件|只|个)/i);
  const beforePrice = priceIndex > -1 ? source.slice(0, priceIndex) : source;
  const colorIndex = beforePrice.search(/颜色\s*[:：]/i);
  if (colorIndex > -1) {
    return beforePrice.slice(colorIndex, colorIndex + 180);
  }
  const rowModel = beforePrice.match(/(?:^|\s)[1-9]\d?\s+(?:阿里)?\s*[A-Z]{1,4}\d{2,5}\b/i);
  if (rowModel) {
    return beforePrice.slice(rowModel.index || 0, (rowModel.index || 0) + 220);
  }
  return beforePrice.slice(0, 220);
}

function purchaseOptionFromSegment(segment) {
  const source = purchaseColorWindow(segment || "");
  const colorText = extractFirstMatch(source, [
    /颜色\s*[:：]\s*(?:阿里)?\s*(?:[A-Z]{1,4}\d{2,5})?\s*([\u4e00-\u9fff]{1,8})/i,
    /(?:阿里)?\s*[A-Z]{1,4}\d{2,5}\s*([\u4e00-\u9fff]{1,8})/i,
  ]);
  const fallbackColor = colorFromTextSegment(source, []);
  const model = extractFirstMatch(source, [
    /颜色\s*[:：]\s*(?:阿里)?\s*([A-Z]{1,4}\d{2,5})/i,
    /(?:^|\s)(?:[1-9]\d?\s+)?(?:阿里)?\s*([A-Z]{1,4}\d{2,5})/i,
  ]);
  return {
    model,
    color: colorFromTextSegment(colorText || "", []) || fallbackColor,
  };
}

function colorFromTextSegment(segment, supplierOptions = []) {
  const aliases = [
    "白色", "本白", "本色", "本全", "米白", "乳白", "奶白", "象牙白", "白",
    "黑色", "黑",
    "粉色", "浅粉", "粉红", "肉粉", "粉",
    "蓝色", "水蓝", "淡蓝", "蓝",
    "绿色", "草绿", "豆绿", "绿",
    "紫色", "浅紫", "紫",
    "灰色", "银灰", "深灰", "灰",
    "红色", "红",
    "浅卡", "卡其",
  ];
  const direct = aliases.find((alias) => new RegExp(`(?:^|\\s|颜色\\s*[:：]|[A-Z]{1,4}\\d{2,5})${looseSequencePattern(alias)}(?:\\s|$|尺码|均码|数量|Qty|Quantity|（|\\()`, "i").test(String(segment || "")));
  if (direct) return direct;
  const matchedSupplierColor = supplierOptions.find((option) => (
    option.color && purchaseMentionsColorText(segment, option.color)
  ));
  return matchedSupplierColor?.color || "";
}

function purchaseMentionsColorText(source, color) {
  const patterns = colorAliasPatterns(color);
  if (!patterns.length) return false;
  return patterns.some((pattern) => new RegExp(pattern, "i").test(String(source || "")));
}

function bestSupplierOptionInPurchaseSegment(segment, supplierOptions) {
  const matches = [];
  supplierOptions.forEach((option) => {
    if (!option.model || !option.color) return;
    const model = String(option.model).toUpperCase();
    const prefix = model.slice(0, -1);
    const suffix = model.slice(-1);
    const modelPatterns = [
      looseSequencePattern(model),
      `${looseSequencePattern(prefix)}[\\s\\S]{0,120}${looseSequencePattern(suffix)}`,
    ];
    const pattern = new RegExp(modelPatterns.flatMap((modelPattern) => (
      colorAliasPatterns(option.color).map((colorPattern) => (
        `(?:${modelPattern}[\\s\\S]{0,180}${colorPattern}|${colorPattern}[\\s\\S]{0,180}${modelPattern})`
      ))
    )).join("|"), "i");
    const match = String(segment || "").match(pattern);
    if (match) {
      matches.push({
        option,
        text: match[0],
        index: match.index || 0,
        length: match[0].length,
      });
    }
  });
  matches.sort((left, right) => left.length - right.length || left.index - right.index);
  return matches[0] || null;
}

function purchaseOptionRowSegments(source) {
  const normalized = normalizeModelText(source || "");
  const rowPatterns = [
    /(?:^|\s)([1-9]\d?)\s+(?=(?:阿里\s*)?[A-Z]{1,4}\d{2,5}\b)/gi,
    /(?:^|\s)([1-9]\d?)\D{0,80}(?=(?:阿里\s*)?[A-Z]{1,4}\d{2,5}\s*-\s*[A-Z]{1,4}\d{2,5})/gi,
    /(?:^|\s)([1-9]\d?)\D{0,120}(?=颜色\s*[:：]\s*(?:阿里\s*)?[A-Z]{1,4}\d{2,5})/gi,
  ];
  const rowMatches = uniquePurchaseRowMatches(rowPatterns.flatMap((pattern) => Array.from(normalized.matchAll(pattern))));
  if (!rowMatches.length) return [normalized];
  return rowMatches.map((match, index) => {
    const start = match.index || 0;
    const end = rowMatches[index + 1]?.index ?? normalized.length;
    return normalized.slice(start, end);
  });
}

function uniquePurchaseRowMatches(matches) {
  return matches
    .filter((match) => match?.[1])
    .sort((left, right) => (left.index || 0) - (right.index || 0))
    .filter((match, index, sorted) => {
      const currentIndex = match.index || 0;
      const previous = sorted[index - 1];
      if (!previous) return true;
      const previousIndex = previous.index || 0;
      return match[1] !== previous[1] || Math.abs(currentIndex - previousIndex) > 12;
    });
}

function extractKnownSupplierOptionHints(source, supplierOptions) {
  const hints = [];
  const seen = new Set();
  purchaseOptionRowSegments(source).forEach((segment) => {
    const matched = bestSupplierOptionInPurchaseSegment(segment, supplierOptions);
    if (!matched?.option) return;
    const key = `${matched.option.model}-${matched.option.color}-${matched.index}`;
    if (seen.has(key)) return;
    seen.add(key);
    hints.push({
      model: matched.option.model,
      color: matched.option.color,
      size: extractFirstMatch(segment, [/尺码\s*[:：]\s*([\u4e00-\u9fffA-Za-z0-9 -]{1,20})/i]) || matched.option.size || "",
      quantity: purchaseSegmentQuantity(segment, matched.text),
      unitCount: extractProductUnitCount(segment),
      sourceIndex: matched.index || 0,
    });
  });
  return hints;
}

function purchaseSegmentForIndexedRow(source, row) {
  const rowNumber = String(row.rowKey || "").match(/\d+/)?.[0];
  if (!rowNumber) return "";
  const model = String(row.model || "").toUpperCase();
  const rowPattern = new RegExp(`(?:^|\\s)${rowNumber}\\D{0,160}${looseSequencePattern(model)}`, "i");
  const match = String(source || "").match(rowPattern);
  if (!match) return "";
  const start = Math.max(0, (match.index || 0) - 50);
  return String(source || "").slice(start, start + 280);
}

function extractIndexedRowColorHints(source, indexedRows, suppliers) {
  const hints = [];
  indexedRows.forEach((row) => {
    const supplierOptions = suppliers.get(String(row.model || "").toUpperCase()) || [];
    const segment = purchaseSegmentForIndexedRow(source, row);
    const matched = bestSupplierOptionInPurchaseSegment(segment, supplierOptions);
    if (!matched?.option) return;
    hints.push({
      rowKey: row.rowKey,
      model: matched.option.model,
      color: matched.option.color,
      size: extractPurchaseSize(segment) || matched.option.size || "",
      quantity: row.quantity || purchaseSegmentQuantity(segment, matched.text),
      unitCount: extractProductUnitCount(segment),
      sourceIndex: matched.index || 0,
    });
  });
  return hints;
}

function purchaseOcrSource(source) {
  const parts = String(source || "").split(/Purchase order image OCR text\s*:\s*/i);
  return parts.length > 1 ? parts.slice(1).join(" ") : source;
}

function extractPurchaseColorHints(source, suppliers) {
  const hints = [];
  const supplierOptions = Array.from(suppliers.values()).flat();

  const specPattern = /颜色\s*[:：]\s*([A-Z]{1,4}\d{3,5})\s*([\u4e00-\u9fff]{1,6})(?:（[^）]*）|\([^)]*\))?[\s\S]{0,50}?尺码\s*[:：]\s*([\u4e00-\u9fffA-Za-z0-9 -]{1,20}?)(?=\s|数量|$)[\s\S]{0,50}?(?:数量|Qty|Quantity)\s*[:：]?\s*([1-9]\d*)/gi;
  for (const match of source.matchAll(specPattern)) {
    hints.push({
      model: match[1],
      color: match[2],
      size: extractPurchaseSize(match[0]) || match[3],
      quantity: match[4],
      unitCount: extractProductUnitCount(match[0]),
      sourceIndex: match.index || 0,
    });
  }

  const colorSegments = String(source || "").split(/颜色\s*[:：]/i).slice(1);
  let runningIndex = 0;
  colorSegments.forEach((rawSegment) => {
    const segment = rawSegment.split(/颜色\s*[:：]/i)[0].slice(0, 240);
    const matched = bestSupplierOptionInPurchaseSegment(segment, supplierOptions);
    runningIndex += rawSegment.length;
    const fallbackColor = colorFromTextSegment(segment, supplierOptions);
    const fallbackModel = extractFirstMatch(segment, [/(?:阿里)?\s*([A-Z]{1,4}\d{2,5})/i]);
    const model = matched?.option?.model || fallbackModel;
    const color = matched?.option?.color || fallbackColor;
    if (!color) return;
    if (hints.some((hint) => Math.abs((hint.sourceIndex || 0) - runningIndex) < 3)) return;
    hints.push({
      model,
      color,
      size: extractPurchaseSize(segment) || matched?.option?.size || "",
      quantity: purchaseSegmentQuantity(segment, matched?.text || ""),
      unitCount: extractProductUnitCount(segment),
      sourceIndex: runningIndex,
    });
  });

  if (!hints.length) {
    hints.push(...extractKnownSupplierOptionHints(source, supplierOptions));
  }

  return dedupePurchaseColorHints(hints).sort((left, right) => left.sourceIndex - right.sourceIndex);
}

function dedupePurchaseColorHints(hints) {
  const seen = new Set();
  return hints.filter((hint) => {
    const key = [
      String(hint.model || "").toUpperCase(),
      canonicalColorKey(hint.color || ""),
      cleanFieldDisplayValue(hint.size || "").toLowerCase(),
    ].filter(Boolean).join("|");
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function extractGenericPurchaseItems(purchaseText, combinedText, options = {}) {
  const source = normalizeModelText(purchaseText || "");
  if (!source) return [];
  const strictPurchaseRowsOnly = Boolean(options.strictPurchaseRowsOnly);

  const suppliers = supplierSkuMap(combinedText);
  const items = [];
  const seen = new Set();
  const usedSupplierOptions = new Set();
  const addItem = (item) => addGenericPurchaseItem(items, seen, usedSupplierOptions, suppliers, combinedText, item);
  if (!/[A-Z]{1,4}\d{3,5}/i.test(source)) {
    if (strictPurchaseRowsOnly) return [];
    addSupplierColorPurchaseItems(source, suppliers, addItem);
    return items;
  }
  const indexedRows = extractIndexedPurchaseRows(source);
  const ocrSource = purchaseOcrSource(source);
  const colorHints = extractPurchaseColorHints(ocrSource, suppliers);
  const rowHints = extractIndexedRowColorHints(ocrSource, indexedRows, suppliers);
  const usedHintIndexes = new Set();
  const hintedRows = indexedRows.map((row) => {
    let hintIndex = colorHints.findIndex((hint, index) => !usedHintIndexes.has(index) && hint.rowKey === row.rowKey);
    if (hintIndex < 0) hintIndex = colorHints.findIndex((hint, index) => !usedHintIndexes.has(index));
    const sequenceHint = hintIndex > -1 ? colorHints[hintIndex] : null;
    if (hintIndex > -1) usedHintIndexes.add(hintIndex);
    const rowHint = rowHints.find((candidate) => candidate.rowKey === row.rowKey);
    const supplierOptions = suppliers.get(String(row.model || "").toUpperCase()) || [];
    const rowColor = purchaseOptionFromSegment(row.segment).color
      || colorFromTextSegment(purchaseColorWindow(row.segment), supplierOptions);
    return {
      ...row,
      color: rowColor || sequenceHint?.color || rowHint?.color || row.color || "",
      size: sequenceHint?.size || rowHint?.size || row.size || "",
      quantity: row.quantity || sequenceHint?.quantity || rowHint?.quantity || "",
      unitCount: sequenceHint?.unitCount || rowHint?.unitCount || row.unitCount || "",
      allowSupplierColorFallback: Boolean(rowColor || sequenceHint?.color || rowHint?.color),
    };
  });
  if (hintedRows.length) {
    const usedColorKeysByModel = new Map();
    hintedRows.forEach((row) => {
      if (!row.color) return;
      const modelKey = String(row.model || "").toUpperCase();
      if (!usedColorKeysByModel.has(modelKey)) usedColorKeysByModel.set(modelKey, new Set());
      usedColorKeysByModel.get(modelKey).add(canonicalColorKey(row.color));
    });
    hintedRows.forEach((row) => {
      if (row.color) return;
      const modelKey = String(row.model || "").toUpperCase();
      const usedColors = usedColorKeysByModel.get(modelKey) || new Set();
      const unusedOptions = (suppliers.get(modelKey) || []).filter((option) => (
        option.color && !usedColors.has(canonicalColorKey(option.color))
      ));
      if (unusedOptions.length !== 1) return;
      row.color = unusedOptions[0].color;
      row.size = row.size || unusedOptions[0].size || "";
      row.allowSupplierColorFallback = true;
      usedColors.add(canonicalColorKey(row.color));
      usedColorKeysByModel.set(modelKey, usedColors);
    });
  }

  if (!strictPurchaseRowsOnly && colorHints.length > indexedRows.length) {
    colorHints.forEach((hint, index) => addItem({
      ...hint,
      model: hint.model || indexedRows[index]?.model || indexedRows[0]?.model || "",
      rowKey: hint.rowKey || `color-${index + 1}`,
      allowSupplierColorFallback: Boolean(hint.color),
    }));
    if (items.length) return items;
  }

  if (hintedRows.length && (colorHints.length || rowHints.length || hintedRows.some((row) => row.color))) {
    hintedRows.forEach((row) => addItem(row));
    if (items.length) return items;
  }

  if (indexedRows.length && /Purchase order image OCR text\s*:/i.test(source)) {
    rowHints.forEach((hint, index) => addItem({
      ...indexedRows[index],
      ...hint,
      rowKey: hint.rowKey || indexedRows[index]?.rowKey || `rowhint-${index}`,
      allowSupplierColorFallback: Boolean(hint.color),
    }));
    if (items.length) return items;
  }

  if (strictPurchaseRowsOnly) return [];

  colorHints.forEach((hint, index) => addItem({ ...hint, rowKey: `color-${index}`, allowSupplierColorFallback: true }));
  if (items.length) return items;

  addSupplierColorPurchaseItems(source, suppliers, addItem);
  if (items.length) return items;

  indexedRows.forEach((row) => {
    const supplierOptions = suppliers.get(String(row.model || "").toUpperCase()) || [];
    const rowColor = purchaseOptionFromSegment(row.segment).color
      || colorFromTextSegment(purchaseColorWindow(row.segment), supplierOptions);
    addItem({
      ...row,
      color: rowColor || row.color || "",
      allowSupplierColorFallback: Boolean(rowColor),
    });
  });
  if (items.length) return items;

  const loosePattern = /(?:^|\s)([1-9]\d?)\s+([A-Z]{1,4}\d{3,5})(?:-[A-Z]{1,4}\d{3,5})?(?:\s+([A-Z]{1,4}\d{3,5}))?(?:\s+([1-9]\d*))?/gi;
  for (const match of source.matchAll(loosePattern)) {
    addItem({
      model: match[3] || match[2],
      quantity: match[4] || "",
      unitCount: extractProductUnitCount(match[0]),
      rowKey: `loose-${match[1]}`,
    });
  }

  return items;
}

function addSupplierColorPurchaseItems(source, suppliers, addItem) {
  const supplierOptions = Array.from(suppliers.values()).flat();
  const seenColors = new Set();
  supplierOptions
    .map((option) => ({
      option,
      index: purchaseColorMentionIndex(source, option.color),
    }))
    .filter(({ option, index }) => option.model && option.color && index > -1)
    .sort((left, right) => left.index - right.index)
    .forEach(({ option }, index) => {
      const colorKey = `${option.model}-${canonicalColorKey(option.color)}-${cleanFieldDisplayValue(option.size || "").toLowerCase()}`;
      if (seenColors.has(colorKey)) return;
      seenColors.add(colorKey);
      addItem({
        model: option.model,
        color: option.color,
        size: option.size || "",
        rowKey: `supplier-color-${index + 1}`,
        allowSupplierColorFallback: true,
      });
    });
}

function purchaseColorMentionIndex(source, color) {
  const patterns = colorAliasPatterns(color);
  if (!patterns.length) return -1;
  const indexes = patterns
    .map((pattern) => String(source || "").search(new RegExp(pattern, "i")))
    .filter((index) => index > -1);
  return indexes.length ? Math.min(...indexes) : -1;
}

function purchaseRowFieldValue(rowText, field) {
  const pattern = new RegExp(`(?:^|;)\\s*${field}\\s*=\\s*([\\s\\S]*?)(?=;\\s*(?:index|code|name|spec|quantity|price|amount)\\s*=|$)`, "i");
  return cleanFieldDisplayValue(normalizePurchaseText(decodeHtmlEntities(rowText).match(pattern)?.[1] || ""));
}

function parseStructuredPurchaseRows(purchaseText) {
  const rows = [];
  const source = String(purchaseText || "");
  const pattern = /PURCHASE_ROW\s*:\s*([^\n]+)/gi;
  for (const match of source.matchAll(pattern)) {
    const rowText = match[1];
    const index = purchaseRowFieldValue(rowText, "index") || String(rows.length + 1);
    const name = purchaseRowFieldValue(rowText, "name");
    const spec = purchaseRowFieldValue(rowText, "spec");
    const code = purchaseRowFieldValue(rowText, "code");
    if (!name && !spec && !code) continue;
    rows.push({
      index,
      rowKey: `row-${index}`,
      code,
      name,
      spec,
      quantity: purchaseRowFieldValue(rowText, "quantity"),
      price: purchaseRowFieldValue(rowText, "price"),
      amount: purchaseRowFieldValue(rowText, "amount"),
      segment: [index, code, name, spec].filter(Boolean).join(" "),
      sourceIndex: match.index || rows.length,
    });
  }
  return contiguousPurchaseRows(rows);
}

function contiguousPurchaseRows(rows) {
  const numericRows = (rows || []).filter((row) => /^[1-9]\d{0,2}$/.test(String(row.index || "")));
  if (!numericRows.length) return rows;
  const kept = [];
  for (const row of rows) {
    const index = Number(row.index);
    if (!Number.isFinite(index)) {
      kept.push(row);
      continue;
    }
    if (index !== kept.filter((item) => /^[1-9]\d{0,2}$/.test(String(item.index || ""))).length + 1) {
      continue;
    }
    kept.push(row);
  }
  return kept.length ? kept : rows;
}

function stripPurchaseTotalsFromOption(value) {
  return normalizePurchaseText(value)
    .replace(/\s+\d+\s+\d+(?:\.\d+)?\s*元\s*\/?\s*(?:双|件|个|盒|把|条|只)?(?:\s+[-+]?\d+(?:\.\d+)?){0,2}\s*$/i, " ")
    .replace(/\s+\d+(?:\.\d+)?\s*元\s*\/?\s*(?:双|件|个|盒|把|条|只)?(?:\s+[-+]?\d+(?:\.\d+)?){0,2}\s*$/i, " ")
    .replace(/\s+(?:数量|单价|优惠|金额)\s*[:：]?\s*[-+]?\d+(?:\.\d+)?[\s\S]*$/i, " ")
    .replace(/\s+(?:元\s*\/?\s*(?:双|件|个|盒|把|条|只)?|¥|￥)\s*[-+]?\d*(?:\.\d+)?[\s\S]*$/i, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function stripModelPrefixFromOption(value) {
  return normalizePurchaseText(value)
    .replace(/\b(?!V02\b|U02\b|V60\b)[A-Z]{1,4}\d{2,5}\b/gi, " ")
    .replace(/\b[A-Z]{1,4}\d{2,5}\s+(?=[\u4e00-\u9fff])/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanPurchaseOptionText(value) {
  return stripPurchaseTotalsFromOption(value)
    .replace(/([A-Za-z])\s+([A-Za-z0-9])/g, "$1$2")
    .replace(/([0-9])\s+([A-Za-z])/g, "$1$2")
    .replace(/([0-9])\s+([0-9]{2})(?=\s*(?:片|pcs|mm|cm|克|g|寸|骨|杯|人份))/gi, "$1$2")
    .replace(/([0-9]{2})\s+([0-9])(?=\s*(?:片|pcs|mm|cm|克|g|寸|骨|杯|人份))/gi, "$1$2")
    .replace(/([0-9])\s+([0-9])(?=片|pcs|mm|cm|克|g|寸|骨|杯|人份)/gi, "$1$2")
    .replace(/颜色\s*[:：]/gi, " ")
    .replace(/尺寸\s*[:：]/gi, " ")
    .replace(/尺码\s*[:：]/gi, " ")
    .replace(/规格\s*[:：]/gi, " ")
    .replace(/亚马逊\s*定制/gi, " ")
    .replace(/货品合计[\s\S]*$/g, " ")
    .replace(/实付款[\s\S]*$/g, " ")
    .replace(/\s+\d+(?:\.\d+)?\s*元\s*运[\s\S]*$/g, " ")
    .replace(/\s+运\s*费[\s\S]*$/g, " ")
    .replace(/\s+优惠[\s\S]*$/g, " ")
    .replace(/[\[\]【】]/g, " ")
    .replace(/[：:]+/g, " ")
    .replace(/\b(?:OPP|opp)\b/g, " ")
    .replace(/\b(?:SKU|sku)\b/g, " ")
    .replace(/\b(?!V02\b|U02\b|V60\b)[A-Z]{1,4}\d{2,5}\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function compactChineseText(value) {
  return normalizePurchaseText(value).replace(/\s+/g, "").trim();
}

function normalizePurchaseSpecSpacing(value) {
  return normalizePurchaseText(value)
    .replace(/([\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])/g, "$1")
    .replace(/([A-Za-z])\s+([A-Za-z0-9])/g, "$1$2")
    .replace(/([0-9])\s+([A-Za-z])/g, "$1$2")
    .replace(/([0-9])\s+([0-9]{2})(?=\s*(?:片|pcs|mm|cm|克|g|寸|骨|杯|人份))/gi, "$1$2")
    .replace(/([0-9]{2})\s+([0-9])(?=\s*(?:片|pcs|mm|cm|克|g|寸|骨|杯|人份))/gi, "$1$2")
    .replace(/([0-9])\s+([0-9])(?=片|pcs|mm|cm|克|g|寸|骨|杯|人份)/gi, "$1$2")
    .replace(/\s+/g, " ")
    .trim();
}

function purchaseRowOptionSource(row) {
  return normalizePurchaseSpecSpacing([
    row.spec,
    row.code,
    row.name,
  ].filter(Boolean).join(" "));
}

function coffeeFilterItemFromPurchaseRow(row) {
  const optionSource = normalizeSkuText(normalizePurchaseSpecSpacing([row.spec, row.code].filter(Boolean).join(" ")));
  const source = normalizeSkuText(purchaseRowOptionSource(row));
  const compact = compactChineseText(source);
  const compactOption = compactChineseText(optionSource);
  if (/粉碗|接粉环|粉槽|portafilter|basket|dosing/i.test(source)) return null;
  const hasFilterSignal = /咖啡|滤纸|圆形|V02|V形|扇形|U02|#?0[24]/i.test(source) || /^600711\b/i.test(String(row.code || "").trim());
  if (!hasFilterSignal) return null;

  const roundSize = extractFirstMatch(optionSource, [
    /(?:^|[^0-9])([1-9]\d)\s*mm/i,
    /(?:^|[^0-9])(5[1368]|60|64|68)(?=\s*(?:10|100|片|pcs|$))/i,
  ]);
  if (/圆形|round/i.test(source) || roundSize && !/V02|V形|扇形|U02|#?0[24]/i.test(optionSource)) {
    const color = extractPurchaseRowColor(row) || "";
    return {
      key: roundSize ? `round-${roundSize}` : `round-${row.index}`,
      spec: `${color ? `${displayColorName(color)} ` : ""}round coffee filter${roundSize ? ` ${roundSize}mm` : ""}`.trim(),
      outputSpec: `${color ? `${colorName(color)} ` : ""}round coffee filter paper${roundSize ? ` ${roundSize}mm` : ""}`.trim(),
      sizeCode: [color ? displayColorName(color) : "", roundSize ? `${roundSize}mm` : ""].filter(Boolean).join(" / "),
      productName: "圆形咖啡滤纸",
      outputProductName: "round coffee filter paper",
      color,
      colorEnglish: colorName(color),
      size: roundSize ? `${roundSize}mm` : "",
      quantity: row.quantity,
      rowKey: row.rowKey,
      purchaseRowKey: row.rowKey,
      model: row.code,
      pack: extractProductUnitCount(source),
    };
  }

  const token = /V02|V形02|V\s*02/i.test(compactOption)
    ? "V02"
    : /扇形04|fan04|#04|04盒/i.test(compactOption)
      ? "fan 04"
      : /扇形U?02|fan02|U02|#02|02盒/i.test(compactOption)
        ? "fan 02"
        : "";
  if (!token) return null;
  const pack = normalizePackageCount(optionSource) || extractProductUnitCount(optionSource);
  const specInfo = productSpecForToken(token);
  return {
    ...specInfo,
    productName: "咖啡滤纸",
    outputProductName: "coffee filter paper",
    variantStyle: specInfo.sizeCode,
    outputSpec: [specInfo.spec, pack].filter(Boolean).join(" - "),
    pack,
    quantity: row.quantity,
    rowKey: row.rowKey,
    purchaseRowKey: row.rowKey,
    model: row.code,
  };
}

function extractPurchaseRowColor(row) {
  const compactSpec = compactChineseText(row.spec);
  const explicitColor = extractFirstMatch(compactSpec, [
    /颜色[:：]?(.+?)(?=尺码|尺寸|规格|数量|$)/i,
  ]);
  const englishColor = extractEnglishColorName([row.spec, row.code, row.name].filter(Boolean).join(" "));
  const sources = [
    explicitColor,
    compactSpec,
    compactChineseText(row.code),
    compactChineseText(row.name),
  ].filter(Boolean);
  const colorCandidates = productColorCandidates();
  for (const source of sources) {
    const found = colorCandidates.find((candidate) => source.includes(candidate));
    if (found) return found;
  }
  return englishColor;
}

function extractEnglishColorName(value) {
  const source = String(value || "").toLowerCase();
  const colors = [
    "black", "white", "gray", "grey", "blue", "green", "purple", "pink", "red", "yellow", "orange", "brown", "khaki", "silver",
  ];
  return colors.find((color) => new RegExp(`(?:^|[^a-z])${color}(?:[^a-z]|$)`, "i").test(source)) || "";
}

function extractPurchaseRowSize(row) {
  const source = normalizePurchaseSpecSpacing([row.spec, row.code].filter(Boolean).join(" "));
  const compactRowText = compactChineseText(`${row.name} ${row.spec}`);
  if (/伞/.test(compactRowText)) {
    const umbrellaSize = extractFirstMatch(source, [
      /([1-9]\d?)\s*(?:寸|inch|in\b)/i,
    ]);
    return umbrellaSize ? `${umbrellaSize} inch` : "";
  }
  if (/粉碗|接粉环|粉槽/.test(compactRowText)) {
    const coffeeSize = extractFirstMatch(source, [/([1-9]\d\s*mm)/i]);
    return coffeeSize ? coffeeSize.replace(/\s+/g, "") : "";
  }
  const size = extractFirstMatch(source, [
    /尺码\s*[:：]?\s*(US\s*Size\s*[0-9]+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?\s*(?:码|号)?|XXL|XL|L|M|S|XS)(?=\s|$|[;；,，/])/i,
    /鞋码\s*[:：]?\s*(US\s*Size\s*[0-9]+(?:\.[0-9]+)?|[0-9]+(?:\.[0-9]+)?\s*(?:码|号)?)(?=\s|$|[;；,，/])/i,
    /(?:^|[\s;；,，/])([0-9]+(?:\.[0-9]+)?\s*(?:码|号))(?=\s|$|[;；,，/])/i,
    /尺码\s*[:：]?\s*(XXL|XL|L|M|S|XS|均码|one\s*size|free\s*size)(?=\s|$|[;；,，])/i,
    /(?:^|[-\s])((?:XXL|XL|L|M|S|XS))(?=\s|$)/i,
    /尺寸\s*[:：]?\s*([^;；,，]+?)(?=\s*(?:数量|单价|$))/i,
    /规格\s*[:：]?\s*([^;；,，]+?)(?=\s*(?:数量|单价|$))/i,
  ]);
  return cleanFieldDisplayValue(size.replace(/常\s*规\s*款/gi, "regular"));
}

function extractPurchaseRowStyle(row) {
  const source = normalizePurchaseSpecSpacing(row.spec || row.code || "");
  const compact = compactChineseText(source);
  const compactRowText = compactChineseText(`${row.name} ${row.spec}`);
  if (/粉碗|接粉环|粉槽/.test(compactRowText)) {
    const clean = cleanPurchaseOptionText(source)
      .replace(/[1-9]\d\s*mm/ig, " ")
      .replace(/银色/g, " ")
      .replace(/带\s*磁\s*吸\s*接\s*粉\s*环/g, " ")
      .replace(/磁\s*吸\s*接\s*粉\s*环/g, " ")
      .replace(/\s*[-—]?\s*\d+(?:\.\d+)?\s*元\s*运[\s\S]*$/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    if (/接粉环/.test(compactRowText)) return "";
    return clean || "粉碗";
  }
  if (/伞/.test(compactRowText)) {
    return umbrellaStyleFromPurchaseRow(row);
  }
  const bracket = extractFirstMatch(source, [/【([^】]{1,30})】/]);
  const afterColor = cleanPurchaseOptionText(extractFirstMatch(source, [
    /颜色\s*[:：]\s*([^;；,，]+?)(?=\s*(?:尺码|尺寸|规格|数量|单价|$))/i,
  ]));
  const hasExplicitColorOrSize = /颜色\s*[:：]|尺码\s*[:：]|尺寸\s*[:：]/i.test(source);
  const cleaned = stripModelPrefixFromOption(cleanPurchaseOptionText(bracket || afterColor || source));
  const withoutColor = extractPurchaseRowColor(row)
    ? cleaned.replace(new RegExp(looseSequencePattern(extractPurchaseRowColor(row)), "i"), " ").replace(/\s+/g, " ").trim()
    : cleaned;
  const withoutGenericSize = withoutColor
    .replace(/^[;；,，\s/-]+|[;；,，\s/-]+$/g, "")
    .replace(/^(?:均码|one size|free size)$/i, "")
    .trim();
  if (withoutGenericSize !== withoutColor && !withoutGenericSize) return "";
  if (isSockFamilyText(compactRowText)) {
    const styleNumber = withoutColor.replace(/^[;；,，\s/-]+|[;；,，\s/-]+$/g, "").trim();
    if (/^[1-9]\d?$/.test(styleNumber) && (!row.quantity || styleNumber === cleanFieldDisplayValue(row.quantity))) return "";
  }
  if (hasExplicitColorOrSize && !withoutColor) return "";
  if (hasExplicitColorOrSize && !/[\u4e00-\u9fff]/.test(withoutColor) && /^[A-Za-z0-9+/=_-]{2,24}$/i.test(withoutColor)) return "";
  if (!/[\u4e00-\u9fff]/.test(withoutColor) && /=/.test(withoutColor)) return "";
  if (/^\d+(?:\.\d+)?(?:\s*元\s*\/?\s*(?:双|件|个|盒|把|条|只)?)?$/i.test(withoutColor)) return "";
  if (/^(?:双|件|个|盒|把|条|只)$/.test(withoutColor)) return "";
  if (/^(?:均码|one size|free size)$/i.test(withoutColor)) return "";
  if (/^[SMLX]{1,3}$/i.test(withoutColor)) return "";
  if (/^[0-9]+(?:mm|cm|克|g|寸|骨)$/i.test(withoutColor)) return "";
  if (/^[-—]+$/.test(withoutColor)) return "";
  if (/生日口水巾/.test(compact)) return "生日口水巾";
  if (/扫帚/.test(compact)) return "扫帚木天蓼";
  if (/羽毛/.test(compact)) return "木天蓼羽毛款";
  if (/鱼骨/.test(compact) && /薄荷/.test(compact) && /虫瘿果/.test(compact)) return "鱼骨木天蓼 薄荷+虫瘿果";
  if (/鱼骨/.test(compact) && /薄荷/.test(compact)) return "鱼骨木天蓼 薄荷味";
  if (/鱼骨/.test(compact) && /虫瘿果/.test(compact)) return "鱼骨木天蓼 虫瘿果味";
  if (/玫瑰|薰衣草|茉莉|藏红花|乌龙茶|秘鲁圣木|桂花/.test(compact)) {
    return extractFirstMatch(compact, [/(玫瑰|薰衣草|茉莉|藏红花|乌龙茶|秘鲁圣木|桂花)/]);
  }
  return withoutColor;
}

function umbrellaStyleFromPurchaseRow(row) {
  const source = normalizePurchaseSpecSpacing([row.name, row.spec, row.code].filter(Boolean).join(" "));
  const compact = compactChineseText(source);
  const parts = [];
  const fold = extractFirstMatch(compact, [/([1-9]\d?)折伞?/]);
  const rib = extractFirstMatch(compact, [/([1-9]\d?)骨/]);
  if (/扁/.test(compact)) parts.push("flat");
  if (fold) parts.push(`${fold}-fold`);
  if (rib) parts.push(`${rib}-rib`);
  return parts.join(" ");
}

function productNameFromPurchaseRow(row) {
  const name = cleanFieldDisplayValue(normalizePurchaseText(row.name || ""));
  const compact = compactChineseText(`${row.name || ""} ${row.spec || ""} ${row.code || ""}`);
  if (/瑜伽袜|普拉提袜|五指袜|五趾袜|分趾袜/.test(compact)) return "五指瑜伽袜";
  if (/船袜|短袜|隐形袜|浅口袜/.test(compact)) return "船袜";
  if (/袜子|袜/.test(compact)) return "袜子";
  if (/口水巾|围兜|围巾/.test(compact)) return "宠物生日围兜";
  if (/铃铛项圈|猫咪项圈|宠物猫脖圈/.test(compact)) return "猫咪铃铛项圈";
  if (/木天蓼|猫玩具|鱼骨/.test(compact)) return "木天蓼猫玩具";
  if (/粉碗/.test(compact)) return "咖啡粉碗";
  if (/接粉环/.test(compact)) return "磁吸接粉环";
  if (/圆形.*滤纸|滤纸.*圆形/.test(compact)) return "圆形咖啡滤纸";
  if (/咖啡.*滤纸|滤纸/.test(compact)) return "咖啡滤纸";
  if (/瑜伽球|普拉提小球/.test(compact)) return "瑜伽球";
  if (/拉力带|拉力绳|弹力带/.test(compact)) return "弹力带";
  if (/伞/.test(compact)) return "六折伞";
  if (/线香/.test(compact)) return "线香";
  return stripSupplierModelCodes(name);
}

function crossBorderNameFromChinese(value) {
  const compact = compactChineseText(value);
  if (/五指瑜伽袜|五趾瑜伽袜|瑜伽袜|普拉提袜/.test(compact)) {
    return descriptiveYogaSockProductName(value)
      || "women's non-slip five-toe yoga pilates socks";
  }
  if (/船袜|短袜|隐形袜|浅口袜/.test(compact)) return "no-show grip socks";
  if (/袜子|袜/.test(compact)) return "socks";
  if (/宠物生日围兜/.test(compact)) return "pet birthday bandana bib";
  if (/猫咪铃铛项圈/.test(compact)) return "cat collar with bell";
  if (/木天蓼猫玩具|猫玩具/.test(compact)) return "matatabi cat toy";
  if (/咖啡粉碗/.test(compact)) return "espresso filter basket";
  if (/磁吸接粉环|接粉环/.test(compact)) return "magnetic dosing funnel";
  if (/圆形咖啡滤纸/.test(compact)) return "round coffee filter paper";
  if (/咖啡滤纸/.test(compact)) return "coffee filter paper";
  if (/瑜伽球/.test(compact)) return "pilates yoga ball";
  if (/弹力带/.test(compact)) return "resistance band";
  if (/六折伞|伞/.test(compact)) return "compact folding umbrella";
  if (/线香/.test(compact)) return "incense sticks";
  return "";
}

function genericItemFromPurchaseRow(row) {
  const productName = productNameFromPurchaseRow(row);
  const color = extractPurchaseRowColor(row);
  const size = extractPurchaseRowSize(row);
  const style = extractPurchaseRowStyle(row);
  const outputProductName = crossBorderNameFromChinese(productName);
  const outputSpec = outputVariantNameFromParts(outputProductName || productName, {
    color,
    size,
    style,
  });
  const optionParts = [
    style,
    color ? displayColorName(color) : "",
    /^(?:均码|one size|free size)$/i.test(size) ? "" : size,
  ].filter(Boolean);
  const optionText = optionParts.join(" / ");
  return {
    key: cleanFieldDisplayValue(row.code || productName || `row-${row.index}`).toLowerCase(),
    purchaseRowKey: row.rowKey,
    rowKey: row.rowKey,
    model: row.code,
    productName,
    outputProductName,
    color,
    displayColor: color ? displayColorName(color) : "",
    colorEnglish: colorName(color),
    size,
    variantStyle: style,
    spec: [productName, optionText].filter(Boolean).join(" - "),
    outputSpec,
    sizeCode: optionText,
    quantity: row.quantity,
    price: row.price,
    pack: "",
    productUnitCount: "",
    fit: "",
    };
  }

function supplierRequestFromPurchaseRow(row) {
  const context = [row.spec, row.code, row.name].filter(Boolean).join(" ");
  const color = extractPurchaseRowColor(row) || supplierSkuColor(context);
  if (!color) return null;
  return {
    color,
    style: supplierSkuStyle(context),
    size: supplierSkuSize(context) || extractPurchaseRowSize(row),
  };
}

function enrichStructuredItemsWithSupplierSkus(items, rows, supplierText) {
  if (!items.length || !/拉力带|拉力片|弹力带|阻力带|resistance\s+band|exercise\s+band/i.test(supplierText || "")) return items;
  const supplierOptions = extractSupplierSkuOptions(supplierText).filter((option) => option.model === GENERIC_SUPPLIER_SKU_MODEL);
  if (!supplierOptions.length) return items;
  return items.map((item) => {
    const row = (rows || []).find((candidate) => candidate.rowKey === item.purchaseRowKey || candidate.rowKey === item.rowKey);
    const request = supplierRequestFromPurchaseRow(row || item);
    const option = supplierOptions.find((candidate) => supplierOptionMatchesPurchaseRequest(candidate, request))
      || supplierOptions.find((candidate) => candidate.color && isSameColorName(candidate.color, item.color || request?.color));
    if (!option) return item;
    const style = option.variantStyle || request?.style || item.variantStyle || "";
    const size = option.size || request?.size || item.size || "";
    return {
      ...item,
      model: option.model,
      color: option.color || item.color,
      displayColor: displayColorName(option.color || item.color),
      colorEnglish: colorName(option.color || item.color),
      size,
      variantStyle: style,
      spec: ["弹力带", style, displayColorName(option.color || item.color), size].filter(Boolean).join(" - "),
      outputProductName: item.outputProductName || "resistance band",
      outputSpec: outputVariantNameFromParts("resistance band", {
        color: option.color || item.color,
        size,
        style: translateSupplierSkuStyle(style),
      }),
      sizeCode: [style, displayColorName(option.color || item.color), size].filter(Boolean).join(" / "),
      dims: option.dims || item.dims,
      supplierOption: option,
      fit: item.fit || "",
    };
  });
}

function outputVariantNameFromParts(baseName, { color = "", size = "", style = "" } = {}) {
  const cleanSize = /^(?:均码|one size|free size)$/i.test(size) ? "" : cleanFieldDisplayValue(size);
  const styleParts = cleanFieldDisplayValue(style)
    .split(/\s+/)
    .filter(Boolean);
  return displayVariantText([
    color ? colorName(color) : "",
    cleanSize,
    ...styleParts,
    baseName,
  ].filter(Boolean).join(" "));
}

function assignMissingRoundFilterColors(items, rows) {
  const roundItems = items.filter((item) => item && /^round-/.test(String(item.key || "")) && !item.color);
  if (roundItems.length < 2) return;
  const duplicateGroups = new Map();
  roundItems.forEach((item) => {
    const size = cleanFieldDisplayValue(item.size || "");
    if (!duplicateGroups.has(size)) duplicateGroups.set(size, []);
    duplicateGroups.get(size).push(item);
  });
  const hasLikelyNaturalAndWhiteSet = Array.from(duplicateGroups.values()).some((group) => group.length >= 2)
    || /白色|原色|本色/.test(normalizePurchaseText(rows.map((row) => `${row.name} ${row.spec}`).join(" ")));
  if (!hasLikelyNaturalAndWhiteSet) return;
  const colorCycle = ["白色", "本色"];
  const counters = new Map();
  roundItems.forEach((item) => {
    const size = cleanFieldDisplayValue(item.size || "");
    const index = counters.get(size) || 0;
    counters.set(size, index + 1);
    const color = colorCycle[index % colorCycle.length];
    item.color = color;
    item.displayColor = displayColorName(color);
    item.colorEnglish = outputColorName(color);
    item.spec = `${item.displayColor} round coffee filter ${size}`.trim();
    item.outputSpec = [item.colorEnglish, "round coffee filter paper", size].filter(Boolean).join(" ");
    item.sizeCode = [item.displayColor, size].filter(Boolean).join(" / ");
  });
}

function extractStructuredPurchaseItems(purchaseText, supplierText = "") {
  const rows = parseStructuredPurchaseRows(purchaseText);
  if (!rows.length) return [];
  const items = rows
    .map((row) => {
      const coffeeItem = coffeeFilterItemFromPurchaseRow(row);
      if (coffeeItem) return coffeeItem;
      return isLikelyStructuredPurchaseRow(row) ? genericItemFromPurchaseRow(row) : null;
    });
  assignMissingRoundFilterColors(items, rows);
  return enrichStructuredItemsWithSupplierSkus(
    items.filter((item) => item && (item.spec || item.sizeCode || item.color || item.key)),
    rows,
    supplierText,
  );
}

function isLikelyStructuredPurchaseRow(row) {
  const source = normalizePurchaseText([row.code, row.name, row.spec].filter(Boolean).join(" "));
  const withoutSettlement = stripPurchaseTotalsFromOption(source);
  if (!withoutSettlement) return false;
  if (/[A-Z]{1,4}\d{2,5}/i.test(withoutSettlement)) return true;
  if (extractPurchaseRowColor(row)) return true;
  if (/咖啡|滤纸|粉碗|接粉环|包装纸|包花纸|花束|鲜花包装|花艺|礼品包装|口水巾|围兜|项圈|木天蓼|猫玩具|瑜伽|普拉提|五指|五趾|分趾|袜|拉力|弹力|伞|线香|球/.test(withoutSettlement)) return true;
  return /[\u4e00-\u9fff]{2,}/.test(row.name || "") && !/^[A-Za-z0-9+/=_-]{2,40}$/i.test(withoutSettlement);
}

function extractPurchaseItems(purchaseText, combinedText) {
  const structuredItems = extractStructuredPurchaseItems(purchaseText, combinedText);
  if (structuredItems.length) return structuredItems;
  const supplierSkuItems = extractSupplierSkuPurchaseItems(purchaseText, combinedText);
  if (supplierSkuItems.length) return supplierSkuItems;
  const strictPurchaseRowsOnly = /Purchase order image OCR text\s*:/i.test(purchaseText || "");

  const normalized = normalizeSkuText(purchaseText || combinedText);
  const items = [];
  const seen = new Set();
  const patterns = [
    /(V02|fan 02|fan 04|#02|#04)[^\n,;，；]{0,30}?(100|200)\s*pcs/gi,
    /(100|200)\s*pcs[^\n,;，；]{0,30}?(V02|fan 02|fan 04|#02|#04)/gi,
  ];

  patterns.forEach((pattern) => {
    for (const match of normalized.matchAll(pattern)) {
      const first = match[1];
      const second = match[2];
      const token = /100|200/.test(first) ? second : first;
      const pack = normalizePackageCount(/100|200/.test(first) ? first : second);
      const specInfo = productSpecForToken(token);
      const key = `${specInfo.key}-${pack}`;
      if (!pack || seen.has(key)) continue;
      seen.add(key);
      items.push({ ...specInfo, pack });
    }
  });

  const coffeeSignals = {
    v02: /V02|V 02|V形/i.test(normalized),
    u02: /fan 02|U02|U102|#02|扇形02/i.test(normalized),
    u04: /fan 04|#04|扇形04/i.test(normalized),
  };

  const has100 = /100\s*(pcs|片)/i.test(normalized);
  const has200 = /200\s*(pcs|片)/i.test(normalized);
  const availablePacks = [has100 && "100 pcs box", has200 && "200 pcs box"].filter(Boolean);

  const appendVariant = (token, enabled) => {
    if (!enabled) return;
    const specInfo = productSpecForToken(token);
    availablePacks.forEach((pack) => {
      const key = `${specInfo.key}-${pack}`;
      if (!seen.has(key)) {
        seen.add(key);
        items.push({ ...specInfo, pack });
      }
    });
  };

  appendVariant("V02", coffeeSignals.v02);
  appendVariant("fan 02", coffeeSignals.u02);
  appendVariant("fan 04", coffeeSignals.u04);

  if (!items.length) {
    return extractGenericPurchaseItems(purchaseText, combinedText, { strictPurchaseRowsOnly });
  }

  return items;
}

function productUnitCountForItem(item, supplierText) {
  if (item.productUnitCount || item.pack) {
    return item.productUnitCount || item.pack;
  }
  if (item.purchaseRowKey && !item.pack && !item.productUnitCount) {
    return "";
  }
  const optionText = [
    item.productUnitCount,
    item.pack,
    item.spec,
    item.size,
    item.color,
    item.supplierOption?.size,
    item.supplierOption?.color,
  ].filter(Boolean).join(" ");
  return extractProductUnitCount(optionText);
}

function purchaseSupplierSkuRequests(purchaseText) {
  const source = normalizePurchaseText(purchaseText || "");
  const requests = [];
  const pattern = /颜色\s*[:：]\s*([\u4e00-\u9fffA-Za-z ]{1,20})([\s\S]*?)(?=颜色\s*[:：]|PURCHASE_ROW\s*:|$)/gi;
  for (const match of source.matchAll(pattern)) {
    const color = supplierSkuColor(match[1]);
    const context = `${match[1]} ${match[2] || ""}`;
    const style = supplierSkuStyle(context);
    const size = supplierSkuSize(context);
    if (!color) continue;
    requests.push({ color, style, size, sourceIndex: match.index || requests.length });
  }
  if (requests.length) return dedupePurchaseSupplierSkuRequests(requests);
  return dedupePurchaseSupplierSkuRequests(purchaseSupplierSkuRequestsFromColorMentions(source));
}

function purchaseSupplierSkuRequestsFromColorMentions(source) {
  const requests = [];
  const seenRanges = [];
  productColorCandidates().forEach((candidate) => {
    const pattern = new RegExp(looseSequencePattern(candidate), "gi");
    for (const match of String(source || "").matchAll(pattern)) {
      const index = match.index || 0;
      if (seenRanges.some(([start, end]) => index >= start && index <= end)) continue;
      const start = Math.max(0, index - 60);
      const end = Math.min(String(source || "").length, index + 180);
      const context = String(source || "").slice(start, end);
      const color = supplierSkuColor(candidate);
      if (!color) continue;
      requests.push({
        color,
        style: supplierSkuStyle(context),
        size: supplierSkuSize(context),
        sourceIndex: index,
      });
      seenRanges.push([index, index + match[0].length]);
    }
  });
  return requests.sort((left, right) => left.sourceIndex - right.sourceIndex);
}

function dedupePurchaseSupplierSkuRequests(requests) {
  const seen = new Set();
  return (requests || []).filter((request) => {
    const key = [
      canonicalColorKey(request.color || ""),
      cleanFieldDisplayValue(request.style || "").toLowerCase(),
      cleanFieldDisplayValue(request.size || "").toLowerCase(),
    ].join("|");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function supplierOptionMatchesPurchaseRequest(option, request) {
  if (!option?.color || !request?.color || !isSameColorName(option.color, request.color)) return false;
  const optionStyle = cleanFieldDisplayValue(option.variantStyle || option.rawSpec || "");
  const optionSize = cleanFieldDisplayValue(option.size || option.rawSpec || "").replace(/\s+/g, "");
  if (request.style && !compactChineseText(optionStyle).includes(compactChineseText(request.style))) return false;
  if (request.size && !optionSize.includes(cleanFieldDisplayValue(request.size).replace(/\s+/g, ""))) return false;
  return true;
}

function extractSupplierSkuPurchaseItems(purchaseText, combinedText) {
  const requests = purchaseSupplierSkuRequests(purchaseText);
  if (!requests.length || !/拉力带|拉力片|弹力带|阻力带|resistance\s+band|exercise\s+band/i.test(combinedText || "")) return [];
  const supplierOptions = extractSupplierSkuOptions(combinedText).filter((option) => option.model === GENERIC_SUPPLIER_SKU_MODEL);
  if (!supplierOptions.length) return [];
  return requests.map((request, index) => {
    const option = supplierOptions.find((candidate) => supplierOptionMatchesPurchaseRequest(candidate, request))
      || supplierOptions.find((candidate) => candidate.color && isSameColorName(candidate.color, request.color));
    if (!option) return null;
    return {
      key: supplierOptionIdentity(option) || `supplier-sku-${index + 1}`,
      purchaseRowKey: `supplier-request-${index + 1}`,
      rowKey: `supplier-request-${index + 1}`,
      model: option.model,
      productName: "弹力带",
      outputProductName: "resistance band",
      color: option.color,
      displayColor: displayColorName(option.color),
      colorEnglish: colorName(option.color),
      size: option.size || request.size || "",
      variantStyle: option.variantStyle || request.style || "",
      spec: ["弹力带", option.variantStyle || request.style, displayColorName(option.color), option.size || request.size].filter(Boolean).join(" - "),
      outputSpec: outputVariantNameFromParts("resistance band", {
        color: option.color,
        size: option.size || request.size || "",
        style: translateSupplierSkuStyle(option.variantStyle || request.style || ""),
      }),
      sizeCode: [option.variantStyle || request.style, displayColorName(option.color), option.size || request.size].filter(Boolean).join(" / "),
      quantity: "",
      price: "",
      pack: "",
      productUnitCount: "",
      dims: option.dims || {},
      supplierOption: option,
      fit: "",
    };
  }).filter(Boolean);
}

function translateSupplierSkuStyle(value) {
  const compact = compactChineseText(value);
  const parts = [];
  if (/常规/.test(compact)) parts.push("regular");
  if (/加长/.test(compact)) parts.push("long");
  if (/加厚/.test(compact)) parts.push("thick");
  return parts.join(" ");
}

function skuRelevantPackValue(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean || /^[1-9]\d*$/.test(clean)) return "";
  if (!/(?:pcs|pieces?|片|pack|包|pairs?|双|件|只|个|set|套|盒|装)/i.test(clean)) return "";
  return clean;
}

function toCrossBorderProductName(productName, fallbackSpec) {
  if (!productName || productName.startsWith("[")) {
    return fallbackSpec || "";
  }
  if (/咖啡滤纸|Coffee Filters?|filter paper/i.test(productName)) {
    return fallbackSpec || "coffee paper filters";
  }
  const normalized = productName
    .replace(/[^\x00-\x7F\u4e00-\u9fff#/-]+/g, " ")
    .replace(/咖啡滤纸|滤纸|滴漏式手冲咖啡挂耳|冲咖啡挂耳/gi, "coffee filters")
    .replace(/原木浆|本色|原色/gi, "natural unbleached")
    .replace(/扇形/gi, "fan-shaped")
    .replace(/V形/gi, "cone")
    .replace(/盒装/gi, "box")
    .replace(/阿里巴巴|Amazon|Amazo/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return normalized;
}

function displayProductName(productName, context = "") {
  const combined = [productName, context].filter(Boolean).join(" ");
  const rawSpecName = readableNameFromRawSpec(combined);
  if (rawSpecName) return rawSpecName;
  if (isYogaSockText(combined)) return "五指瑜伽袜";
  if (/船袜|短袜|隐形袜|浅口袜|no[-\s]?show/i.test(combined)) return "船袜";
  if (isSockFamilyText(combined)) return "袜子";
  return cleanProductDisplayName(productName, "");
}

function crossBorderProductName(productName, context = "") {
  const rawSpecName = readableNameFromRawSpec([productName, context].filter(Boolean).join(" "));
  if (rawSpecName) return rawSpecName;
  const translated = translateProductTitleWords(productName, context);
  const translatedFromContext = translateProductTitleWords(extractFirstMatch(context, [/PRODUCT_TITLE:\s*([^\n]+)/i]), context);
  const coreTitle = compactCoreProductTitle(translated || productName, translatedFromContext || context);
  if (coreTitle) return coreTitle;
  if (translated) return translated;
  if (translatedFromContext) return translatedFromContext;
  return toCrossBorderProductName(productName, "") || stripSupplierModelCodes(cleanFieldDisplayValue(productName));
}

function crossBorderColorName(item) {
  return cleanFieldDisplayValue(item?.colorEnglish || outputColorName(item?.color || item?.displayColor || ""));
}

function compactEnglishWords(value, maxWords = 6) {
  return cleanFieldDisplayValue(value)
    .toLowerCase()
    .replace(/[^a-z0-9#/+ -]+/g, " ")
    .replace(/\b(?:women'?s|men'?s|for|and|with|the|a|an|professional|special|dedicated)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, maxWords)
    .join(" ");
}

function compactCoreProductTitle(value, source = "") {
  const descriptiveName = descriptiveYogaSockProductName(value, source);
  if (descriptiveName) return descriptiveName;
  const text = compactEnglishWords(value, 12);
  const combined = `${text} ${compactEnglishWords(source, 12)}`;
  if (!text && !combined.trim()) return "";
  if (/round/.test(combined) && /coffee\s+filter/.test(combined)) return "round coffee filter";
  if (/coffee\s+filter/.test(combined)) return "coffee filter";
  if (/filter\s+basket/.test(combined)) return "filter basket";
  if (/dosing\s+funnel/.test(combined)) return "dosing funnel";
  if (/pet\s+bandana|bandana|bib/.test(combined)) return "pet bandana";
  if (/cat\s+collar|collar/.test(combined)) return "cat collar";
  if (/cat\s+toy|matatabi/.test(combined)) return "cat toy";
  if (/resistance\s+band/.test(combined)) return "resistance band";
  if (/yoga\s+ball|pilates\s+ball/.test(combined)) return "yoga ball";
  if (/folding\s+umbrella|umbrella/.test(combined)) return "folding umbrella";
  if (/incense\s+sticks|incense/.test(combined)) return "incense sticks";
  if (/\byoga\b/.test(combined) && /\bsocks?\b/.test(combined)) return "yoga socks";
  if (/no\s+show/.test(combined) && /\bsocks?\b/.test(combined)) return "no-show socks";
  if (/\btoe\b/.test(combined) && /\bsocks?\b/.test(combined)) return "toe socks";
  if (/\bgrip\b/.test(combined) && /\bsocks?\b/.test(combined)) return "grip socks";
  if (/\bsocks?\b/.test(combined)) return "socks";
  const featureWords = new Set(["grip", "non", "slip", "cotton", "soft", "professional", "special", "dedicated", "solid", "color"]);
  const words = text.split(/\s+/).filter((word) => word && !featureWords.has(word));
  return uniquePromptItems(words).slice(0, 6).join(" ") || text;
}

function shortCrossBorderBaseName(productName, context = "") {
  const combined = [productName, context].filter(Boolean).join(" ");
  const coreTitle = compactCoreProductTitle(productName, context);
  if (coreTitle) return coreTitle;
  if (/round coffee filter|圆形咖啡滤纸/i.test(combined)) return "round coffee filter";
  if (/coffee filters?|咖啡滤纸|filter paper/i.test(combined)) return "coffee filter";
  if (/espresso filter basket|咖啡粉碗|粉碗/i.test(combined)) return "filter basket";
  if (/magnetic dosing funnel|接粉环/i.test(combined)) return "dosing funnel";
  if (/bandana|bib|围兜|口水巾/i.test(combined)) return "pet bandana";
  if (/collar|项圈/i.test(combined)) return "cat collar";
  if (/matatabi|cat toy|猫玩具|木天蓼/i.test(combined)) return "cat toy";
  if (/resistance band|拉力|弹力/i.test(combined)) return "resistance band";
  if (/umbrella|伞/i.test(combined)) return "folding umbrella";
  if (/incense|线香/i.test(combined)) return "incense sticks";
  return compactEnglishWords(crossBorderProductName(productName, context) || productName || "product", 6);
}

function shortCrossBorderOptionLabel(baseName, item, fallback = "product option") {
  const size = optionSizeForSkuLabel(item);
  const style = optionStyleForSkuLabel(item);
  const color = simpleColorName(item?.color || item?.displayColor || item?.colorEnglish || "");
  const pack = skuRelevantPackValue(item?.productUnitCount || item?.pack || "");
  const attributes = uniquePromptItems([
    style && !/^(?:regular|standard)$/i.test(style) ? style : "",
    color,
    /^(?:均码|one size|free size)$/i.test(size) ? "" : size,
    pack,
  ]).filter(Boolean);
  const label = [compactEnglishWords(baseName, 6), ...attributes].filter(Boolean).join("-");
  return displayVariantText(label || fallback);
}

function comparisonOptionLabel(item, fallback = "product option") {
  const size = optionSizeForSkuLabel(item);
  const style = optionStyleForSkuLabel(item);
  const color = simpleColorName(item?.color || item?.displayColor || item?.colorEnglish || "");
  const pack = skuRelevantPackValue(item?.productUnitCount || item?.pack || "");
  const parts = uniquePromptItems([
    color,
    /^(?:均码|one size|free size)$/i.test(size) ? "" : size,
    style && !/^(?:regular|standard)$/i.test(style) ? style : "",
    pack,
  ]).filter(Boolean);
  return displayVariantText(parts.join(" / ") || fallback);
}

function skuCurrentOptionText(item, fallback = "selected product option") {
  const cleanFallback = cleanOptionFallbackText(item?.outputSpec || item?.spec || item?.label, item);
  if (cleanFallback && cleanFallback !== displayVariantText(item?.outputProductName || item?.productName || "")) return cleanFallback;
  const color = crossBorderColorName(item);
  if (color) return color;
  const size = optionSizeForSkuLabel(item);
  const pack = skuRelevantPackValue(item?.productUnitCount || item?.pack || "");
  const style = optionStyleForSkuLabel(item);
  return displayVariantText([style, /^(?:均码|one size|free size)$/i.test(size) ? "" : size, pack].filter(Boolean).join(" / "))
    || cleanFallback
    || displayVariantText(fallback);
}

function cleanOptionFallbackText(value, item = {}) {
  const productName = displayVariantText(item?.outputProductName || item?.productName || "");
  let clean = displayVariantText(value);
  if (!clean || isCodeLikeValue(clean)) return "";
  clean = stripRepeatedValue(clean, productName);
  clean = stripRepeatedValue(clean, item?.productName || "");
  clean = stripRepeatedValue(clean, item?.outputProductName || "");
  clean = displayVariantText(clean);
  if (!clean) return productName;
  if (/[\u4e00-\u9fff]/.test(clean)) return productName;
  if (/(?:PURCHASE_ROW|Source HTML file|PRODUCT_ATTRIBUTE|SKU_OPTION|颜色|尺码|规格|数量|单价|金额|实付款|货品合计)/i.test(clean)) return productName;
  if (/\b\d+(?:\.\d+)?\s*(?:元|¥|￥)\b/i.test(clean)) return productName;
  if (clean.length > 48 || clean.split(/\s+/).filter(Boolean).length > 7) return productName;
  return clean;
}

function optionStyleForSkuLabel(item) {
  const style = compactEnglishWords(item?.variantStyle || "", 2);
  if (!style) return "";
  const quantity = cleanFieldDisplayValue(item?.quantity || "");
  const itemContext = [item?.productName, item?.outputProductName, item?.spec, item?.outputSpec, item?.label].filter(Boolean).join(" ");
  if (/^[1-9]\d?$/.test(style) && quantity && style === quantity) return "";
  if (/^[1-9]\d?$/.test(style) && isSockFamilyText(itemContext)) return "";
  return style;
}

function optionSizeForSkuLabel(item) {
  const size = cleanFieldDisplayValue(item?.size || "");
  if (!size) return "";
  const quantity = cleanFieldDisplayValue(item?.quantity || "");
  if (/^[1-9]\d*$/.test(size) && quantity && size === quantity) return "";
  const itemContext = [item?.productName, item?.outputProductName, item?.spec, item?.outputSpec, item?.label].filter(Boolean).join(" ");
  if (/^[1-9]\d?$/.test(size) && isSockFamilyText(itemContext)) return "";
  return size;
}

function crossBorderVariantName(productName, item, fallback = "Product") {
  const baseName = promptValue(productName, fallback) || fallback;
  const size = optionSizeForSkuLabel(item);
  const parts = [
    crossBorderColorName(item),
    /^(?:均码|one size)$/i.test(size) ? "" : size,
    item.productUnitCount || "",
  ].filter(Boolean);
  return displayVariantText([baseName, ...parts].filter(Boolean).join(" - "));
}

function variantAttributeParts(item, productUnitCount = "") {
  const size = optionSizeForSkuLabel(item);
  return [
    optionStyleForSkuLabel(item),
    item.displayColor || displayColorName(item.color, item.colorEnglish) || item.colorEnglish || colorName(item.color),
    /^(?:均码|one size)$/i.test(size) ? "" : size,
    productUnitCount,
  ].filter(Boolean);
}

function stripSupplierModelCodes(value) {
  return String(value || "")
    .replace(/\b(?!V02\b|U02\b|V60\b)[A-Z]{1,4}\d{2,5}\b/gi, " ")
    .replace(/\b[A-Z]{1,4}\d{2,4}\s+\d\b/gi, " ")
    .replace(/\s*-\s*-\s*/g, " - ")
    .replace(/\s+/g, " ")
    .replace(/^[\s,/-]+|[\s,/-]+$/g, "")
    .trim();
}

function displayVariantText(value) {
  const rawSpecName = readableNameFromRawSpec(value);
  if (rawSpecName) return rawSpecName;
  const source = stripSupplierModelCodes(value)
    .replace(/(?:^|[-\s/])(?:quantity|qty)\s*[:：]?\s*[1-9]\d*(?=$|[-\s/])/gi, " ")
    .replace(/(?:^|[-\s/])数量\s*[:：]?\s*[1-9]\d*(?=$|[-\s/])/gi, " ")
    .replace(/\b(?:model|colorEnglish|color|rawSpec|variantStyle|size)\s*=\s*[^;\n|/]+/gi, " ")
    .replace(/SKU_OPTION\s*[:;]+/gi, " ")
    .replace(/\s*-\s*(?=[-\s/]|$)/g, " ")
    .replace(/\s+/g, " ")
    .replace(/^[\s,/-]+|[\s,/-]+$/g, "")
    .trim();
  return isMachineProductText(source) ? "" : source;
}

function productVariantName(productName, item, fallback = "Product") {
  const baseName = promptValue(productName, fallback) || fallback;
  const parts = variantAttributeParts(item, item.productUnitCount || "");
  return displayVariantText([baseName, ...parts].filter(Boolean).join(" - "));
}

function productVariantLabel(productName, item, fallback = "Product") {
  return productVariantName(productName, item, fallback);
}

function disambiguateDuplicateLabels(items) {
  const counts = new Map();
  items.forEach((item) => {
    const key = String(item.label || "").trim().toLowerCase();
    if (!key) return;
    counts.set(key, (counts.get(key) || 0) + 1);
  });
  const seen = new Map();
  return items.map((item) => {
    const key = String(item.label || "").trim().toLowerCase();
    if (!key || (counts.get(key) || 0) < 2) return item;
    const index = (seen.get(key) || 0) + 1;
    seen.set(key, index);
    const suffix = `style ${index}`;
    return {
      ...item,
      label: `${item.label} - ${suffix}`,
      spec: item.spec ? `${item.spec} - ${suffix}` : item.spec,
      sizeCode: [item.sizeCode, suffix].filter(Boolean).join(" / "),
    };
  });
}

function dedupeExtractedVariants(items) {
  const seen = new Set();
  return items.filter((item) => {
    const colorKey = canonicalColorKey(item.colorEnglish || item.color || item.spec || item.label || "");
    const size = cleanFieldDisplayValue(item.size || item.sizeCode || "");
    const pack = cleanFieldDisplayValue(item.pack || item.productUnitCount || "");
    const style = cleanFieldDisplayValue(item.variantStyle || item.outputSpec || item.spec || item.label || "").toLowerCase();
    const model = String(item.model || item.key || "").toUpperCase();
    const rowKey = String(item.purchaseRowKey || item.rowKey || "").trim();
    const key = [model, colorKey, size, pack, style].filter(Boolean).join("|") || rowKey;
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizedColorVariantItems(items, purchaseText, combinedText) {
  if (!isSockFamilyText(combinedText)) return items;
  const purchaseColors = colorsFromPurchaseText(purchaseText);
  const colorItems = (items || []).filter((item) => isKnownColorValue(item.color || item.colorEnglish || item.displayColor || item.label || item.outputLabel || ""));
  if (!purchaseColors.length && !colorItems.length) return items;

  const baseItem = colorItems[0] || (items || []).find((item) => item?.model) || (items || [])[0] || {};
  const byColor = new Map();
  colorItems.forEach((item) => {
    const color = item.color || item.colorEnglish || item.displayColor || item.label || item.outputLabel || "";
    const key = canonicalColorKey(color);
    if (key && !byColor.has(key)) byColor.set(key, item);
  });

  const orderedColors = purchaseColors.length
    ? purchaseColors
    : colorItems.map((item) => item.color || item.colorEnglish || item.displayColor || item.label || item.outputLabel || "");
  return orderedColors
    .map((color, index) => {
      const key = canonicalColorKey(color);
      const existing = byColor.get(key) || {};
      const colorEnglish = colorName(color);
      const displayColor = displayColorName(color, colorEnglish);
      return {
        ...baseItem,
        ...existing,
        id: existing.id || `EXTRACTED-${index + 1}-${colorEnglish.replace(/[^A-Z0-9]+/gi, "-") || key || "COLOR"}`,
        label: colorEnglish,
        outputLabel: colorEnglish,
        displayLabel: colorEnglish,
        color,
        displayColor,
        colorEnglish,
        shape: colorEnglish,
        spec: displayColor || color,
        outputSpec: colorEnglish,
        sizeCode: displayColor || color,
        outputSizeCode: colorEnglish,
        variantStyle: "",
        pack: "",
        productUnitCount: "",
      };
    })
    .filter((item) => isKnownColorValue(item.color || item.colorEnglish));
}

function normalizeAmazonHeader(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function amazonCellText(value) {
  if (value == null) return "";
  return String(value).replace(/\s+/g, " ").trim();
}

function amazonColumnLookup(rows) {
  const labels = rows[3] || [];
  const attrs = rows[4] || [];
  const byLabel = new Map();
  const byAttr = new Map();
  labels.forEach((label, index) => {
    const key = normalizeAmazonHeader(label);
    if (key && !byLabel.has(key)) byLabel.set(key, index);
  });
  attrs.forEach((attr, index) => {
    const key = String(attr || "").trim();
    if (key && !byAttr.has(key)) byAttr.set(key, index);
  });

  const find = (...candidates) => {
    for (const candidate of candidates) {
      const labelKey = normalizeAmazonHeader(candidate);
      if (byLabel.has(labelKey)) return byLabel.get(labelKey);
      const attrMatch = Array.from(byAttr.keys()).find((attr) => attr === candidate || attr.includes(candidate));
      if (attrMatch) return byAttr.get(attrMatch);
    }
    return -1;
  };

  return { find };
}

function amazonRowValue(row, columns, ...candidates) {
  const index = columns.find(...candidates);
  return index >= 0 ? amazonCellText(row[index]) : "";
}

function workbookRows(workbook, sheetName) {
  if (!sheetName || !workbook.Sheets[sheetName]) return [];
  return window.XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1, defval: "" });
}

function amazonTemplateRowsLookValid(rows) {
  const labelRow = (rows[3] || []).map(amazonCellText);
  const attributeRow = (rows[4] || []).map(amazonCellText);
  return attributeRow.some((value) => /contribution_sku/i.test(value))
    && (labelRow.some((value) => /^SKU$/i.test(value)) || attributeRow.some((value) => /product_type|item_name/i.test(value)));
}

function findWorkbookSheetName(workbook, preferredNames, rowPredicate) {
  const sheetNames = workbook.SheetNames || [];
  const exactName = preferredNames.find((name) => sheetNames.includes(name));
  if (exactName && (!rowPredicate || rowPredicate(workbookRows(workbook, exactName)))) return exactName;
  return sheetNames.find((name) => rowPredicate?.(workbookRows(workbook, name))) || exactName || sheetNames[0];
}

function amazonTemplateSheetName(workbook) {
  return findWorkbookSheetName(workbook, ["Template", "模板"], amazonTemplateRowsLookValid);
}

function amazonBrowseSheetName(workbook) {
  return findWorkbookSheetName(workbook, ["Browse Data", "浏览数据"], (rows) => {
    const firstRows = rows.slice(0, 6).map((row) => row.map(amazonCellText).join(" ")).join(" ");
    return /Browse\s+Node/i.test(firstRows) && /Browse\s+Path/i.test(firstRows);
  });
}

function parseAmazonSkuFilter(value) {
  const source = String(value || "").trim();
  if (!source) return null;
  const rowNumbers = new Set();
  const skuValues = new Set();
  source
    .split(/[\s,，;；]+/)
    .map((item) => item.trim())
    .filter(Boolean)
    .forEach((item) => {
      const range = item.match(/^([1-9]\d*)\s*[-~]\s*([1-9]\d*)$/);
      if (range) {
        const start = Number(range[1]);
        const end = Number(range[2]);
        const min = Math.min(start, end);
        const max = Math.max(start, end);
        for (let rowNumber = min; rowNumber <= max; rowNumber += 1) rowNumbers.add(rowNumber);
        return;
      }
      if (/^[1-9]\d*$/.test(item)) {
        rowNumbers.add(Number(item));
        return;
      }
      skuValues.add(item.toLowerCase());
    });
  return {
    raw: source,
    rowNumbers,
    skuValues,
    hasFilter: rowNumbers.size > 0 || skuValues.size > 0,
  };
}

function amazonRowMatchesFilter(rowInfo, columns, filter) {
  if (!filter?.hasFilter) return true;
  const sku = amazonRowValue(rowInfo.row, columns, "SKU", "contribution_sku").toLowerCase();
  return filter.rowNumbers.has(rowInfo.excelRowNumber) || filter.skuValues.has(sku);
}

function amazonBulletPoints(row, columns) {
  const points = [];
  for (let index = 1; index <= 5; index += 1) {
    const attrValue = amazonRowValue(row, columns, `bullet_point[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#${index}.value`);
    if (attrValue && !points.includes(attrValue)) points.push(attrValue);
  }
  if (!points.length) {
    const fallback = amazonRowValue(row, columns, "Bullet Point", "bullet_point");
    if (fallback) points.push(fallback);
  }
  return points;
}

function amazonRepeatedRowValues(row, columns, attributeBase, fallbackLabel, limit = 5) {
  const values = [];
  for (let index = 1; index <= limit; index += 1) {
    const attrValue = amazonRowValue(row, columns, `${attributeBase}#${index}.value`);
    if (attrValue && !values.includes(attrValue)) values.push(attrValue);
  }
  if (!values.length && fallbackLabel) {
    const fallback = amazonRowValue(row, columns, fallbackLabel, attributeBase);
    if (fallback) values.push(fallback);
  }
  return values;
}

function amazonListingUseSceneText({ title = "", description = "", bullets = [], keywords = [], occasions = [], compatibleUses = [], category = "" } = {}) {
  return uniquePromptItems([
    ...occasions,
    ...compatibleUses,
    inferUseScene([title, description, bullets.join(" "), keywords.join(" "), category].filter(Boolean).join(" ")),
  ].map((value) => cleanFieldDisplayValue(value))).slice(0, 4).join(" / ");
}

function amazonListingCompatibleUseText({ title = "", description = "", bullets = [], keywords = [], occasions = [], compatibleUses = [], category = "" } = {}) {
  return uniquePromptItems([
    ...compatibleUses,
    extractFirstMatch([title, description, bullets.join(" "), keywords.join(" "), category].filter(Boolean).join(" "), [
      /(?:compatible with|fits?|for use with|适配|适用于)[:：]?\s*([^\n。；;|]{2,100})/i,
    ]),
  ].map((value) => cleanFieldDisplayValue(value))).slice(0, 3).join(" / ");
}

function amazonListingStructureText({ text = "", material = "", style = "", itemShape = "", itemForm = "", paperFinish = "", designName = "", height = "", heelType = "" } = {}) {
  const isThong = isThongFlipFlopText(text);
  return compactPromptItems([
    isThong ? "thong flip-flop construction with one Y-shaped strap, central toe post, visible front slit/open hole, exposed footbed texture, open heel with no back strap" : "",
    !isThong && /backstrap/i.test(text) ? "backstrap closure" : "",
    itemShape && `${itemShape} shape`,
    itemForm && `${itemForm} form`,
    style && `${style} style`,
    designName && `${designName} design`,
    paperFinish && `${paperFinish} finish`,
    material && `${material} material`,
    height && `${height} profile`,
    heelType && `${heelType} heel`,
  ], "", 6);
}

function amazonListingPackText(text, row, columns) {
  const count = extractFirstMatch(text, [
    /\b([1-9]\d*\s*(?:sheets?|pcs|pieces?|count|counts|rolls?|packs?|sets?))\b/i,
    /\b(pack\s+of\s+[1-9]\d*)\b/i,
  ]);
  if (count) return count;
  const itemPackageQuantity = amazonRowValue(row, columns, "Item Package Quantity", "item_package_quantity[marketplace_id=ATVPDKIKX0DER]#1.value");
  const numberOfItems = amazonRowValue(row, columns, "Number of Items", "number_of_items[marketplace_id=ATVPDKIKX0DER]#1.value");
  return [itemPackageQuantity, numberOfItems]
    .map((value) => cleanFieldDisplayValue(value))
    .find((value) => value && !/^1$/.test(value)) || "";
}

function amazonListingDimensionListText(row, columns) {
  const size = amazonRowValue(row, columns, "Size", "size[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
  const paperSize = amazonRowValue(row, columns, "Paper Size", "paper_size[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
  const paperSizeUnit = amazonRowValue(row, columns, "Paper Size Unit", "paper_size[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.unit");
  const displayLength = amazonRowValue(row, columns, "Item Display Length", "item_display_dimensions[marketplace_id=ATVPDKIKX0DER]#1.length.value");
  const displayLengthUnit = amazonRowValue(row, columns, "Item Display Length Unit", "item_display_dimensions[marketplace_id=ATVPDKIKX0DER]#1.length.unit");
  const dimensions = uniquePromptItems([
    size && `Size: ${size}`,
    paperSize && `Paper Size: ${paperSize}${paperSizeUnit ? ` ${paperSizeUnit}` : ""}`,
    displayLength && `Display Length: ${displayLength}${displayLengthUnit ? ` ${displayLengthUnit}` : ""}`,
  ]);
  return dimensions.length ? `[VERIFIED_DIMENSIONS: ${dimensions.join("; ")}]` : "";
}

function amazonFactsWithFallback(primary, fallback) {
  const merged = { ...fallback };
  Object.entries(primary || {}).forEach(([key, value]) => {
    const hasValue = Array.isArray(value) ? value.length : cleanFieldDisplayValue(value);
    if (hasValue) merged[key] = value;
  });
  return merged;
}

function amazonVariantAttributes(row, columns, theme) {
  const themeParts = String(theme || "")
    .split("/")
    .map((item) => item.trim().toUpperCase())
    .filter(Boolean);
  const attrs = {};
  if (!themeParts.length || themeParts.includes("COLOR")) {
    attrs.color = amazonRowValue(row, columns, "Color", "color[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
    attrs.colorMap = amazonRowValue(row, columns, "Color Map", "color[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.standardized_values#1");
  }
  if (!themeParts.length || themeParts.includes("SIZE")) {
    attrs.size = amazonRowValue(
      row,
      columns,
      "Size",
      "Size Name",
      "尺码",
      "尺寸",
      "size[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value",
      "size_name[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value",
      "size_name",
    ) || amazonRowValue(
      row,
      columns,
      "Footwear Size",
      "鞋码",
      "footwear_size[marketplace_id=ATVPDKIKX0DER]#1.size",
      "footwear_size",
    );
  }
  if (themeParts.includes("NUMBER_OF_ITEMS")) {
    attrs.numberOfItems = amazonRowValue(row, columns, "Number Of Items", "number_of_items");
  }
  if (themeParts.includes("TEAM_NAME")) {
    attrs.teamName = amazonRowValue(row, columns, "Team Name", "team_name");
  }
  return attrs;
}

function extractAmazonVariantSizeFromText(...values) {
  const text = values.map(amazonCellText).filter(Boolean).join(" ");
  return extractFirstMatch(text, [
    /\b(US\s*Size\s*[0-9]+(?:\.[0-9]+)?(?:\s*(?:-|–|~|to)\s*[0-9]+(?:\.[0-9]+)?)?)\b/i,
    /\b(?:Size|Sz)\s*[:#-]?\s*([0-9]+(?:\.[0-9]+)?(?:\s*(?:-|–|~|to)\s*[0-9]+(?:\.[0-9]+)?)?)\b/i,
    /(?:^|[-_\s])([0-9]{1,2}(?:\.[0-9]+)?)(?:[-_\s]?[A-Z])?$/i,
  ]).replace(/^US\s*Size/i, "US Size").replace(/^([0-9])/, "US Size $1");
}

function compactAmazonTitle(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean) return "";
  const firstClause = clean.split(/\s*,\s*/)[0] || clean;
  return compactEnglishWords(firstClause, 8) || clean;
}

function englishAmazonValue(value) {
  const clean = cleanFieldDisplayValue(value);
  if (!clean || /[\u4e00-\u9fff]/.test(clean)) return "";
  return clean;
}

function isThongFlipFlopText(value) {
  return /thong|toe\s*post|y[-\s]?strap|y\s*shaped|人字拖|夹脚|夹趾/i.test(String(value || ""));
}

function thongFlipFlopStructureLockText() {
  return "Thong flip-flop anatomy lock: exactly one Y-shaped thong strap splitting from one central toe post into two side anchors; visible front toe-post slit/open hole and negative space around the post; footbed texture visible between/inside the Y straps; open heel; no sealed triangular vamp, no closed/filled front, no heel/back/ankle strap, no second parallel strap, no wide slide band.";
}

function thongFlipFlopShortLockText() {
  return "Keep thong anatomy: Y strap, central toe post, visible front slit/open hole, exposed footbed, open heel.";
}

function amazonSharedFacts(row, columns, browsePath = "") {
  const bullets = amazonBulletPoints(row, columns);
  const title = amazonRowValue(row, columns, "Item Name", "item_name");
  const description = amazonRowValue(row, columns, "Product Description", "product_description");
  const keywords = amazonRepeatedRowValues(row, columns, "generic_keyword[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]", "Generic Keyword");
  const occasionTypes = amazonRepeatedRowValues(row, columns, "occasion_type[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]", "Occasion");
  const occasions = uniquePromptItems([
    ...occasionTypes,
    ...amazonRepeatedRowValues(row, columns, "occasion[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]", "Occasion"),
  ]);
  const compatibleUses = amazonRepeatedRowValues(row, columns, "recommended_uses_for_product[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]", "Recommended Uses For Product");
  const style = amazonRowValue(row, columns, "Product Style", "Style", "style[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value", "style");
  const itemShape = amazonRowValue(row, columns, "Item Shape", "item_shape[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
  const itemForm = amazonRowValue(row, columns, "Item Form", "item_form[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
  const paperFinish = amazonRowValue(row, columns, "Paper Finish", "paper_finish[marketplace_id=ATVPDKIKX0DER]#1.value");
  const designName = amazonRowValue(row, columns, "Design Name", "design_name[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]#1.value");
  const material = uniquePromptItems([
    ...amazonRepeatedRowValues(row, columns, "material[marketplace_id=ATVPDKIKX0DER][language_tag=en_US]", "Material"),
    amazonRowValue(row, columns, "Material", "material")
    || amazonRowValue(row, columns, "Sole Material", "sole_material")
    || amazonRowValue(row, columns, "Outer Material", "outer")
    || amazonRowValue(row, columns, "Compliance - Upper Material", "compliance_upper_material"),
  ]).join(", ");
  const height = amazonRowValue(row, columns, "Height Map", "height_map");
  const heelType = amazonRowValue(row, columns, "Heel Type", "heel[marketplace_id");
  const targetGender = amazonRowValue(row, columns, "Target Gender", "target_gender");
  const ageRange = amazonRowValue(row, columns, "Age Range Description", "age_range_description");
  const productType = amazonRowValue(row, columns, "Product Type", "product_type");
  const category = amazonRowValue(row, columns, "Item Type Keyword", "item_type_keyword") || browsePath;
  const productText = `${title} ${description} ${bullets.join(" ")} ${keywords.join(" ")} ${occasions.join(" ")}`;
  const englishCategory = englishAmazonValue(category);
  const readableProductType = productType ? productType.toLowerCase().replace(/_/g, " ") : "";
  const scenes = amazonListingUseSceneText({ title, description, bullets, keywords, occasions, compatibleUses, category });
  const fit = amazonListingCompatibleUseText({ title, description, bullets, keywords, occasions, compatibleUses, category });
  const structure = amazonListingStructureText({
    text: productText,
    material,
    style,
    itemShape,
    itemForm,
    paperFinish,
    designName,
    height,
    heelType,
  });
  const pack = amazonListingPackText(productText, row, columns);
  const dimensionList = amazonListingDimensionListText(row, columns);

  return {
    title,
    shortTitle: compactAmazonTitle(title),
    description,
    bullets,
    productType,
    readableProductType,
    category,
    englishCategory,
    material,
    structure,
    scene: scenes,
    fit,
    pack,
    feature1: bullets[0] || style || "",
    feature2: bullets[1] || bullets[2] || "",
    surfaceFinish: paperFinish,
    dimensionList,
    detailParameter: compactPromptItems([
      style,
      itemShape,
      itemForm,
      designName,
      paperFinish,
      targetGender,
      ageRange,
      occasions.join(", "),
      englishCategory,
    ], "", 8),
  };
}

function amazonRowsToProducts(rows, browsePath = "", skuFilter = "") {
  if (!rows.length) return [];
  const columns = amazonColumnLookup(rows);
  const filter = parseAmazonSkuFilter(skuFilter);
  const dataRowInfos = rows
    .slice(6)
    .map((row, index) => ({ row, excelRowNumber: index + 7 }))
    .filter((rowInfo) => amazonRowValue(rowInfo.row, columns, "SKU", "contribution_sku"));
  if (!dataRowInfos.length) return [];

  const rowsBySku = new Map();
  dataRowInfos.forEach((rowInfo) => {
    rowsBySku.set(amazonRowValue(rowInfo.row, columns, "SKU", "contribution_sku"), rowInfo.row);
  });
  const filteredRowInfos = filter?.hasFilter
    ? dataRowInfos.filter((rowInfo) => amazonRowMatchesFilter(rowInfo, columns, filter))
    : dataRowInfos;
  const childRowInfos = filteredRowInfos.filter((rowInfo) => /child/i.test(amazonRowValue(rowInfo.row, columns, "Parentage Level", "parentage_level")));
  const sourceRowInfos = childRowInfos.length ? childRowInfos : filteredRowInfos;
  if (!sourceRowInfos.length) {
    throw new Error(`Amazon 模板中没有匹配“${filter.raw}”的子 SKU，请检查行号范围或 SKU。`);
  }
  const parentRow = dataRowInfos.find((rowInfo) => /parent/i.test(amazonRowValue(rowInfo.row, columns, "Parentage Level", "parentage_level")))?.row || dataRowInfos[0].row;
  const shared = amazonSharedFacts(parentRow, columns, browsePath);
  const variantLabels = [];

  const products = sourceRowInfos.map((rowInfo, index) => {
    const row = rowInfo.row;
    const sku = amazonRowValue(row, columns, "SKU", "contribution_sku");
    const parentSku = amazonRowValue(row, columns, "Parent SKU", "parent_sku");
    const theme = amazonRowValue(row, columns, "Variation Theme Name", "variation_theme") || amazonRowValue(parentRow, columns, "Variation Theme Name", "variation_theme");
    const listing = amazonFactsWithFallback(amazonSharedFacts(row, columns, browsePath), shared);
    const attrs = amazonVariantAttributes(row, columns, theme);
    const rowTitle = amazonRowValue(row, columns, "Item Name", "item_name");
    if (/SIZE/i.test(theme || "") && !attrs.size) {
      attrs.size = extractAmazonVariantSizeFromText(rowTitle, sku);
    }
    const optionParts = [
      attrs.color,
      attrs.size && !/^(?:one size|free size)$/i.test(attrs.size) ? attrs.size : "",
      attrs.numberOfItems,
      attrs.teamName,
    ].filter(Boolean);
    const optionLabel = optionParts.join(" / ") || sku;
    variantLabels.push(optionLabel);
    const productName = displayVariantText([listing.shortTitle || "Amazon template product", attrs.color, attrs.size].filter(Boolean).join(" - "));
    const sizeCode = displayVariantText(optionParts.join(" / "));
    return {
      id: `EXTRACTED-AMAZON-${index + 1}-${sku.replace(/[^A-Z0-9]+/gi, "-")}`,
      label: `${sku} | ${optionLabel}`,
      displayLabel: `${sku} | ${optionLabel}`,
      productName,
      baseProductName: listing.shortTitle || "Amazon template product",
      shape: productName,
      model: sku,
      parentSku,
      amazonRowNumber: rowInfo.excelRowNumber,
      color: attrs.color || attrs.colorMap || "",
      displayColor: attrs.color || attrs.colorMap || "",
      colorEnglish: attrs.color || attrs.colorMap || "",
      size: attrs.size || "",
      variantStyle: "",
      sizeCode,
      outputSizeCode: sizeCode,
      pack: listing.pack || "",
      material: listing.material,
      structure: listing.structure,
      scene: listing.scene,
      feature1: listing.feature1,
      feature2: listing.feature2,
      surfaceFinish: listing.surfaceFinish || "",
      fit: listing.fit,
      detailParameter: listing.detailParameter,
      groupKey: parentSku || amazonRowValue(parentRow, columns, "SKU", "contribution_sku") || "amazon-template",
      group: {
        promptName: listing.shortTitle || listing.title || "Amazon template product",
        promptSpecs: [listing.readableProductType, listing.englishCategory, theme, listing.pack, listing.material, listing.structure, listing.scene].filter(Boolean),
        dimensions: listing.dimensionList ? extractDimensions(listing.dimensionList) : [],
        evidenceNote: `Amazon 模板：按 Child SKU 提取 ${sourceRowInfos.length} 个采购款式；变体主题 ${theme || "未填写"}。${filter?.hasFilter ? `筛选：${filter.raw}。` : ""}`,
      },
      dims: {
        cupRange: "",
        source: `Amazon 模板：Child SKU = 款式数量；${theme || "变体"} = 款式属性。`,
      },
      singleSpec: `[CURRENT_PRODUCT_OPTION: ${optionLabel}]`,
      specList: `[SPEC_LIST: ${[listing.shortTitle, optionLabel, listing.pack, listing.material, listing.structure, listing.scene].filter(Boolean).join(" / ")}]`,
      variantList: "",
      dimensionList: listing.dimensionList || "",
    };
  });

  const variantList = `[VARIANT_LIST: ${uniquePromptItems(variantLabels).join(" | ")}]`;
  return products.map((product) => ({ ...product, variantList }));
}

async function extractAmazonTemplateProducts(file, skuFilter = "") {
  if (!file) return { products: [], sourceText: "" };
  const workbook = await readWorkbook(file);
  const sheetName = amazonTemplateSheetName(workbook);
  const templateRows = workbookRows(workbook, sheetName);
  const browseName = amazonBrowseSheetName(workbook);
  const browseRows = browseName
    ? workbookRows(workbook, browseName)
    : [];
  const browsePath = browseRows.slice(1).map((row) => row.filter(Boolean).join(" > ")).filter(Boolean)[0] || "";
  const products = amazonRowsToProducts(templateRows, browsePath, skuFilter);
  const parentSkus = uniquePromptItems(products.map((product) => product.parentSku).filter(Boolean));
  const sourceText = products.length
    ? [
      `Amazon template file: ${file.name}`,
      `AMAZON_TEMPLATE_SHEET: ${sheetName || "not found"}`,
      `AMAZON_TEMPLATE_RULE: Child SKU count = ${products.length}; variant theme fields define style attributes.`,
      skuFilter ? `AMAZON_TEMPLATE_FILTER: ${skuFilter}` : "",
      parentSkus.length ? `PARENT_SKU: ${parentSkus.join(", ")}` : "",
      `VARIANTS: ${products.map((product) => product.label).join(" | ")}`,
    ].filter(Boolean).join("\n")
    : "";
  return { products, sourceText };
}

function mergedAmazonProductWithSupplierFacts(amazonProduct, supplierProduct, supplierBaseName) {
  const supplierName = cleanFieldDisplayValue(
    supplierProduct.outputProductName
      || supplierProduct.baseProductName
      || supplierProduct.productName
      || supplierBaseName
      || defaultProductName(supplierProduct)
  );
  const amazonOption = displayVariantText(amazonProduct.sizeCode || amazonProduct.outputSizeCode || cleanTokenValue(amazonProduct.singleSpec) || "");
  const amazonBaseName = cleanFieldDisplayValue(
    amazonProduct.baseProductName
      || amazonProduct.productName
      || defaultProductName(amazonProduct)
  );
  const baseName = amazonBaseName || supplierName;
  const productName = displayVariantText([
    baseName,
    amazonOption && !promptItemsOverlap(baseName, amazonOption) ? amazonOption : "",
  ].filter(Boolean).join(" - ")) || amazonProduct.productName || supplierName;
  const supplierGroup = supplierProduct.group || {};
  const amazonGroup = amazonProduct.group || {};
  const dimensions = (amazonGroup.dimensions || []).length ? amazonGroup.dimensions : (supplierGroup.dimensions || []);
  const dimensionList = amazonProduct.dimensionList
    || supplierProduct.dimensionList
    || (dimensions.length ? `[VERIFIED_DIMENSIONS: ${dimensions.join("; ")}]` : "");
  const material = amazonProduct.material || supplierProduct.material || "";
  const structure = amazonProduct.structure || supplierProduct.structure || "";
  const scene = amazonProduct.scene || supplierProduct.scene || "";
  const feature1 = amazonProduct.feature1 || supplierProduct.feature1 || "";
  const feature2 = amazonProduct.feature2 || supplierProduct.feature2 || "";
  const fit = amazonProduct.fit || supplierProduct.fit || "";
  const detailParameter = amazonProduct.detailParameter || supplierProduct.detailParameter || "";
  const promptSpecs = uniquePromptItems([
    productName,
    amazonOption,
    amazonProduct.pack || supplierProduct.pack,
    material,
    structure,
    scene,
  ]).filter(Boolean);
  const evidenceNote = compactPromptItems([
    amazonProduct.group?.evidenceNote || "Amazon listing：优先采用模板中的 listing 字段和 Child SKU 款式结构。",
    "1688 / 采购单：仅补充 Amazon 未填写的材质、结构、场景、卖点、尺寸等参数。",
  ], "Amazon listing 优先，1688 补缺。", 4);

  return {
    ...amazonProduct,
    productName,
    baseProductName: amazonBaseName || supplierName || productName,
    shape: productName || amazonProduct.shape || supplierProduct.shape,
    pack: amazonProduct.pack || supplierProduct.pack || "",
    material,
    structure,
    scene,
    feature1,
    feature2,
    feature3: "",
    surfaceFinish: amazonProduct.surfaceFinish || supplierProduct.surfaceFinish || "",
    fit,
    detailParameter,
    bundleComponents: amazonProduct.bundleComponents || supplierProduct.bundleComponents || "",
    dims: amazonProduct.dims || supplierProduct.dims,
    dimensionList,
    cupRange: amazonProduct.cupRange || amazonProduct.dims?.cupRange || supplierProduct.cupRange || supplierProduct.dims?.cupRange || "",
    group: {
      promptName: productName || amazonGroup.promptName || supplierName || supplierGroup.promptName || "",
      promptSpecs,
      dimensions,
      evidenceNote,
    },
    singleSpec: `[CURRENT_PRODUCT_OPTION: ${[productName, amazonOption].filter(Boolean).join(", ")}]`,
    specList: `[SPEC_LIST: ${promptSpecs.join(" / ")}]`,
    variantList: amazonProduct.variantList || supplierProduct.variantList || "",
  };
}

function supplierProductForAmazonVariant(supplierProducts, amazonProduct, index) {
  if (!supplierProducts.length) return {};
  if (supplierProducts.length === 1) return supplierProducts[0];
  const amazonText = [
    amazonProduct.color,
    amazonProduct.displayColor,
    amazonProduct.colorEnglish,
    amazonProduct.size,
    amazonProduct.sizeCode,
    amazonProduct.outputSizeCode,
    amazonProduct.label,
  ].filter(Boolean).join(" ").toLowerCase();
  const matched = supplierProducts.find((product) => {
    const supplierText = [
      product.color,
      product.displayColor,
      product.colorEnglish,
      product.size,
      product.sizeCode,
      product.outputSizeCode,
      product.label,
    ].filter(Boolean).join(" ").toLowerCase();
    return supplierText && amazonText && (promptItemsOverlap(supplierText, amazonText) || promptItemsOverlap(amazonText, supplierText));
  });
  return matched || supplierProducts[index % supplierProducts.length] || supplierProducts[0];
}

function mergeAmazonProductsWithSupplierFacts(amazonProducts, supplierProducts) {
  if (!amazonProducts.length || !supplierProducts.length) return amazonProducts;
  const supplierBaseName = cleanFieldDisplayValue(
    supplierProducts[0].outputProductName
      || supplierProducts[0].baseProductName
      || supplierProducts[0].productName
      || defaultProductName(supplierProducts[0])
  );
  return amazonProducts.map((amazonProduct, index) => mergedAmazonProductWithSupplierFacts(
    amazonProduct,
    supplierProductForAmazonVariant(supplierProducts, amazonProduct, index),
    supplierBaseName
  ));
}

function inferProductsFromSources(purchaseText, supplierText, competitorText) {
  const primaryText = productIdentitySourceText(purchaseText, supplierText);
  const attributeText = [primaryText, supplierText].filter(Boolean).join(" ");
  const combined = [attributeText, competitorText].join(" ");
  const supplierAttrs = supplierAttributeMap(supplierText);
  const identityAttrs = supplierAttributeMap(primaryText);
  const productName = inferProductName(primaryText);
  const isYogaSockFamily = isYogaSockText(primaryText);
  const isSockFamily = isSockFamilyText(primaryText);
  const detailAttributes = supplierAttributeMap(supplierText);
  const material = detailAttributes.Material
    || (/wood pulp|原木浆|木浆|unbleached/i.test(primaryText)
    ? "natural wood pulp paper / unbleached brown paper"
    : /TPE|tpe|热塑性弹性体/i.test(primaryText)
      ? "TPE thermoplastic elastomer"
    : /主面料成分["：:]*棉|棉|cotton/i.test(primaryText) || /棉|cotton/i.test(supplierAttrs.Material || "")
      ? translateAttributeValue("Material", supplierAttrs.Material) || "cotton blend fabric"
    : "");
  const color = isSockFamily ? "" : /brown|本色|原色|natural/i.test(primaryText) ? "natural brown" : "";
  const isCoffeeFilterFamily = /coffee filters|咖啡滤纸|V02|扇形02|扇形04|U02|#04/i.test(primaryText);
  const detailTechnology = identityAttrs.Technology || detailAttributes.Technology || "";
  const detailSpecialCraft = identityAttrs.SpecialCraft || detailAttributes.SpecialCraft || "";
  const sockStructure = isSockFamily ? compactSpecificPromptItems([
    hasCrossStrapDesign(primaryText) ? "3D cross-strap design" : "",
    hasFiveToeDesign(primaryText) ? "five-toe separated design" : "",
    detailTechnology,
  ], "", 4) : "";
  const umbrellaStructure = umbrellaStructureText(attributeText);
  const genericStructure = genericStructureText(attributeText || primaryText);
  const structure = isSockFamily
      ? sockStructure || "sock construction matched to source product"
    : umbrellaStructure
      ? umbrellaStructure
    : genericStructure
      ? genericStructure
    : /pressed|压边|压纹|fold|折边/i.test(primaryText) || isCoffeeFilterFamily
      ? "pressed side seam and bottom fold"
    : "";
  const scene = inferUseScene(attributeText || primaryText || combined);
  const sellingPoints = inferSellingPoints(attributeText, material, 6);
  const extraSellingPointText = remainingSellingPointText(sellingPoints.points || [], 2, 4);
  const extractedSellingPointSet = uniqueSellingPoints(sellingPoints.points || [], 6);
  const globalSellingPoint1 = sellingPointGroupText(distributedSellingPointGroups(extractedSellingPointSet, 0, 2, 4));
  const globalSellingPoint2 = sellingPointGroupText(distributedSellingPointGroups(extractedSellingPointSet, 1, 2, 4));
  const dimensions = isSockFamily ? [] : extractDimensions(attributeText);
  const sizeOrRange = detailAttributes.Size
    || (isCoffeeFilterFamily ? extractFirstMatch(primaryText, [/([0-9]+\s*-\s*[0-9]+\s*(?:cups|人份))/i]) : "");
  const capacityOrWeight = detailAttributes.Capacity || detailAttributes.Weight || "";
  const productUnitCount = isSockFamily ? "" : skuRelevantPackValue(extractProductUnitCount(supplierText));
  const cleanProductName = toCrossBorderProductName(productName, "");
  const displayName = displayProductName(cleanProductName || productName, combined) || cleanProductName;
  const outputName = crossBorderProductName(cleanProductName || productName, combined) || cleanProductName || displayName;
  const batchBaseName = shortCrossBorderBaseName(outputName || productName || displayName, combined) || "product";
  const purchaseItems = extractPurchaseItems(purchaseText, combined);
  const supplierOnlyOptions = extractSupplierSkuOptions(supplierText)
    .filter((option) => option.model && (option.rawSpec || option.color || option.size || option.dims?.topWidth || option.dims?.weight));
  const variants = [];

  if (purchaseItems.length) {
    variants.push(...purchaseItems.map((item, index) => {
      const itemUnitCount = skuRelevantPackValue(productUnitCountForItem(item, supplierText));
      const itemDisplayColor = displayColorName(item.displayColor || item.color, item.colorEnglish);
      const itemForOutput = { ...item, productUnitCount: itemUnitCount };
      const itemDisplayName = displayProductName(item.productName || displayName, combined) || item.productName || displayName;
      const itemOutputBaseName = isYogaSockFamily
        ? outputName
        : item.outputProductName || crossBorderProductName(item.productName || outputName, combined) || outputName;
      const shortBaseName = batchBaseName || shortCrossBorderBaseName(itemOutputBaseName || itemDisplayName || outputName, combined);
      const shortOptionLabel = comparisonOptionLabel(itemForOutput, shortCrossBorderOptionLabel(shortBaseName, itemForOutput, `product ${index + 1}`));
      return {
        id: `EXTRACTED-${index + 1}-${[item.colorEnglish || item.color, item.size, itemUnitCount].filter(Boolean).join("-").replace(/[^A-Z0-9]+/gi, "-") || "ITEM"}`,
        label: productVariantLabel(itemDisplayName, { ...item, displayColor: itemDisplayColor, productUnitCount: itemUnitCount }, `Product ${index + 1}`),
        outputLabel: shortOptionLabel,
        key: item.key,
        purchaseRowKey: item.purchaseRowKey || item.rowKey,
        model: item.model,
        productName: itemDisplayName,
        outputProductName: itemOutputBaseName,
        color: item.color,
        displayColor: itemDisplayColor,
        colorEnglish: item.colorEnglish,
        size: item.size,
        variantStyle: item.variantStyle,
        productUnitCount: itemUnitCount,
        spec: item.spec || productVariantName(itemDisplayName, { ...item, displayColor: itemDisplayColor, productUnitCount: itemUnitCount }, `Product ${index + 1}`),
        outputSpec: item.outputSpec || crossBorderVariantName(itemOutputBaseName, itemForOutput, `Product ${index + 1}`),
        sizeCode: item.sizeCode || variantAttributeParts(item, itemUnitCount).join(" / "),
        outputSizeCode: [crossBorderColorName(itemForOutput), /^(?:均码|one size)$/i.test(cleanFieldDisplayValue(item.size || "")) ? "" : cleanFieldDisplayValue(item.size || "")].filter(Boolean).join(" / "),
        cupRange: item.cupRange,
        pack: itemUnitCount,
        quantity: item.quantity,
        dims: item.dims,
        fit: item.fit,
        supplierOption: item.supplierOption,
      };
    }));
  } else {
    const supplierOnlyVariants = supplierOnlyOptions.map((option, index) => {
      const itemDisplayColor = displayColorName(option.color, option.colorEnglish);
      const itemForOutput = {
        ...option,
        displayColor: itemDisplayColor,
        productUnitCount: "",
        pack: "",
      };
      const optionBaseName = displayName || productName || `Product ${index + 1}`;
      const optionOutputName = outputName || crossBorderProductName(optionBaseName, combined) || optionBaseName;
      return {
        id: `EXTRACTED-SUPPLIER-${index + 1}-${[option.colorEnglish || option.color, option.size].filter(Boolean).join("-").replace(/[^A-Z0-9]+/gi, "-") || "SKU"}`,
        label: productVariantLabel(optionBaseName, itemForOutput, `Product ${index + 1}`),
        outputLabel: shortCrossBorderOptionLabel(batchBaseName, itemForOutput, `product ${index + 1}`),
        key: supplierOptionIdentity(option) || `supplier-sku-${index + 1}`,
        model: option.model,
        productName: optionBaseName,
        outputProductName: optionOutputName,
        color: option.color,
        displayColor: itemDisplayColor,
        colorEnglish: option.colorEnglish || colorName(option.color),
        size: option.size,
        material: option.material,
        variantStyle: option.variantStyle,
        spec: [optionBaseName, itemDisplayColor, option.size].filter(Boolean).join(" - "),
        outputSpec: crossBorderVariantName(optionOutputName, itemForOutput, `Product ${index + 1}`),
        sizeCode: variantAttributeParts(itemForOutput).join(" / "),
        outputSizeCode: [crossBorderColorName(itemForOutput), /^(?:均码|one size)$/i.test(cleanFieldDisplayValue(option.size || "")) ? "" : cleanFieldDisplayValue(option.size || "")].filter(Boolean).join(" / "),
        pack: "",
        productUnitCount: "",
        dims: option.dims,
        fit: "",
        supplierOption: option,
      };
    });
    variants.push(...supplierOnlyVariants);
    if (/V02|V形|V60/i.test(combined)) variants.push({ ...productSpecForToken("V02"), id: "EXTRACTED-V02", label: "Extracted | V02" });
    if (/#02|U02|U102|扇形02|fan-shaped 02/i.test(combined)) variants.push({ ...productSpecForToken("fan 02"), id: "EXTRACTED-U02", label: "Extracted | Fan 02 / U02" });
    if (/#04|扇形04|fan-shaped 04/i.test(combined)) variants.push({ ...productSpecForToken("fan 04"), id: "EXTRACTED-U04", label: "Extracted | Fan 04" });
  }

  const colorScopedVariants = normalizedColorVariantItems(variants, purchaseText, combined);
  const normalizedVariants = colorScopedVariants.length ? disambiguateDuplicateLabels(dedupeExtractedVariants(colorScopedVariants)) : [{
    id: "EXTRACTED-PRODUCT-1",
    label: displayName || "Product 1",
    outputLabel: outputName || "Product 1",
    spec: "",
    outputSpec: "",
    sizeCode: "",
    outputSizeCode: "",
    pack: productUnitCount || "",
    fit: "",
  }];

  return normalizedVariants.map((item) => {
    const itemCupRange = isCoffeeFilterFamily
      ? inferCupRangeForSpec(combined, item) || item.cupRange || sizeOrRange || ""
      : validSizeRangeValue(sizeOrRange || item.cupRange || item.size || item.outputSizeCode || item.sizeCode || "");
    const fallbackDimensions = fallbackDimensionsForSpec(item, combined);
    const itemDimensions = [
      item.dims?.topWidth && `Length: ${item.dims.topWidth}`,
      item.dims?.sideLength && `Width: ${item.dims.sideLength}`,
      item.dims?.bottomWidth && `${thirdDimensionLabel([combined, item.spec, item.sizeCode].filter(Boolean).join(" "))}: ${item.dims.bottomWidth}`,
      capacityOrWeight && `${detailAttributes.Capacity ? "Capacity" : "Weight"}: ${capacityOrWeight}`,
      (!capacityOrWeight && !isSockFamily && item.dims?.weight) && `Weight: ${item.dims.weight}`,
    ].filter(Boolean);
    const dimensionList = dimensions.length
      ? `[VERIFIED_DIMENSIONS: ${dimensions.join("; ")}]`
      : itemDimensions.length
        ? `[VERIFIED_DIMENSIONS: ${itemDimensions.join("; ")}]`
        : fallbackDimensions.dimensionList || "";
    const itemDisplayColor = displayColorName(item.displayColor || item.color, item.colorEnglish);
    const itemColor = item.colorEnglish || colorName(item.color) || color;
    const itemMaterial = translateAttributeValue("Material", item.material || "") || material;
    const itemStructure = structure;
    const itemProductName = item.productName || displayProductName(cleanProductName || productName, combined) || toCrossBorderProductName(productName, item.spec);
    const itemOutputName = isYogaSockFamily
      ? outputName
      : item.outputProductName || crossBorderProductName(cleanProductName || productName, combined) || toCrossBorderProductName(productName, item.outputSpec || item.spec);
    const variantProductName = displayVariantText(item.outputSpec || outputVariantNameFromParts(itemOutputName, item)) || itemOutputName;
    const itemShortBaseName = batchBaseName || shortCrossBorderBaseName(itemOutputName || itemProductName, combined);
    const safePack = skuRelevantPackValue(item.productUnitCount || item.pack || productUnitCount);
    const itemForDisplay = { ...item, displayColor: itemDisplayColor, productUnitCount: safePack, pack: safePack };
    const itemForOutput = { ...item, productUnitCount: safePack, pack: safePack };
    const displaySpec = displayVariantText(item.spec || productVariantName(itemProductName, itemForDisplay, itemProductName || "selected product"));
    const outputSpec = skuCurrentOptionText(
      { ...itemForOutput, outputSpec: item.outputLabel || shortCrossBorderOptionLabel(itemShortBaseName, itemForOutput, itemOutputName || "selected product") },
      itemOutputName || "selected product"
    );
    const variantList = normalizedVariants
      .map((variant) => displayVariantText(comparisonOptionLabel({ ...variant, productUnitCount: skuRelevantPackValue(variant.productUnitCount || variant.pack || productUnitCount), pack: skuRelevantPackValue(variant.productUnitCount || variant.pack || productUnitCount) }, variant.outputLabel || itemOutputName || "product option")))
      .filter(Boolean)
      .join(" | ");
    const displaySizeCode = displayVariantText(item.outputSizeCode || outputSpec || item.sizeCode || item.spec || displaySpec);
    return {
    id: item.id,
    label: variantProductName || itemOutputName || outputSpec || displayVariantText(item.outputLabel || item.label),
    displayLabel: variantProductName || itemOutputName || outputSpec || displayVariantText(item.outputLabel || item.label),
    productName: variantProductName || itemOutputName,
    baseProductName: itemOutputName,
    shape: variantProductName || outputSpec || displaySpec || item.spec,
    pack: safePack,
    sizeCode: displaySizeCode,
    groupKey: "",
    group: {
      promptName: variantProductName || outputSpec || displaySpec || displayVariantText(item.spec),
      promptSpecs: [variantProductName || outputSpec || displaySpec || displayVariantText(item.spec), itemCupRange, safePack, itemMaterial, itemStructure].filter(Boolean),
      dimensions: dimensions.length ? dimensions : itemDimensions,
    },
    dims: {
      topWidth: dimensionValueByLabels(dimensions.join("; "), ["Folded Size", "Top Width", "Length"]) || item.dims?.topWidth || fallbackDimensions.topWidth || "",
      sideLength: dimensionValueByLabels(dimensions.join("; "), ["Open Diameter", "Side Length", "Width"]) || item.dims?.sideLength || fallbackDimensions.sideLength || "",
      bottomWidth: dimensionValueByLabels(dimensions.join("; "), ["Open Height", "Bottom Width", "Height"]) || item.dims?.bottomWidth || fallbackDimensions.bottomWidth || "",
      weight: dimensionValueByLabels(dimensions.join("; "), ["Weight", "Capacity", "Volume", "Weight / Capacity"]) || capacityOrWeight || (!isSockFamily ? item.dims?.weight : "") || fallbackDimensions.weight || "",
      cupRange: itemCupRange,
      source: dimensions.length ? "Extracted from uploaded source files" : item.dims?.source || fallbackDimensions.source || "No verified dimensions extracted",
    },
    quantity: item.quantity,
    material: itemMaterial,
    color: itemColor,
    structure: itemStructure,
    scene,
    feature1: globalSellingPoint1 || sellingPoints.feature1,
    feature2: globalSellingPoint2 || sellingPoints.feature2,
    surfaceFinish: detailTechnology,
    fit: item.fit || "",
    detailParameter: compactPromptItems([umbrellaDetailText(attributeText, dimensionList), detailSpecialCraft, extraSellingPointText], "", 6),
    singleSpec: `[CURRENT_PRODUCT_OPTION: ${[variantProductName || outputSpec, safePack].filter(Boolean).join(", ")}]`,
    specList: `[SPEC_LIST: ${[variantProductName || outputSpec, itemCupRange, safePack, itemMaterial, itemStructure].filter(Boolean).join(" / ")}]`,
    variantList: variantList ? `[VARIANT_LIST: ${variantList}]` : "",
    dimensionList,
  };
  });
}

async function extractSources() {
  hasUserSourceAttempt = true;
  const purchaseFile = byId("purchaseFile").files[0];
  const purchaseImageFile = byId("purchaseImageFile").files[0];
  const amazonTemplateFile = byId("amazonTemplateFile").files[0];
  const amazonSkuFilter = byId("amazonSkuFilter")?.value || "";
  const supplierFiles = Array.from(byId("supplierFile").files || []);
  const competitorFiles = Array.from(byId("competitorFile").files || []);
  const extractButton = byId("extractSources");
  extractButton.disabled = true;
  extractButton.setAttribute("aria-busy", "true");
  byId("extractStatus").textContent = "正在解析资料...";

  try {
    const purchasePdfText = await readPdfText(purchaseFile);
    const purchaseImageOcr = await ocrLocalImageFile(purchaseImageFile, (message) => {
      byId("extractStatus").textContent = message;
    });
    const purchaseText = [
      purchasePdfText,
      purchaseImageOcr.text && `Purchase order image OCR text: ${purchaseImageOcr.text}`,
    ].filter(Boolean).join("\n");
    const amazonTemplate = await extractAmazonTemplateProducts(amazonTemplateFile, amazonSkuFilter);
    const supplierEntries = await readNamedTextFiles(supplierFiles, (message) => {
      byId("extractStatus").textContent = message;
    });
    const supplierHtml = combinedNamedHtmlEntries(supplierEntries);
    const competitorHtml = await readTextFiles(competitorFiles, (message) => {
      byId("extractStatus").textContent = message;
    });
    const supplierFileExtraction = supplierEntries.length > 1
      ? await extractSupplierSourcesByFile(supplierEntries, (message) => {
        byId("extractStatus").textContent = message;
      })
      : null;
    const supplierSource = supplierFileExtraction?.merged || await extractSupplierSourceText(supplierHtml, (message) => {
      byId("extractStatus").textContent = message;
    });
    const supplierFileProducts = supplierFileExtraction?.fileSources?.length > 1
      ? productsFromSupplierFileSources(supplierFileExtraction.fileSources)
      : [];
    const useSupplierFileProducts = supplierFileProducts.length > 1;
    const competitorSourceText = competitorHtml
      ? [
        `REFERENCE_SOURCE_FILES: ${competitorFiles.map((file) => file.name).join(", ")}`,
        cleanHtmlText(competitorHtml),
      ].filter(Boolean).join("\n")
      : "";
    sourcePayload = {
      purchase: purchaseText,
      amazonTemplate: useSupplierFileProducts ? "" : amazonTemplate.sourceText,
      supplier: supplierSource.text,
      competitor: useSupplierFileProducts ? "" : competitorSourceText,
    };
    fieldOverrides = {};
    fieldOverridesBySku = {};
    appliedSellingPointOverridesBySku = {};
    sellingPointDraftDirty = false;
    const inferredSourceProducts = inferProductsFromSources(sourcePayload.purchase, sourcePayload.supplier, sourcePayload.competitor);
    let supplierCategoryId = categoryIdFromProduct(inferredSourceProducts[0] || {});
    if (supplierCategoryId === "generic") {
      supplierCategoryId = categoryIdFromSourceText([sourcePayload.purchase, sourcePayload.supplier].filter(Boolean).join(" "));
    }
    let amazonCategoryId = categoryIdFromProduct(amazonTemplate.products[0] || {});
    if (amazonCategoryId === "generic") {
      amazonCategoryId = categoryIdFromSourceText(amazonTemplate.sourceText);
    }
    const amazonSupplierConflict = amazonTemplate.products.length
      && inferredSourceProducts.length
      && sourceCategoriesConflict(supplierCategoryId, amazonCategoryId);
    const mergedAmazonSupplierProducts = amazonTemplate.products.length && inferredSourceProducts.length
      ? mergeAmazonProductsWithSupplierFacts(amazonTemplate.products, inferredSourceProducts)
      : [];
    if (useSupplierFileProducts) {
      extractedProducts = supplierFileProducts;
    } else if (mergedAmazonSupplierProducts.length) {
      extractedProducts = mergedAmazonSupplierProducts;
    } else if (amazonTemplate.products.length) {
      extractedProducts = amazonTemplate.products;
    } else {
      extractedProducts = inferredSourceProducts;
    }
    if (!extractedProducts.length) {
      throw new Error("没有从当前资料中提取到产品 / 款式，请确认采购单、Amazon 模板或 1688 HTML 是否已选择。");
    }
    renderProductSelect(extractedProducts[0]?.id);
    renderFields(true);
    renderAll();
    const ocrStatus = supplierSource.imageCount
      ? `1688 图片 OCR：共发现 ${supplierSource.candidateCount || supplierSource.imageCount} 张图片，全局筛选后优先识别 ${supplierSource.imageCount} 张疑似产品详情/参数图，实际成功 ${supplierSource.scannedCount} 张，采纳 ${supplierSource.acceptedCount || 0} 张，其中命中卖点文本 ${supplierSource.sellingPointCount || 0} 张，跳过/失败 ${supplierSource.failedCount} 张。远程图片可能因跨域、防盗链、尺寸过小或内容过滤而跳过。`
      : "未找到可识别的 1688 图片。";
    const ocrAvailability = supplierSource.imageCount && !supplierSource.ocrAvailable
      ? "OCR 引擎未加载成功，已跳过图片文字识别。"
      : "";
    const purchaseImageStatus = purchaseImageFile
      ? `采购单图片 OCR：${purchaseImageOcr.scannedCount ? "成功识别" : "未识别到文字或识别失败"}。`
      : "";
    const purchaseImageAvailability = purchaseImageFile && !purchaseImageOcr.available
      ? "OCR 引擎未加载成功，已跳过采购单图片识别。"
      : "";
    const amazonTemplateStatus = amazonTemplateFile
      ? `Amazon 模板：${useSupplierFileProducts
        ? "多 1688 文件模式已改按文件输出产品，未使用模板款式"
        : mergedAmazonSupplierProducts.length
            ? `${amazonTemplate.products.length} 个子 SKU 款式；listing 参数优先，1688 / 采购单仅补缺${amazonSupplierConflict ? "；检测到类目不一致，请确认文件是否配套" : ""}${amazonSkuFilter ? `，筛选 ${amazonSkuFilter}` : ""}`
            : `${amazonTemplate.products.length} 个子 SKU 款式${amazonSkuFilter ? `，筛选 ${amazonSkuFilter}` : ""}`}。`
      : "";
    const htmlFileStatus = `1688 HTML：${supplierFiles.length} 个；参考链接 HTML：${competitorFiles.length} 个。`;
    const supplierFileStatus = useSupplierFileProducts
      ? `多 1688 文件：已按 ${supplierFileProducts.length} 个文件生成 ${supplierFileProducts.length} 个独立产品选项；旧参考链接内容未参与本次提示词。`
      : "";
    byId("extractStatus").textContent = `已提取 ${extractedProducts.length} 个产品 / 款式。${supplierFileStatus}${amazonTemplateStatus}PDF、采购单图片、多网页 HTML 与详情图 OCR 已尝试读取。${htmlFileStatus}${purchaseImageStatus}${ocrStatus}${purchaseImageAvailability}${ocrAvailability}`;
  } finally {
    extractButton.disabled = false;
    extractButton.removeAttribute("aria-busy");
  }
}

function negativePrompt(facts = null) {
  const profile = facts ? categoryProfile(facts) : {};
  return compactPromptItems([
    "No wrong product, invented specs, unsupported claims, extra logos, Chinese/source text, dense copy, long labels, bullets, text stacking, blur",
    facts?.bundleComponents ? "No missing bundle component, fused hybrid product, swapped component parameters, or treating bundle components as optional variants" : "",
    "No Asian reference ethnicity; people only European/American if shown",
    profile.negative,
    facts ? footwearStructureNegativeText(facts) : "",
    "Keep authentic non-Chinese product markings only",
  ], "", 7);
}

function isPlaceholderName(value) {
  const clean = String(value || "").trim();
  const knownPlaceholders = new Set([
    "PRODUCT_NAME",
    "PRODUCT_SPEC",
    "PACKAGING_COUNT",
    "PRODUCT_COUNT_OR_SET",
    "CURRENT_PRODUCT_OPTION",
    "MATERIAL",
    "COLOR",
    "STRUCTURE",
    "COMPATIBLE_USE",
    "USE_SCENE",
    "SELLING_POINT_1",
    "SELLING_POINT_2",
    "VARIANT_LIST",
    "SPEC_LIST",
    "VERIFIED_DIMENSIONS",
    "SIZE_CODE",
    "CUP_RANGE",
  ]);
  return knownPlaceholders.has(clean) || /^[A-Z0-9_ ]+$/.test(clean) && clean.includes("_");
}

function promptValue(value, fallback = "") {
  const clean = cleanTokenValue(value);
  if (!clean || isPlaceholderName(clean)) return fallback;
  return clean;
}

function packagingValue(data) {
  const candidates = [
    cleanTokenValue(data.pack),
    cleanTokenValue(data.packagingCount),
  ].filter(Boolean);
  return candidates.find((value) => /(?:pcs|pieces?|片|pack|包|pairs?|双|件|只|个|set|套)/i.test(value) && !/cups?|人份/i.test(value)) || "";
}

function cupTypeValue(value) {
  return cleanTokenValue(value)
    .split(",")
    .map((part) => part.trim())
    .filter((part) => part && !/(?:pcs|片|pack|包|cups?|人份)/i.test(part))
    .join(", ");
}

function promptFacts(sku, data) {
  const group = productGroups[sku.groupKey] || sku.group || {};
  const productName = promptValue(data.productName, sku.shape || "the product");
  const selectedSpec = promptValue(data.singleSpec, sku.shape || "selected product specification");
  const cupType = promptValue(cupTypeValue(group.promptName || sku.shape || selectedSpec), sku.shape || selectedSpec || "selected product specification");
  const pack = packagingValue(data);
  const material = promptValue(data.material, "verified product material");
  const color = promptValue(data.color, "accurate product color");
  const fit = "";
  const scene = promptValue(data.scene, "");
  const feature1 = promptValue(data.feature1, "");
  const feature2 = promptValue(data.feature2, "");
  const feature3 = promptValue(data.feature3, "");
  const variants = promptValue(data.variantList, "available verified product options");
  const dimensions = promptValue(data.dimensionList, "");
  const cupRange = promptValue(data.cupRange || sku.dims?.cupRange || extractFirstMatch(data.specList || "", [/([0-9]+\s*-\s*[0-9]+\s*(?:cups|cup|人份))/i]), "");
  const dimension1 = data.topWidth ? cleanTokenValue(data.topWidth) : "";
  const dimension2 = data.sideLength ? cleanTokenValue(data.sideLength) : "";
  const dimension3 = data.bottomWidth ? cleanTokenValue(data.bottomWidth) : "";
  const weightOrCapacity = data.weight ? cleanTokenValue(data.weight) : "";
  const structure = promptValue(data.structure, sku.structure || "");
  const surfaceFinish = promptValue(data.surfaceFinish, "");
  const detailParameter = promptValue(data.detailParameter, "");
  const bundleComponents = promptValue(data.bundleComponents || sku.bundleComponents, "");
  const titleSpec = stripRepeatedValue(selectedSpec, pack) || productName || selectedSpec;
  const skuOptionSource = sku.sizeCode && !promptItemsOverlap(productName, sku.sizeCode)
    ? sku.sizeCode
    : titleSpec || selectedSpec || sku.sizeCode;
  const skuOption = compactSkuOptionText(skuOptionSource, {
    productName,
    pack,
    material,
    structure,
    fit,
    cupRange,
  });
  const specs = [
    selectedSpec,
    pack,
    material,
    structure,
    fit,
    dimensions,
  ].filter(Boolean).join(" / ");

  return {
    productName,
    titleSpec,
    skuOption,
    cupType,
    selectedSpec,
    pack,
    material,
    color,
    fit,
    scene,
    feature1,
    feature2,
    feature3,
    bundleComponents,
    variants,
    specs,
    dimensions,
    dimension1,
    dimension2,
    dimension3,
    weightOrCapacity,
    structure,
    surfaceFinish,
    detailParameter,
    cupRange,
  };
}

function stripRepeatedValue(value, repeatedValue) {
  const clean = String(value || "").trim();
  const repeated = String(repeatedValue || "").trim();
  if (!clean || !repeated) return clean;
  return clean
    .replace(new RegExp(repeated.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi"), "")
    .replace(/\s*,\s*,/g, ",")
    .replace(/^[\s,/-]+|[\s,/-]+$/g, "")
    .trim();
}

function stripPromptFragments(value, fragments = []) {
  return fragments.reduce((current, fragment) => {
    const cleanFragment = cleanTokenValue(fragment);
    return cleanFragment ? stripRepeatedValue(current, cleanFragment) : current;
  }, cleanTokenValue(value))
    .replace(/\s*,\s*,/g, ",")
    .replace(/\s*\/\s*\/\s*/g, " / ")
    .replace(/^[\s,/-]+|[\s,/-]+$/g, "")
    .trim();
}

function compactSkuOptionText(value, context = {}) {
  const clean = stripPromptFragments(value, [
    context.productName,
    context.pack,
    context.material,
    context.structure,
    context.fit,
    context.cupRange,
  ]);
  if (!clean) return "";

  const parts = clean
    .split(/\s*(?:\/|\||;|\s+-\s+)\s*/)
    .map((part) => part.replace(/^[\s,/-]+|[\s,/-]+$/g, "").trim())
    .filter(Boolean);
  return uniquePromptItems(parts.length ? parts : [clean]).slice(0, 3).join(" / ");
}

function compactProductName(value) {
  return cleanTokenValue(value)
    .replace(/\s*,\s*/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function compactDisplayTitle(facts, options = {}) {
  const includePack = options.includePack !== false;
  const productName = compactProductName(facts.productName) || "Product";
  const option = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  const details = uniquePromptItems([
    option,
    includePack ? facts.pack : "",
  ], [productName]).slice(0, includePack ? 2 : 1).join(" / ");
  return displayVariantText([productName, details].filter(Boolean).join(" - ")) || productName;
}

function skuDisplayLabel(sku, data = null) {
  if (sku.displayLabel) return sku.displayLabel;
  const facts = promptFacts(sku, data || valueMap(sku));
  return compactDisplayTitle(facts, { includePack: true }) || sku.label || sku.id;
}

function promptContextText(facts) {
  return [
    facts.productName,
    facts.titleSpec,
    facts.selectedSpec,
    facts.cupType,
    facts.material,
    facts.structure,
    facts.scene,
    facts.feature1,
    facts.feature2,
    facts.feature3,
    facts.variants,
    facts.detailParameter,
  ].filter(Boolean).join(" ").toLowerCase();
}

function promptIdentityText(facts) {
  return [
    facts.productName,
    facts.titleSpec,
    facts.selectedSpec,
    facts.cupType,
    facts.material,
    facts.structure,
    facts.variants,
    facts.detailParameter,
    facts.bundleComponents,
  ].filter(Boolean).join(" ").toLowerCase();
}

function categoryProfile(facts) {
  const identity = promptIdentityText(facts);
  const isResistanceBand = /resistance\s+band|exercise\s+band|workout\s+band|拉力带|拉力片|弹力带|阻力带/.test(identity);
  const isFlowerWrappingPaper = isFlowerWrappingPaperText(identity);
  const isSock = !isResistanceBand && /sock|socks|toe socks|grip socks|瑜伽袜|普拉提袜|五指袜|五趾袜|分趾袜|船袜|短袜|隐形袜|浅口袜|袜子|袜/.test(identity);
  const isFootwear = !isSock && !isFlowerWrappingPaper && /slipper|slippers|flip\s*flops?|flip-flops?|sandal|sandals|footwear|shoe|shoes|clog|slides?|拖鞋|凉拖|一字拖|人字拖|沙滩鞋|鞋/.test(identity);
  const isUmbrella = /umbrella|parasol|rain\s*umbrella|sun\s*umbrella|folding\s*umbrella|伞|雨伞|遮阳伞|晴雨伞/.test(identity);
  const isCoffeeFilter = /coffee\s+filters?|filter\s+paper|pour[-\s]?over\s+filter|drip\s+coffee\s+filter|滤纸|咖啡滤纸|木浆纸|原木浆|dripper|pour-over|pour over/.test(identity);
  const isCoffeeMetalAccessory = /portafilter|filter\s+basket|espresso\s+basket|dosing\s+funnel|espresso|咖啡粉碗|接粉环|粉碗/.test(identity);
  const isKitchenware = /kitchenware|kitchen\s+tool|cup|mug|bottle|jar|container|厨房用品|杯子|马克杯|水杯|瓶|罐|收纳盒|保鲜盒/.test(identity);
  const profiles = [
    {
      id: "resistance-band",
      match: isResistanceBand,
      apparel: false,
      background: "Category background: clean fitness, physical therapy, stretching, strength training, or home workout setting with realistic training props.",
      scene: "Scene category: clean fitness, physical therapy, stretching, strength training, and home workout scenes.",
      identity: "Resistance band identity lock: preserve flat band sheet shape, selected color, TPE material feel, thickness, width, and length; do not turn into loop bands, tube bands, handles, ropes, fabric bands, socks, straps, or apparel.",
      negative: "No socks, shoes, clothing, loop bands, tube bands, handles, ropes, fabric straps, wrong color, wrong thickness, invented texture, or extra logo.",
      proof: {
        "break-resistant": "show controlled stretch tension without tearing, with visible band continuity and safe distance",
        "deformation-resistant": "show even stretch and flat band recovery without warping",
        "stretch-range": "show extended stretch length with simple ruler/arrow guide",
        "full-body": "show multiple workout poses or body-area icons while band stays accurate",
        durable: "show close-up of intact edge and material under tension",
        elastic: "show smooth elastic stretch in a workout scene",
      },
      inset: {
        "break-resistant": "tension stretch close-up with intact edge",
        "deformation-resistant": "even flat stretch close-up",
        "stretch-range": "extended length arrow guide",
        "full-body": "full-body exercise pose icons",
        durable: "TPE edge/material close-up",
        elastic: "elastic stretch close-up",
      },
    },
    {
      id: "flower-wrapping-paper",
      match: isFlowerWrappingPaper,
      apparel: false,
      background: "Category background: elegant florist studio, bouquet wrapping table, gift packaging station, flower market counter, or wedding/event floral prep scene with soft natural light.",
      scene: "Scene category: florist studio, bouquet wrapping, gift packaging, flower market, and event floral arrangement scenes; the wrapping paper remains the product hero.",
      identity: "Flower wrapping paper identity lock: preserve sheet/roll/folded paper form, color, translucency or texture, thickness, printed pattern if verified, and packaging count; do not turn it into flowers, bags, shoes, fabric, ribbons, or finished bouquets only.",
      negative: "No footwear, slippers, flip-flops, shoes, socks, beach/spa/shower footwear scene, unrelated bags, fabric cloth, wallpaper, gift boxes replacing the product, or flowers hiding the wrapping paper.",
      multiScene: (sceneList) => [
        `Flower wrapping paper scene choices for ${sceneList}: florist wrapping bouquet, gift packaging table, flower market display, wedding/event floral prep, craft storage, or paper color/texture selection.`,
        "Show the wrapping paper clearly as sheets, rolls, folded stacks, or being wrapped around flowers; flowers and ribbons are supporting props only.",
        "Paper benefits should be implied through handling, wrapping, layering, color matching, texture visibility, and clean finished bouquet presentation.",
      ],
      proof: {
        durable: "show paper being folded or wrapped cleanly around a bouquet without tearing",
        "multi-use": "show bouquet wrapping, gift packaging, craft decor, and floral arrangement use contexts",
        material: "show paper texture, translucency, thickness, or matte/gloss finish in a florist setup",
        soft: "show soft flexible sheet handling around delicate flowers",
        compact: "show neat roll, folded stack, or easy storage on a packaging shelf",
      },
      inset: {
        durable: "folded edge and wrapped bouquet close-up",
        "multi-use": "bouquet, gift, and craft use mini scenes",
        material: "paper texture and translucency close-up",
        soft: "flexible sheet handling close-up",
        compact: "roll or folded stack storage close-up",
      },
    },
    {
      id: "coffee-filter",
      match: isCoffeeFilter,
      apparel: false,
      background: "Category background: bright coffee brewing counter or light studio setup with dripper/cup hints; do not copy competitor product scenes.",
      scene: "Scene category: bright coffee brewing counter or light studio setup with dripper/cup hints.",
      negative: "Do not turn the product into coffee beans, cups, mugs, drippers, machines, metal baskets, cloth filters, or unrelated kitchen paper.",
    },
    {
      id: "coffee-metal-accessory",
      match: isCoffeeMetalAccessory,
      apparel: false,
      background: "Category background: clean marble coffee bar with espresso-machine and cup props; do not copy competitor product scenes.",
      scene: "Scene category: clean marble coffee bar with espresso-machine and cup props.",
      negative: "Do not turn the product into paper filters, coffee beans, mugs, full espresso machines, or unrelated kitchen tools.",
    },
    {
      id: "kitchen",
      match: isKitchenware,
      apparel: false,
      background: "Category background: bright kitchen or studio countertop, subtle matching props, realistic light.",
      scene: "Scene category: bright kitchen or studio countertop with subtle matching props.",
      negative: "Do not replace the product with unrelated kitchenware, food, appliances, bottles, jars, mugs, or generic containers.",
    },
    {
      id: "footwear",
      match: isFootwear,
      apparel: true,
      background: "Category background: neutral product-first footwear setting only when no source scene is verified.",
      scene: "",
      identity: "Footwear structure lock: preserve the exact source slipper/slide/sandal construction; keep upper band or strap layout/count/width, open or closed toe area as shown, sole outline/thickness, edge profile, fold/hinge if present, material texture, and selected color.",
      negative: "No changed footwear construction, strap/band layout/count/width, open/closed toe area, sole outline/thickness, fold/hinge, invented heel/back/ankle strap, second parallel strap, two-band upper, decoration, wrong material texture/color, or extra logo.",
      multiScene: (sceneList) => [
        `Footwear scene choices must come only from verified extracted scene text: ${sceneList}.`,
        "Show the exact slippers/slides/sandals while keeping realistic foot scale and true color.",
        "Do not add footwear benefits, actions, or environments unless they are present in current source fields.",
      ],
      proof: {
        compact: "show only source-verified compact or foldable structure without changing the shoe shape",
        lightweight: "show only source-verified lightweight handling with realistic scale",
        grip: "show only source-verified sole texture or anti-slip detail",
        rain: "show only source-verified water or quick-dry detail",
        material: "show source-verified footwear material texture in a clean close-up",
      },
      inset: {
        grip: "source-verified sole texture close-up",
        compact: "source-verified compact or fold detail close-up",
        lightweight: "source-verified lightweight detail with realistic scale",
        rain: "source-verified water or quick-dry detail close-up",
        material: "source-verified footwear material texture close-up",
        "cross-strap": "upper strap or backstrap structure close-up",
      },
    },
    {
      id: "yoga-socks",
      match: isSock,
      apparel: true,
      background: "Category background: premium yoga/pilates lifestyle setting, bright studio floor or calm home workout space.",
      scene: "Scene category: premium yoga or pilates lifestyle setting with soft natural light.",
      identity: "Sock identity lock: keep the exact sock type, toe/strap/opening structure, fabric texture, grip placement, and selected color; show worn fit only when it helps prove the product.",
      negative: "No bare feet without socks, slippers, shoes, sandals, stockings, leggings, gloves, wrong toe structure, missing grip pattern, wrong color, invented decoration, or extra brand logo.",
      proof: {
        grip: "show real anti-slip grip under floor/mat/surface pressure",
        "cross-strap": "show worn/angled view that reveals the structure",
        "five-toe": "show worn/angled view that reveals the structure",
        elastic: "show snug stretch in use without distortion",
        cotton: "show relaxed comfort with fabric texture visible",
        soft: "show relaxed comfort with fabric texture visible",
      },
      inset: {
        grip: "anti-slip sole close-up",
        "cross-strap": "structure/detail close-up",
        "five-toe": "structure/detail close-up",
        cotton: "fabric comfort close-up",
        soft: "fabric comfort close-up",
        elastic: "fabric comfort close-up",
      },
    },
    {
      id: "umbrella",
      match: isUmbrella,
      apparel: false,
      scene: "Scene category: realistic daily commute, travel, rainy sidewalk, and sunny outdoor shade environments with natural scale cues.",
      negative: "Do not replace the product with parasols of a different structure, tents, raincoats, bags, canopies, unrelated outdoor gear, wrong handle, wrong canopy shape, or invented logos.",
      proof: {
        compact: "show folded umbrella beside a hand, pocket, or small bag with a clear size comparison",
        lightweight: "show easy one-hand carry or bag storage without exaggerating scale",
        uv: "show sun-shade use with canopy coverage and no unsupported numeric UV claims",
        rain: "show raindrops beading on the canopy in a realistic rainy scene",
        windproof: "show reinforced ribs or stable canopy structure in a mild wind context",
      },
      inset: {
        compact: "folded umbrella beside hand, phone, pocket, or small bag",
        lightweight: "one-hand carry or handbag storage proof",
        uv: "sun-shade canopy coverage proof",
        rain: "water-beading canopy close-up",
        windproof: "reinforced rib frame close-up",
      },
    },
  ];
  return profiles.find((profile) => profile.match) || {
    id: "generic",
    apparel: false,
    background: "Category background: realistic light category-matched surface and props, uncluttered Amazon listing style.",
    scene: "Scene category: realistic light category-matched surface, props, and color mood.",
    negative: "Do not replace the product with a nearby prop, background object, model accessory, or generic category guess.",
  };
}

function isApparelCategory(facts) {
  return categoryProfile(facts).apparel
    || /apparel|clothing|garment|wear|activewear|sportswear|fashion|legging|shirt|dress|pants|shorts|bra|glove|hat|cap|服装|衣|裤|裙|帽/.test(promptIdentityText(facts));
}

function isFootwearCategory(facts) {
  return categoryProfile(facts).id === "footwear";
}

function isThongFlipFlopFacts(facts) {
  return isThongFlipFlopText(promptIdentityText(facts));
}

function mainImageRule() {
  return "Main image: no overlay text; preserve authentic non-Chinese product/packaging markings only; product occupies about 85% of the frame.";
}

function sceneMainProductScaleRule() {
  return "Scene main image scale: the selected product itself must occupy at least 30% of the image area; crop close enough that the product is easy to inspect; scene, props, model, hands, and environment stay secondary.";
}

function multiSceneProductScaleRule() {
  return "Multi-scene scale: in every equal-size panel, the selected product should usually occupy about 12-15% of that panel and never feel tiny; product color, silhouette, and key decoration/structure must stay readable while leaving room for natural action and environment.";
}

function multiSceneEqualPanelRule() {
  return "Multi-scene layout: exactly four equal-size panels in a clean 2x2 grid; no oversized hero panel, no side strip, no stacked sidebar, no masonry collage, and no mixed large-small panel layout.";
}

function scenePhraseInterpretationRule() {
  return "Scene phrases are context labels, not literal actions: use only the scenes provided on the left, reinterpret each phrase as a physically plausible environment for the current product, and do not add example scenes or unrelated lifestyle contexts.";
}

function footwearUsePlausibilityRule() {
  return "Footwear use must be physically plausible: shoes/slippers stay worn on feet or placed on a stable walking surface; no floating footwear, no feet raised in midair as the main action, no stepping on fruit/food/merchandise/tables/crates/chairs, and no using coffee cups, baskets, produce, or props as support surfaces.";
}

function footwearMultiSceneUseRule() {
  return "Footwear multi-scene rule: every panel shows the exact shoes/slippers worn on feet or naturally on stable ground in the user-provided scene; no product-only top-down shots, no flat lays, no basket/bag/storage display, no isolated close-ups, no macro detail panels, and no product placement as decor.";
}

function isMainImageType(typeId) {
  return typeId === "1" || typeId === "1A" || typeId === "1B";
}

function shortTextRule() {
  return "English labels only: selling-point image titles must match the left selling-point count, 1 title group for 1 selling point or 2 title groups for 2 selling points; each group may use soft Title + Explanation text, and each part is max 5 characters; no full sentence captions or explanatory phrases on selling-point images; parameter labels stay 2-4 words max; summary feature labels stay 1-3 words max; no paragraphs, badges, repeated claims, or text stacking.";
}

function humanSceneRule(facts) {
  return isApparelCategory(facts)
    ? "People optional; use European/American model only when it proves fit/use."
    : "People optional; product remains the focus.";
}

function sharedVisualRules(facts, typeId = "") {
  return [
    "4K clarity and sharp realistic detail.",
    isMainImageType(typeId) ? mainImageRule() : shortTextRule(),
    humanSceneRule(facts),
  ].filter(Boolean).join(" ");
}

function neutralProductSceneFallback() {
  return "neutral product-first setting with clean light, realistic scale, simple surface or placement, and no category-specific props or scene unless present in source fields";
}

function neutralProductSceneListFallback() {
  return "";
}

function hasVerifiedUseContext(facts) {
  return Boolean(cleanFieldDisplayValue(facts?.scene || ""));
}

function recommendedUseSceneItems(facts, limit = 4) {
  if (hasVerifiedUseContext(facts)) return [];
  const productFacts = compactSpecificPromptItems([
    facts?.productName && `product name: ${facts.productName}`,
    facts?.selectedSpec && `current option: ${facts.selectedSpec}`,
    facts?.material && `material: ${facts.material}`,
    facts?.structure && `structure: ${facts.structure}`,
    facts?.feature1 && `selling point: ${facts.feature1}`,
    facts?.feature2 && `selling point: ${facts.feature2}`,
  ], "current product facts", 6);
  const sceneCount = Math.max(3, Math.min(limit, 5));
  return [
    `Scene selection task: because Use Scene is empty, choose ${sceneCount} distinct best-fit use scenes from current product facts only (${productFacts}); make them specific, commercially plausible, and visually different.`,
    "Do not use a hard-coded category scene list, competitor scenes, or scenes from another product; avoid any scene that would change the product identity, structure, material, scale, or verified use.",
  ];
}

function recommendedUseSceneText(facts, fallback = neutralProductSceneFallback(), limit = 4) {
  const scenes = recommendedUseSceneItems(facts, limit);
  return scenes.length ? scenes.join(" / ") : fallback;
}

function useSceneText(facts, fallback = neutralProductSceneFallback(), limit = 4) {
  const sceneText = cleanFieldDisplayValue(facts?.scene || "");
  return sceneText || recommendedUseSceneText(facts, fallback, limit);
}

function verifiedProductDetailFallback() {
  return "visible product structure, material texture, true color, scale, and verified parameters";
}

function categoryStyleRule(facts) {
  const sceneText = cleanFieldDisplayValue(facts?.scene || "");
  return sceneText
    ? `Verified source scene/background: ${sceneText}.`
    : `Current-product scene/background selection: ${recommendedUseSceneText(facts)}.`;
}

function basicImageRequirements(templateId, typeId, extra = "") {
  const parts = ["1:1 Amazon listing image", "4K clarity", "sharp realistic detail"];
  if (isMainImageType(typeId)) {
    parts.push("no added overlay text", "preserve authentic non-Chinese product/packaging markings only");
    if (templateId === "feature") {
      parts.push("pure white background", "product occupies about 85% of the frame");
    } else {
      parts.push(sceneMainProductScaleRule());
      parts.push(`neutral product-first background: ${neutralProductSceneFallback()}`);
    }
  } else {
    parts.push("verified overlay text only when useful");
  }
  if (extra) parts.push(extra);
  return compactPromptItems(parts, "", 8);
}

function noChineseTextRule() {
  return "No Chinese text; keep authentic non-Chinese product markings only.";
}

function visualProofFirstRule() {
  return "Visual proof first: use action, close-ups, icons, arrows, or measurements; text is only a short locator.";
}

function imageMeasurementUnitRule() {
  return "On-image length labels use inches (in); convert source cm/mm.";
}

function amazonImageFileSizeRule() {
  return "Final image file <= 5 MB.";
}

function formatInches(value) {
  const rounded = Math.round(value * 100) / 100;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2).replace(/0+$/g, "").replace(/\.$/, "");
}

function convertLengthNumberToInches(numberText, unit) {
  const value = Number.parseFloat(numberText);
  if (!Number.isFinite(value)) return `${numberText} ${unit}`;
  const normalizedUnit = String(unit || "").toLowerCase();
  const inches = normalizedUnit === "mm" ? value / 25.4 : normalizedUnit === "cm" ? value / 2.54 : value;
  return `${formatInches(inches)} in`;
}

function convertLengthUnitsToInches(value) {
  return String(value || "")
    .replace(/([0-9]+(?:\.[0-9]+)?)\s*(cm|mm)\b/gi, (_, numberText, unit) => convertLengthNumberToInches(numberText, unit))
    .replace(/([0-9]+(?:\.[0-9]+)?)\s*(?:厘米|公分)/gi, (_, numberText) => convertLengthNumberToInches(numberText, "cm"))
    .replace(/([0-9]+(?:\.[0-9]+)?)\s*毫米/gi, (_, numberText) => convertLengthNumberToInches(numberText, "mm"));
}

function dimensionText(facts) {
  return compactSpecificPromptItems([
    facts.dimension1 && `${dimensionLabelForFacts(facts, 1)}: ${convertLengthUnitsToInches(facts.dimension1)}`,
    facts.dimension2 && `${dimensionLabelForFacts(facts, 2)}: ${convertLengthUnitsToInches(facts.dimension2)}`,
    facts.dimension3 && `${dimensionLabelForFacts(facts, 3)}: ${convertLengthUnitsToInches(facts.dimension3)}`,
    facts.weightOrCapacity && `Weight / Capacity: ${facts.weightOrCapacity}`,
  ], "", 4);
}

function dimensionLabelForFacts(facts, index) {
  const context = promptContextText(facts);
  if (/umbrella|伞|canopy|folded|open diameter|open height|rain|sun shade/.test(context)) {
    return ["", "Folded Size", "Open Diameter", "Open Height"][index] || `Dimension ${index}`;
  }
  return `Dimension ${index}`;
}

function productDetailText(facts, extraItems = [], limit = 8) {
  const option = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  const structureIncludesTechnology = facts.structure && facts.surfaceFinish
    && comparablePromptItem(facts.structure).includes(comparablePromptItem(facts.surfaceFinish));
  const extraText = comparablePromptItem(extraItems.join(" "));
  const extraIncludesMaterial = facts.material && promptItemsOverlap(extraText, facts.material);
  const extraIncludesStructure = facts.structure && promptItemsOverlap(extraText, facts.structure);
  const extraIncludesColor = facts.color && promptItemsOverlap(extraText, facts.color);
  const extraIncludesSurfaceFinish = facts.surfaceFinish && promptItemsOverlap(extraText, facts.surfaceFinish);
  const detailValue = visibleDetailParameter(facts.detailParameter);
  const extraIncludesDetail = detailValue && promptItemsOverlap(extraText, detailValue);
  const extraIncludesPack = facts.pack && promptItemsOverlap(extraText, facts.pack);
  const color = specificPromptValue(facts.color, "");
  return compactSpecificPromptItems([
    `Product: ${facts.productName}`,
    option && `Current option: ${option}`,
    facts.bundleComponents && `Included components: ${facts.bundleComponents}`,
    color && !extraIncludesColor && `Color: ${color}`,
    referenceColorLockText(),
    ...extraItems,
    specificPromptValue(facts.material, "") && !extraIncludesMaterial && `Material: ${facts.material}`,
    facts.cupRange && `Size / range: ${facts.cupRange}`,
    facts.pack && !extraIncludesPack && `Count / set: ${facts.pack}`,
    specificPromptValue(facts.structure, "") && !extraIncludesStructure && `Structure: ${facts.structure}`,
    specificPromptValue(facts.surfaceFinish, "") && !structureIncludesTechnology && !extraIncludesSurfaceFinish && `Technology: ${facts.surfaceFinish}`,
    detailValue && !extraIncludesDetail && `Texture detail: ${detailValue}`,
  ], "", limit);
}

function referenceColorLockText() {
  return "Match source color exactly; no hue/brightness shift.";
}

function productIdentityLockText(facts) {
  return compactPromptItems([
    "Identity lock: exact source product; no substitute, redesign, or invented detail.",
    facts.bundleComponents && "Bundle identity lock: show every included component as separate physical items in one set; no fused hybrid product, no missing component, no component substitution.",
    facts.bundleComponents && `Included bundle components: ${facts.bundleComponents}`,
    categoryProfile(facts).identity,
    facts.productName && `Exact product type/name: ${facts.productName}`,
    facts.selectedSpec && `Exact option/spec: ${shortOptionText(facts) || facts.selectedSpec}`,
    facts.color && `Exact color: ${facts.color}`,
    facts.material && `Exact material: ${facts.material}`,
    facts.structure && `Exact visible structure: ${facts.structure}`,
    facts.pack && `Pack count if shown: ${facts.pack}`,
    "Keep authentic markings.",
  ], "", 8);
}

function productIdentityBasicRule(facts) {
  if (!facts) return "";
  const option = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  return compactPromptItems([
    "Product identity lock comes first: exact selected current product only; no category substitution, no redesign, no invented parts.",
    facts.bundleComponents && "Bundle rule: this is one bundled listing; show all included components together as separate items, not alternative options.",
    facts.bundleComponents && `Included components: ${facts.bundleComponents}`,
    facts.productName && `Product: ${facts.productName}`,
    option && `Option: ${option}`,
    facts.color && `Color: ${facts.color}`,
    facts.material && `Material: ${facts.material}`,
    facts.structure && `Structure: ${facts.structure}`,
    categoryProfile(facts).identity,
  ], "", 7);
}

function sceneProductDetailText(facts, extraItems = [], limit = 8) {
  return productDetailText(facts, [
    categoryProfile(facts).identity,
    ...extraItems,
  ], limit);
}

function sceneContextProductDetailText(facts, extraItems = [], limit = 5) {
  const option = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  return compactSpecificPromptItems([
    `Product: ${facts.productName}`,
    option && `Current option: ${option}`,
    referenceColorLockText(),
    "Product accuracy: product must stay recognizable and match the source product, but the complete use environment is the main visual priority.",
    ...extraItems,
  ], "", limit);
}

function overallStyleText(facts, typeId, extra = "", options = {}) {
  return compactPromptItems([
    categoryStyleRule(facts),
    extra,
  ], "", 3);
}

function buildPromptSections({ facts, templateId, typeId, basic = "", details = "", style = "", negative = "", includeNegative = true }) {
  const priorityText = compactPromptItems([
    productIdentityBasicRule(facts),
    basic || basicImageRequirements(templateId, typeId),
  ], "", 8);
  const visualText = promptVisualSubsections(
    details || productDetailText(facts),
    style || overallStyleText(facts, typeId)
  );
  const textRules = compactPromptItems([
    noChineseTextRule(),
    isMainImageType(typeId) ? "" : shortTextRule(),
    isMainImageType(typeId) ? "" : visualProofFirstRule(),
    humanSceneRule(facts),
    imageMeasurementUnitRule(),
    amazonImageFileSizeRule(),
    referenceRuleText(),
  ], "", 6);
  const sections = [
    promptSection("PRIORITY", priorityText),
    promptSection("VISUAL", visualText),
    promptSection("TEXT", textRules),
  ];
  if (includeNegative) {
    sections.push(promptSection("AVOID", negative || negativePrompt(facts)));
  }
  return sections.join("\n\n");
}

function promptSection(label, value) {
  const clean = normalizePromptLines(value);
  const lines = clean.split("\n").filter(Boolean);
  const formatted = lines.length > 1
    ? lines.map((line) => ensurePromptPeriod(line)).join("\n")
    : ensurePromptPeriod(clean);
  return `${label}:\n${formatted}`;
}

function promptVisualSubsections(details, style) {
  const productFacts = normalizePromptLines(details).replace(/\n+/g, " / ");
  const styleGroups = sceneCompositionGroups(style);
  return [
    productFacts && `PRODUCT FACTS: ${productFacts}`,
    "SCENE & COMPOSITION:",
    ...styleGroups.map(([label, value]) => value ? `${label}: ${value}` : ""),
  ].filter(Boolean).join("\n");
}

function sceneCompositionGroups(style) {
  const clauses = splitPromptClauses(style);
  const groups = {
    scene: [],
    composition: [],
    text: [],
    guardrails: [],
    other: [],
  };
  clauses.forEach((clause) => {
    const lower = clause.toLowerCase();
    if (/\b(?:no|do not|don't|never|avoid|must not|unless verified|unsupported|unverified|wrong|invented|preserve|authentic|source-accurate|exact|lock|stay accurate|remains clear|distinct from)\b/.test(lower)) {
      groups.guardrails.push(clause);
    } else if (/\b(?:text|label|labels|title|headline|caption|callout|typography|wordart|sticker|badge|slogan|claim block)\b/.test(lower)) {
      groups.text.push(clause);
    } else if (/\b(?:composition|layout|grid|panel|poster|inset|close-up|macro|angle|centered|dominant|occupies|frame|hierarchy|padding|line break|ruler|arrow|measured|main subject)\b/.test(lower)) {
      groups.composition.push(clause);
    } else if (/\b(?:scene|background|lifestyle|hero|use|environment|product-theme|category|premium|studio|human|model|props|action|proof|demo|show)\b/.test(lower)) {
      groups.scene.push(clause);
    } else {
      groups.other.push(clause);
    }
  });
  return [
    ["SCENE DIRECTION", compactPromptItems(groups.scene, "", 4)],
    ["COMPOSITION / LAYOUT", compactPromptItems(groups.composition, "", 5)],
    ["TEXT / CALLOUTS", compactPromptItems(groups.text, "", 4)],
    ["ACCURACY GUARDRAILS", compactPromptItems(groups.guardrails, "", 4)],
    ["OTHER STYLE", compactPromptItems(groups.other, "", 3)],
  ];
}

function splitPromptClauses(value) {
  return String(value || "")
    .split(/\s+\/\s+|[.!?]\s+/)
    .map((item) => item
      .replace(/\s+/g, " ")
      .replace(/[.。]+$/g, "")
      .trim())
    .filter(Boolean);
}

function normalizePromptLines(value) {
  return String(value || "")
    .split(/\n+/)
    .map((line) => line
      .replace(/\s+/g, " ")
      .replace(/[.。]+$/g, "")
      .trim())
    .filter(Boolean)
    .join("\n");
}

function ensurePromptPeriod(value) {
  const clean = String(value || "")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return "";
  if (/:$/.test(clean)) return clean;
  return /[.!?。]$/.test(clean) ? clean : `${clean}.`;
}

function promptCardKey(sku, template, type) {
  return [sku?.id || "sku", template?.id || "template", type?.id || "type"].join("::");
}

function promptTextForLanguage(englishPrompt, language) {
  return language === "zh" ? translatePromptToChinese(englishPrompt) : englishPrompt;
}

function translatePromptToChinese(prompt) {
  return translatePromptSegment(prompt);
}

function translatePromptSegment(segment) {
  const replacements = [
    [/^PRIORITY:$/gm, "优先级:"],
    [/^VISUAL:$/gm, "视觉画面:"],
    [/^TEXT:$/gm, "文字规则:"],
    [/^AVOID:$/gm, "避免事项:"],
    [/^PRODUCT FACTS:/gm, "产品事实:"],
    [/^SCENE & COMPOSITION:/gm, "场景构图:"],
    [/^SCENE DIRECTION:/gm, "场景方向:"],
    [/^COMPOSITION \/ LAYOUT:/gm, "构图布局:"],
    [/^TEXT \/ CALLOUTS:/gm, "文字标注:"],
    [/^ACCURACY GUARDRAILS:/gm, "准确性约束:"],
    [/^OTHER STYLE:/gm, "其他风格:"],
    [/"Size Reference"/g, "“尺寸参考”"],
    [/"Product Details"/g, "“产品详情”"],
    [/"Product Information"/g, "“产品信息”"],
    [/"Choose Your Color"/g, "“选择颜色”"],
    [/"Choose Your Style"/g, "“选择款式”"],
    [/"What You Get"/g, "“套装内容”"],
    [/"Complete Set"/g, "“完整套装”"],
    [/\bSize Reference\b/g, "尺寸参考"],
    [/\bProduct Details\b/g, "产品详情"],
    [/\bProduct Information\b/g, "产品信息"],
    [/\bChoose Your Color\b/g, "选择颜色"],
    [/\bChoose Your Style\b/g, "选择款式"],
    [/\bWhat You Get\b/g, "套装内容"],
    [/\bComplete Set\b/g, "完整套装"],
    [/\bProduct-first proof scene\b/g, "产品优先的证明场景"],
    [/\bPremium product-theme hero scene\b/g, "高级产品主题主视觉场景"],
    [/\bRealistic lifestyle use scene\b/g, "真实生活方式使用场景"],
    [/\bPure white Amazon main image\b/g, "亚马逊纯白底主图"],
    [/\bSize-reference parameter infographic\b/g, "尺寸参考参数信息图"],
    [/\bPremium option showcase\b/g, "高级选项展示"],
    [/\bBundle included-components showcase\b/g, "套装内含组件展示"],
    [/\bMatch source color exactly\b/gi, "严格匹配来源颜色"],
    [/\bno hue\/brightness shift\b/gi, "不要色相/亮度偏移"],
    [/\bproduct hero\b/gi, "产品主体"],
    [/\bany human presence stays secondary\b/gi, "人物存在也保持次要"],
    [/\btemplate Image\b/gi, "模板图"],
    [/\bScene template Image\b/gi, "场景模板图"],
    [/\bSpec template Image\b/gi, "规格模板图"],
    [/\bFeature template Image\b/gi, "功能模板图"],
    [/\bReference template Image\b/gi, "参考模板图"],
    [/\bKeep authentic non-Chinese product markings only\b/gi, "只保留真实的非中文产品标识"],
    [/\bKeep authentic non-Chinese product\/packaging markings only\b/gi, "只保留真实的非中文产品/包装标识"],
    [/\bKeep authentic product markings\b/gi, "保留真实产品标识"],
    [/\bNo Asian reference ethnicity\b/gi, "不要亚洲参考人种特征"],
    [/\bpeople only European\/American if shown\b/gi, "如展示人物，仅使用欧美人物"],
    [/\bReference blueprint slot\b/g, "参考蓝图图位"],
    [/\bReference-derived composition\b/g, "参考提取构图"],
    [/\bReference-derived proof method\b/g, "参考提取证明方式"],
    [/\bReference text density\b/g, "参考文字密度"],
    [/\bReference layout cues\b/g, "参考布局线索"],
    [/\bReference proof-slot cues\b/g, "参考证明图位线索"],
    [/\bExecute this exact reference slot with the current product\b/g, "用当前产品执行这个准确的参考图位"],
    [/\bExecute slot composition exactly\b/g, "严格执行该图位构图"],
    [/\bCurrent product identity is the top priority\b/g, "当前产品身份是最高优先级"],
    [/\bCurrent product fields always override the reference product\b/g, "当前产品字段始终优先于参考产品"],
    [/\bProduct stays prominent and source-accurate\b/g, "产品保持突出且来源准确"],
    [/\bProduct geometry stays unchanged\b/g, "产品几何形态保持不变"],
    [/\bProduct must be in active use\b/g, "产品必须处于实际使用状态"],
    [/\bnot just placed as a prop\b/g, "不要只是当作道具摆放"],
    [/\bcomposition should feel aspirational, high-end, and category-matched\b/g, "构图应有高级向往感，并匹配品类"],
    [/\bshow only the product itself\b/g, "只展示产品本身"],
    [/\bproduct itself\b/g, "产品本身"],
    [/\bno hands\b/g, "不要手"],
    [/\bno people\b/g, "不要人物"],
    [/\bno body parts\b/g, "不要身体部位"],
    [/\bno props\b/g, "不要道具"],
    [/\bno furniture\b/g, "不要家具"],
    [/\bno room\b/g, "不要室内房间"],
    [/\bno outdoor scene\b/g, "不要户外场景"],
    [/\bno lifestyle background\b/g, "不要生活方式背景"],
    [/\bno added title\b/g, "不要添加标题"],
    [/\bno added labels\b/g, "不要添加标签"],
    [/\bno added overlay text\b/g, "不要添加覆盖文字"],
    [/\bUse the reference slot layout\b/g, "使用参考图位布局"],
    [/\blabels\/arrows\/insets must explain only verified current-product facts\b/g, "标签/箭头/小窗只能解释已验证的当前产品事实"],
    [/\bMacro close-ups or insets must come from the current product\b/g, "微距特写或小窗必须来自当前产品"],
    [/\bIf a referenced detail is not verified for the current product\b/g, "如果某个参考细节未被当前产品验证"],
    [/\breplace it with a verified current-product detail\b/g, "用已验证的当前产品细节替换"],
    [/\bDo not copy the reference person, floor, exact pose, text style, or product shape\b/g, "不要复制参考图的人物、地面、准确姿势、文字样式或产品形状"],
    [/\bDo not invent folding, detachable parts, straps, openings, holes, hinges, or steps\b/g, "不要虚构折叠、可拆部件、带子、开口、孔洞、铰链或步骤"],
    [/\bdo not add extra views, scenes, claims, or callouts unless the current reference slot calls for them\b/g, "除非当前参考图位需要，否则不要添加额外视角、场景、宣称或标注"],
    [/\bProduct identity lock comes first\b/g, "产品身份锁定优先"],
    [/\bexact selected current product only\b/g, "只生成当前选中的准确产品"],
    [/\bno category substitution\b/g, "不要替换成其他品类"],
    [/\bno redesign\b/g, "不要重新设计产品"],
    [/\bno invented parts\b/g, "不要虚构部件"],
    [/\bIdentity lock\b/g, "产品身份锁定"],
    [/\bExact source product\b/g, "准确来源产品"],
    [/\bExact product type\/name\b/g, "准确产品类型/名称"],
    [/\bExact option\/spec\b/g, "准确选项/规格"],
    [/\bExact color\b/g, "准确颜色"],
    [/\bExact material\b/g, "准确材质"],
    [/\bExact visible structure\b/g, "准确可见结构"],
    [/\bPack count if shown\b/g, "如展示包装数量需准确"],
    [/\bKeep authentic markings\b/g, "保留真实产品标识"],
    [/\bCurrent selected option\b/g, "当前选中选项"],
    [/\bCurrent option\b/g, "当前选项"],
    [/\bDetail fields\b/g, "细节字段"],
    [/\bSummary points\b/g, "总结卖点"],
    [/\bDetail inset subjects\b/g, "细节小窗主题"],
    [/\bMacro focus\b/g, "微距重点"],
    [/\bScene\b/g, "场景"],
    [/\bReference\b/g, "参考"],
    [/\bcomposition only\b/g, "只参考构图"],
    [/\bcopy no claims, text, brand, or people\b/g, "不要复制对方宣称、文字、品牌或人物"],
    [/\b1:1 Amazon listing image\b/g, "1:1 亚马逊 listing 图片"],
    [/\b1:1 Amazon image\b/g, "1:1 亚马逊图片"],
    [/\b4K clarity\b/g, "4K 清晰度"],
    [/\bsharp realistic detail\b/g, "清晰真实细节"],
    [/\bpremium scene-based hero background\b/g, "高级场景化主图背景"],
    [/\bproduct occupies most of the frame\b/g, "产品占据画面主体"],
    [/\bwhite background\b/g, "白底"],
    [/\bclean studio lighting\b/g, "干净棚拍光线"],
    [/\bverified overlay text only when useful\b/g, "只在有用时添加已验证的覆盖文字"],
    [/\bNo Chinese text\b/g, "图片内不要出现中文文字"],
    [/\bkeep authentic non-Chinese product markings only\b/g, "只保留真实的非中文产品标识"],
    [/\bEnglish labels only\b/g, "图片内标签只用英文"],
    [/\bno full sentence captions\b/g, "不要完整句说明文字"],
    [/\bexplanatory phrases\b/g, "不要解释性短语"],
    [/\bdescriptive caption\b/g, "描述性说明文字"],
    [/\bvisual proof target only\b/g, "仅作为视觉证明目标"],
    [/\bnot on-image text\b/g, "不要写到图上"],
    [/\blabels 3-5 words\b/g, "标签 3-5 个英文词"],
    [/\bmax 2 on selling-point images\b/g, "卖点图最多 2 个标签"],
    [/\bmax 3 on parameter\/summary images\b/g, "参数/总结图最多 3 个标签"],
    [/\bno paragraphs\b/g, "不要段落文字"],
    [/\bno badges\b/g, "不要徽章式贴纸"],
    [/\bno repeated claims\b/g, "不要重复宣称"],
    [/\bno text stacking\b/g, "不要堆叠文字"],
    [/\bVisual proof first\b/g, "视觉证明优先"],
    [/\buse action, close-ups, icons, arrows, or measurements\b/g, "用动作、特写、图标、箭头或尺寸证明"],
    [/\btext is only a short locator\b/g, "文字只作为短标签定位"],
    [/\bPeople optional\b/g, "人物可选"],
    [/\bproduct remains the focus\b/g, "产品始终是主体"],
    [/\buse European\/American model only when it proves fit\/use\b/g, "仅在证明穿戴/使用时使用欧美模特"],
    [/\bOn-image length labels use inches \(in\)\b/g, "图片内长度标签使用英寸 (in)"],
    [/\bconvert source cm\/mm\b/g, "将来源 cm/mm 转换为英寸"],
    [/\bFinal image file <= 5 MB\b/g, "最终图片文件不超过 5 MB"],
    [/\bNo wrong product\b/g, "不要错误产品"],
    [/\binvented specs\b/g, "不要虚构规格"],
    [/\bunsupported claims\b/g, "不要无依据宣称"],
    [/\bextra logos\b/g, "不要额外 logo"],
    [/\bChinese\/source text\b/g, "不要中文/来源文字"],
    [/\bdense copy\b/g, "不要密集文案"],
    [/\blong labels\b/g, "不要长标签"],
    [/\bbullets\b/g, "不要项目符号"],
    [/\bblur\b/g, "不要模糊"],
    [/\bfocus\b/g, "聚焦"],
    [/\bheadline\b/g, "标题"],
    [/\buses polished Amazon editorial typography integrated with the scene\b/g, "使用自然融入场景的精致亚马逊编辑风标题排版"],
    [/\bprove\b/g, "证明"],
    [/\bthrough\b/g, "通过"],
    [/\bElegant hierarchy\b/g, "层级优雅"],
    [/\bgenerous padding\b/g, "留白充足"],
    [/\bnatural line breaks\b/g, "自然换行"],
    [/\bno oversized hard-sell banner\b/g, "不要夸张硬广横幅"],
    [/\bsticker look\b/g, "不要贴纸感"],
    [/\bdense claim block\b/g, "不要密集宣称块"],
    [/\brepeated benefit\b/g, "不要重复卖点"],
    [/\bDistinct from Image\b/g, "需区别于第"],
    [/\bProduct remains clear and accurate\b/g, "产品保持清晰准确"],
    [/\bno unsupported claims\b/g, "不要无依据宣称"],
    [/\bUse the reference blueprint proof method\b/g, "使用参考蓝图的证明方式"],
    [/\bdo not force\b/g, "不要强行加入"],
    [/\bunless verified\b/g, "除非资料已验证"],
    [/\bExecute slot composition exactly\b/g, "严格执行该图位构图"],
    [/\bBlueprint proof method\b/g, "蓝图证明方式"],
    [/\bProduct\b/g, "产品"],
    [/\bOption\b/g, "选项"],
    [/\bColor\b/g, "颜色"],
    [/\bMaterial\b/g, "材质"],
    [/\bStructure\b/g, "结构"],
  ];
  const translated = replacements.reduce((text, [pattern, replacement]) => text.replace(pattern, replacement), segment);
  return translatePromptVocabulary(translated);
}

function translatePromptVocabulary(text) {
  const vocabulary = {
    a: "一个",
    about: "约",
    accurate: "准确",
    accurately: "准确地",
    accuracy: "准确性",
    action: "动作",
    adapt: "适配",
    add: "添加",
    added: "添加的",
    aligned: "对齐的",
    allowed: "允许",
    alternative: "替代",
    amazon: "亚马逊",
    angle: "角度",
    annotations: "标注",
    arrows: "箭头",
    aspirational: "有高级向往感的",
    authentic: "真实",
    avoid: "避免",
    background: "背景",
    balanced: "平衡",
    based: "基于",
    benefit: "卖点",
    benefits: "卖点",
    block: "块",
    bold: "醒目",
    borrow: "借用",
    brightness: "亮度",
    callout: "标注",
    callouts: "标注",
    caption: "说明文字",
    captions: "说明文字",
    category: "品类",
    centered: "居中",
    certification: "认证",
    chart: "图表",
    clarity: "清晰度",
    clean: "干净",
    clear: "清晰",
    claims: "宣称",
    close: "特写",
    closeup: "特写",
    collage: "拼图",
    color: "颜色",
    colors: "颜色",
    comparison: "对比",
    complete: "完整",
    composition: "构图",
    concise: "简洁",
    consistent: "一致",
    constraints: "约束",
    context: "语境",
    copy: "复制",
    core: "核心",
    count: "数量",
    crop: "裁切",
    current: "当前",
    capacity: "容量",
    compatible: "适配",
    density: "密度",
    depth: "层次",
    desirable: "有吸引力",
    detail: "细节",
    details: "细节",
    diagram: "示意图",
    different: "不同",
    dimensions: "尺寸",
    display: "展示",
    distance: "距离",
    dominate: "占主导",
    dominant: "主体",
    drawn: "绘制",
    each: "每个",
    easy: "易于",
    edge: "边缘",
    effects: "效果",
    english: "英文",
    environment: "环境",
    exact: "准确",
    exactly: "严格",
    extra: "额外",
    facts: "事实",
    feature: "功能",
    features: "功能",
    feel: "感觉",
    filler: "填充",
    file: "文件",
    final: "最终",
    fit: "适配",
    finish: "工艺",
    first: "优先",
    floating: "悬浮",
    focus: "重点",
    folded: "折叠",
    foreground: "前景",
    form: "形态",
    frame: "画面",
    furniture: "家具",
    generous: "充足",
    geometry: "几何形态",
    grid: "网格",
    guardrails: "约束",
    guide: "引导",
    cues: "线索",
    hands: "手",
    harsh: "生硬",
    headline: "标题",
    hierarchy: "层级",
    high: "高",
    end: "端",
    hide: "遮挡",
    highlight: "突出",
    human: "人物",
    icons: "图标",
    image: "图片",
    in: "在",
    inches: "英寸",
    included: "包含",
    information: "信息",
    infographic: "信息图",
    insets: "小窗",
    integrated: "融合",
    invented: "虚构",
    item: "物品",
    items: "物品",
    label: "标签",
    labels: "标签",
    large: "大",
    largest: "最大",
    layout: "布局",
    length: "长度",
    light: "光线",
    lighting: "光线",
    line: "线条",
    listing: "listing",
    locator: "定位标签",
    lock: "锁定",
    logos: "logo",
    long: "长",
    macro: "微距",
    main: "主要",
    markings: "标识",
    material: "材质",
    measurement: "测量",
    measurements: "尺寸",
    method: "方式",
    mini: "小型",
    model: "模特",
    mood: "氛围",
    natural: "自然",
    name: "名称",
    needed: "需要时",
    negative: "留白",
    numeric: "数字",
    object: "对象",
    occupies: "占据",
    optional: "可选",
    option: "选项",
    options: "选项",
    order: "顺序",
    outdoor: "户外",
    overlay: "覆盖",
    package: "包装",
    packaging: "包装",
    panel: "面板",
    panels: "面板",
    parameter: "参数",
    quantity: "数量",
    paragraphs: "段落",
    parts: "部件",
    people: "人物",
    photo: "照片",
    physical: "实体",
    placed: "放置",
    polished: "精致",
    poster: "海报",
    premium: "高级",
    present: "呈现",
    priority: "优先级",
    product: "产品",
    props: "道具",
    proof: "证明",
    prove: "证明",
    realistic: "真实",
    recognizable: "可识别",
    refined: "精致",
    reference: "参考",
    render: "渲染",
    rendering: "渲染",
    replace: "替换",
    repeated: "重复",
    required: "必需",
    restrained: "克制",
    rhythm: "节奏",
    role: "角色",
    room: "房间",
    ruler: "尺规",
    range: "范围",
    scene: "场景",
    scenes: "场景",
    secondary: "次要",
    selected: "选中",
    separate: "分开",
    set: "套装",
    shadow: "阴影",
    shadows: "阴影",
    shape: "形状",
    sharp: "清晰",
    shot: "镜头",
    show: "展示",
    shown: "展示",
    simple: "简单",
    size: "尺寸",
    slogans: "口号",
    soft: "柔和",
    source: "来源",
    space: "留白",
    spacing: "间距",
    specification: "规格",
    specs: "规格",
    stacking: "堆叠",
    stays: "保持",
    sticker: "贴纸",
    studio: "棚拍",
    style: "风格",
    subject: "主体",
    subtle: "细微",
    surface: "表面",
    summary: "总结",
    support: "支撑",
    table: "表格",
    tags: "标签",
    technology: "工艺",
    text: "文字",
    texture: "纹理",
    theme: "主题",
    through: "通过",
    tiny: "很小",
    title: "标题",
    typography: "字体排版",
    unverified: "未验证",
    unsupported: "无依据",
    use: "使用",
    useful: "有用",
    verified: "已验证",
    view: "视图",
    visible: "可见",
    visual: "视觉",
    width: "宽度",
    matched: "匹配",
    matching: "匹配",
    multi: "多",
    panel: "面板",
    first: "优先",
    derived: "提取",
    accurate: "准确",
    waterproofing: "防水",
    weight: "重量",
    white: "白色",
    wordart: "艺术字",
    wrong: "错误",
    and: "和",
    or: "或",
    with: "带有",
    without: "不带",
    only: "仅",
    when: "当",
    where: "在",
    while: "同时",
    as: "作为",
    from: "从",
    for: "用于",
    into: "成",
    not: "不",
    no: "不要",
    must: "必须",
    should: "应",
  };
  const translated = String(text || "").replace(/\b[A-Za-z][A-Za-z0-9/-]*\b/g, (word) => {
    if (/^[A-Z0-9/-]{2,}$/.test(word)) return word;
    return translatePromptWord(word, vocabulary);
  });
  return cleanChinesePromptTranslation(markResidualEnglishTerms(translated));
}

function translatePromptWord(word, vocabulary) {
  const lower = String(word || "").toLowerCase();
  if (vocabulary[lower]) return vocabulary[lower];
  if (/[-/]/.test(lower)) {
    const translatedParts = lower.split(/[-/]+/).map((part) => vocabulary[part] || part);
    if (translatedParts.some((part, index) => part !== lower.split(/[-/]+/)[index])) {
      return translatedParts.join("");
    }
  }
  return word;
}

function markResidualEnglishTerms(text) {
  return String(text || "").replace(/\b[A-Za-z][A-Za-z0-9-]*(?:[\/\s]+[A-Za-z][A-Za-z0-9-]*)*\b/g, (match) => {
    const clean = match.trim();
    if (!clean) return match;
    if (/^[A-Z0-9/-]{2,}$/.test(clean)) return match;
    if (/^(cm|mm|in|mb|kg|g|ml|oz|pcs|pc|set|sets|pack|packs|x)$/i.test(clean)) return match;
    return `原始词「${clean}」`;
  });
}

function cleanChinesePromptTranslation(text) {
  return String(text || "")
    .replace(/([一-龥])\s+(?=[一-龥])/g, "$1")
    .replace(/([一-龥])\s*\/\s*(?=[一-龥])/g, "$1/")
    .replace(/([一-龥])\s*,\s*/g, "$1，")
    .replace(/\s*,\s*([一-龥])/g, "，$1")
    .replace(/([一-龥])\s*;\s*/g, "$1；")
    .replace(/\s*;\s*([一-龥])/g, "；$1")
    .replace(/([一-龥])\s*:\s*/g, "$1：")
    .replace(/\s*:\s*([一-龥])/g, "：$1")
    .replace(/\s+\./g, ".")
    .replace(/。+/g, "。")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function compactPromptItems(items, fallback = "", limit = 5) {
  const cleanItems = uniquePromptItems(items)
    .map((item) => cleanTokenValue(item))
    .filter(Boolean);
  const selected = [];
  cleanItems.forEach((item) => {
    const lower = comparablePromptItem(item);
    const keywordSet = promptKeywordSet(item);
    const existingIndex = selected.findIndex((existing) => {
      const existingLower = comparablePromptItem(existing);
      const existingKeywordSet = promptKeywordSet(existing);
      return lower.includes(existingLower)
        || existingLower.includes(lower)
        || Boolean(keywordSet && existingKeywordSet && (
          keywordSet === existingKeywordSet
          || promptKeywordSetContains(keywordSet, existingKeywordSet)
          || promptKeywordSetContains(existingKeywordSet, keywordSet)
        ));
    });
    if (existingIndex > -1) {
      if (item.length > selected[existingIndex].length) selected[existingIndex] = item;
      return;
    }
    selected.push(item);
  });
  return selected.length ? selected.slice(0, limit).join(" / ") : fallback;
}

function promptItemsOverlap(left, right) {
  const leftClean = comparablePromptItem(left);
  const rightClean = comparablePromptItem(right);
  if (!leftClean || !rightClean) return false;
  if (leftClean.includes(rightClean) || rightClean.includes(leftClean)) return true;

  const stopWords = new Set([
    "accurate",
    "available",
    "compatible",
    "current",
    "option",
    "product",
    "realistic",
    "selected",
    "true",
    "verified",
    "visible",
  ]);
  const leftWords = new Set(leftClean.split(" ").filter((word) => word.length > 2 && !stopWords.has(word)));
  const rightWords = rightClean.split(" ").filter((word) => word.length > 2 && !stopWords.has(word));
  const smallerCount = Math.min(leftWords.size, rightWords.length);
  if (smallerCount < 2) return false;

  const overlapCount = rightWords.filter((word) => leftWords.has(word)).length;
  return overlapCount >= Math.min(3, smallerCount) || overlapCount / smallerCount >= 0.7;
}

function promptKeywordSet(value) {
  return comparablePromptItem(value)
    .split(" ")
    .filter((word) => word.length > 2)
    .sort()
    .join(" ");
}

function promptKeywordSetContains(left, right) {
  const leftSet = new Set(String(left || "").split(" ").filter(Boolean));
  const rightWords = String(right || "").split(" ").filter(Boolean);
  return rightWords.length >= 3 && rightWords.every((word) => leftSet.has(word));
}

function isGenericPromptFallback(value) {
  const clean = comparablePromptItem(cleanTokenValue(value));
  if (!clean) return true;
  return [
    "verified product material",
    "accurate product color",
    "compatible use",
    "realistic product use scene",
    "verified product benefit",
    "verified secondary benefit",
    "available verified product options",
    "selected product specification",
    "the product",
  ].some((generic) => clean === generic);
}

function specificPromptValue(value, fallback = "") {
  const clean = cleanTokenValue(value);
  return isGenericPromptFallback(clean) ? fallback : clean;
}

function compactSpecificPromptItems(items, fallback = "", limit = 5) {
  return compactPromptItems(
    items.map((item) => specificPromptValue(item, "")).filter(Boolean),
    fallback,
    limit,
  );
}

function sellingPointKey(value) {
  const clean = comparablePromptItem(value);
  if (!clean) return "";
  if (/(?:compact|portable|folded|pocket|travel|small|小巧|便携|收纳|折叠|迷你|随身)/i.test(value)) return "compact";
  if (/(?:lightweight|light weight|轻量|轻便|轻巧)/i.test(value)) return "lightweight";
  if (/(?:break resistant|without breaking|fracture|tear|防断|抗拉|不断裂|不惧断裂)/i.test(value)) return "break-resistant";
  if (/(?:deformation|不变形|均匀拉伸)/i.test(value)) return "deformation-resistant";
  if (/(?:3x|3 x|three times|3倍)/i.test(value)) return "stretch-range";
  if (/(?:full body|全身)/i.test(value)) return "full-body";
  if (/(?:durable|耐用|安全)/i.test(value)) return "durable";
  if (/(?:multi use|versatility|多用途|多场景|不同需求)/i.test(value)) return "multi-use";
  if (/(?:easy clean|washable|易清洁|可水洗)/i.test(value)) return "easy-clean";
  if (/(?:stable|sturdy|support|承重|稳固|牢固|省力)/i.test(value)) return "stable";
  if (/(?:uv|upf|sun|shade|防晒|遮阳|防紫外|紫外线|隔热|黑胶)/i.test(value)) return "uv";
  if (/(?:rain|waterproof|water resistant|防雨|晴雨|拒水|防水)/i.test(value)) return "rain";
  if (/(?:windproof|wind resistant|reinforced|ribs?|防风|抗风|加固|伞骨|骨架)/i.test(value)) return "windproof";
  if (/(?:non slip|anti slip|grip|silicone|printed grip|防滑|点胶|硅胶|胶印|抓地)/i.test(value)) return "grip";
  if (/(?:cross strap|strappy|3d cross|绑带|交叉|立体)/i.test(value)) return "cross-strap";
  if (/(?:five toe|toe separated|五指|五趾|分趾)/i.test(value)) return "five-toe";
  if (/(?:mid calf|long sock|coverage|中筒|长筒|高筒)/i.test(value)) return "coverage";
  if (/(?:seamless|hand linked|无骨|手工缝头)/i.test(value)) return "seam";
  if (/(?:sweat|moisture|吸汗)/i.test(value)) return "sweat";
  if (/(?:friction|防摩擦)/i.test(value)) return "friction";
  if (/(?:single needle|knit texture|单针)/i.test(value)) return "knit";
  if (/(?:combed cotton|cotton|精梳棉|棉)/i.test(value)) return "cotton";
  if (/(?:elastic|cuff|高弹|橡筋|袜口)/i.test(value)) return "elastic";
  if (/(?:soft|delicate|柔软|细腻)/i.test(value)) return "soft";
  if (/(?:deodor|antibacterial|抗菌|阻菌|防臭)/i.test(value)) return "hygiene";
  if (/(?:filter|filtration|flow|过滤|萃取)/i.test(value)) return "filtration";
  if (/(?:unbleached|wood pulp|木浆|未漂白|原色)/i.test(value)) return "material";
  return promptKeywordSet(clean) || clean;
}

function uniqueSellingPoints(items, limit = 6) {
  const selected = [];
  const seenKeys = new Set();
  items
    .map((item) => specificPromptValue(item, ""))
    .filter(Boolean)
    .forEach((item) => {
      const key = sellingPointKey(item);
      if (!key || seenKeys.has(key)) return;
      if (selected.some((existing) => promptItemsOverlap(existing, item))) return;
      selected.push(item);
      seenKeys.add(key);
    });
  return selected.slice(0, limit);
}

function sellingPointCandidates(facts, limit = 6) {
  return uniqueSellingPoints([
    ...splitSellingPointText(facts.feature1),
    ...splitSellingPointText(facts.feature2),
    ...splitSellingPointText(facts.feature3),
    facts.structure,
    facts.surfaceFinish,
    ...splitSellingPointText(visibleDetailParameter(facts.detailParameter)),
  ].filter((point) => !isOrdinaryMaterialSellingPoint(point)), limit);
}

function isOrdinaryMaterialSellingPoint(value) {
  const clean = comparablePromptItem(value);
  return clean === "cotton" || clean === "breathable cotton comfort";
}

function remainingSellingPointText(points, used = 2, limit = 4) {
  return uniqueSellingPoints(points, used + limit + 3)
    .filter((point) => !isOrdinaryMaterialSellingPoint(point))
    .slice(used, used + limit)
    .join(", ");
}

function preferredSecondarySellingPoint(points, usedPoints = []) {
  const used = usedPoints.filter(Boolean);
  const available = uniqueSellingPoints(points, 6).filter((point) => (
    !used.some((usedPoint) => promptItemsOverlap(usedPoint, point))
    && !["cotton", "material"].includes(sellingPointKey(point))
    && !isOrdinaryMaterialSellingPoint(point)
  ));
  const preferredKeys = ["break-resistant", "deformation-resistant", "durable", "multi-use", "compact", "lightweight", "grip", "rain", "uv", "windproof", "stable", "easy-clean", "seam", "sweat", "friction", "coverage", "elastic", "soft", "knit"];
  for (const key of preferredKeys) {
    const matched = available.find((point) => sellingPointKey(point) === key);
    if (matched) return matched;
  }
  return available[0] || "";
}

function sellingPointGroupText(points) {
  return limitedSellingPoints(points, 2).join(" + ");
}

function sellingPointGroupFromText(value) {
  return String(value || "")
    .split(/\s*\+\s*/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function limitedSellingPoints(points, limit = 2, exclusions = []) {
  const sourcePoints = Array.isArray(points) ? points : [points];
  const excluded = uniqueSellingPoints(Array.isArray(exclusions) ? exclusions : [exclusions], 8);
  const excludedKeys = new Set(excluded.map((point) => sellingPointKey(point)).filter(Boolean));
  return uniqueSellingPoints(sourcePoints, limit + excluded.length + 6)
    .filter((point) => {
      const key = sellingPointKey(point);
      if (key && excludedKeys.has(key)) return false;
      return !excluded.some((usedPoint) => promptItemsOverlap(usedPoint, point));
    })
    .slice(0, limit);
}

function distributedSellingPointGroups(points, groupIndex = 0, groupSize = 2, maxPoints = 4) {
  const cleanPoints = uniqueSellingPoints(Array.isArray(points) ? points : [points], maxPoints);
  const size = cleanPoints.length >= 3 ? groupSize : 1;
  const start = groupIndex * size;
  const group = cleanPoints.slice(start, start + size);
  if (group.length) return group;
  return cleanPoints.slice(groupIndex, groupIndex + 1);
}

function sellingPointGroups(facts, groupIndex = 0, groupSize = 2) {
  return distributedSellingPointGroups(sellingPointCandidates(facts, 6), groupIndex, groupSize, 4);
}

function clampSellingPointTitle(value, fallback = "Info") {
  const clean = String(value || "")
    .replace(/[^a-z0-9]/gi, "")
    .trim();
  const fallbackClean = String(fallback || "Info").replace(/[^a-z0-9]/gi, "") || "Info";
  const source = clean || fallbackClean;
  const clipped = source.slice(0, 5);
  return clipped.charAt(0).toUpperCase() + clipped.slice(1);
}

function sellingPointWords(point) {
  return String(point || "")
    .replace(/\[[^\]]+\]/g, " ")
    .replace(/[^a-z0-9\s-]/gi, " ")
    .replace(/[-_/]+/g, " ")
    .split(/\s+/)
    .map((word) => word.trim())
    .filter((word) => /^[a-z0-9]+$/i.test(word) && !/^(?:and|with|for|the|product|design|feature|benefit|verified)$/i.test(word));
}

function sellingPointLabelParts(point, fallback = "Info") {
  const labelByKey = {
    compact: ["Pack", "Flat"],
    lightweight: ["Light", "Carry"],
    "break-resistant": ["Firm", "Hold"],
    "deformation-resistant": ["Shape", "Keep"],
    "stretch-range": ["Range", "Pull"],
    "full-body": ["Body", "Train"],
    durable: ["Daily", "Use"],
    "multi-use": ["Multi", "Use"],
    "easy-clean": ["Clean", "Wash"],
    stable: ["Firm", "Base"],
    uv: ["UV", "Shade"],
    rain: ["Dry", "Water"],
    windproof: ["Wind", "Hold"],
    grip: ["Grip", "Sole"],
    "cross-strap": ["Strap", "Hold"],
    "five-toe": ["Toes", "Fit"],
    coverage: ["Cover", "Fit"],
    seam: ["Seam", "Soft"],
    sweat: ["Dry", "Sweat"],
    friction: ["Glide", "Soft"],
    knit: ["Knit", "Feel"],
    cotton: ["Soft", "Touch"],
    elastic: ["Flex", "Fit"],
    soft: ["Soft", "Feel"],
    hygiene: ["Fresh", "Wear"],
    filtration: ["Flow", "Brew"],
    material: ["Feel", "Touch"],
  };
  const key = sellingPointKey(point);
  if (labelByKey[key]) {
    return labelByKey[key].map((part) => clampSellingPointTitle(part, fallback)).filter(Boolean).slice(0, 2);
  }

  const words = sellingPointWords(point);
  const preferred = words.filter((word) => word.length >= 3 && word.length <= 5);
  const title = preferred[0] || words[0] || fallback;
  const explanation = preferred.find((word) => !promptItemsOverlap(word, title)) || words.find((word) => !promptItemsOverlap(word, title));
  return [title, explanation]
    .filter(Boolean)
    .map((part) => clampSellingPointTitle(part, fallback))
    .filter(Boolean)
    .slice(0, 2);
}

function conciseSellingPointLabel(point, fallback = "Info") {
  return sellingPointLabelParts(point, fallback).join(" ") || clampSellingPointTitle(fallback, "Info");
}

function sellingPointLabels(points, fallback = "Info") {
  const labels = limitedSellingPoints(points, 2)
    .map((point) => conciseSellingPointLabel(point, fallback))
    .filter(Boolean);
  return uniquePromptItems(labels).slice(0, 2);
}

function sellingPointFocusText(points, fallback = "verified product detail") {
  return limitedSellingPoints(points, 2).join(" + ") || fallback;
}

function sellingPointDisplayText(points, fallback = "Info") {
  return sellingPointLabels(points, conciseSellingPointLabel(fallback)).join(" + ") || conciseSellingPointLabel(fallback);
}

function sellingPointHeadlineRule(points) {
  const labels = sellingPointLabels(points);
  if (!labels.length) return "Use one soft Title + Explanation group only when labeling verified visible product facts; each part max 5 characters.";
  return `Headline groups: ${labels.join(" + ")}. Match the left selling-point count exactly (${labels.length}); each selling point may use soft Title + Explanation text, each part max 5 characters.`;
}

function sellingPointSceneGuide(points, facts = {}) {
  const cleanPoints = limitedSellingPoints(points, 2);
  const guides = cleanPoints.map((point) => {
    const key = sellingPointKey(point);
    if (key === "filtration") return "show real filtration flow visually";
    if (key === "material") return "show material texture visually";
    return "show the verified benefit through product imagery only";
  });
  return compactPromptItems([
    ...guides,
    facts.scene && `Keep scene relevant to ${facts.scene}`,
  ], "", 4);
}

function sellingPointSceneDescription(points, facts = {}, fallback = "verified product detail") {
  if (!limitedSellingPoints(points, 2).length) {
    const baseScene = compactSpecificPromptItems([
      useSceneText(facts, neutralProductSceneFallback(), 2),
    ], neutralProductSceneFallback(), 2);
    return `Scene: ${baseScene}; use universal product-detail proof: ${verifiedProductDetailFallback()}; no unsupported benefit claims; no sentence captions.`;
  }
  const focusText = sellingPointFocusText(points, fallback);
  const sceneGuide = sellingPointSceneGuide(points, facts);
  const baseScene = compactSpecificPromptItems([
    useSceneText(facts, neutralProductSceneFallback(), 2),
  ], neutralProductSceneFallback(), 2);
  return `Scene: ${baseScene}; visual proof target only, do not write this target on the image: ${focusText}. Prove it through ${sceneGuide || "product imagery only"}; no sentence captions or explanatory phrases.`;
}

function sellingPointImageTemplateRule(points, facts = {}, imageName = "this selling-point image") {
  if (!limitedSellingPoints(points, 2).length) {
    return [
      `${imageName}: detail-focused Amazon proof layout using the current product only.`,
      sellingPointSceneDescription(points, facts),
      "On-image text may only be short label groups; no full sentence, no paragraph, no descriptive caption, no explanatory phrase.",
      "Elegant hierarchy, generous padding, natural line breaks; no oversized hard-sell banner, sticker look, dense claim block, repeated benefit, or unsupported feature claim.",
    ].join(" ");
  }
  const focusText = sellingPointFocusText(points);
  const sceneDescription = sellingPointSceneDescription(points, facts);
  return [
    `${imageName}: visual proof target only, not on-image text: ${focusText}. ${sellingPointHeadlineRule(points)} On-image text may only be these headline groups; no full sentence, no paragraph, no descriptive caption, no explanatory phrase.`,
    sceneDescription,
    "Elegant hierarchy, generous padding, natural line breaks; no oversized hard-sell banner, sticker look, dense claim block, or repeated benefit.",
  ].join(" ");
}

function comparablePromptItem(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[^\w\u4e00-\u9fff]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function compactVariantText(facts) {
  const productName = String(facts.productName || "").trim();
  const variantSource = cleanTokenValue(facts.variants);
  const variants = (variantSource.includes("|")
    ? variantSource.split(/\s+\|\s+/)
    : variantSource.split(/\s+\/\s+/))
    .map((item) => {
      const clean = item
        .replace(productName, "")
        .replace(/^[\s/-]+/, "")
        .trim();
      return clean || item.trim();
    })
    .filter(Boolean);
  return uniquePromptItems(variants).join(" / ") || variantSource || facts.variants;
}

function shortOptionText(facts) {
  const productName = String(facts.productName || "").trim();
  const option = cleanTokenValue(facts.titleSpec || facts.selectedSpec || "");
  if (!option) return "";
  if (productName && option.toLowerCase().startsWith(productName.toLowerCase())) {
    return option.slice(productName.length).replace(/^[\s,/-]+/, "").trim();
  }
  return option;
}

function visibleDetailParameter(value) {
  return convertLengthUnitsToInches(cleanTokenValue(value))
    .split(/\s*,\s*|\s*\/\s*/)
    .map((item) => item.trim())
    .filter((item) => item && !/antibacterial|deodorizing|阻菌|抗菌|防臭/i.test(item))
    .slice(0, 2)
    .join(", ");
}

function detailTextureText(facts, fallback = "accurate visible material texture from the reference") {
  return compactSpecificPromptItems([
    facts.material,
    facts.structure,
    facts.surfaceFinish,
    visibleDetailParameter(facts.detailParameter),
  ], fallback, 3);
}

function visibleTextureDetails(facts) {
  return compactSpecificPromptItems([detailTextureText(facts), facts.color], "visible material texture and true color", 4);
}

function referenceRuleText() {
  return sourcePayload.competitor
    ? "Reference: composition only; copy no claims, text, brand, or people."
    : "Reference: clean Amazon listing style.";
}

function textFingerprint(value) {
  const source = String(value || "").slice(0, 20000);
  let hash = 2166136261;
  for (let index = 0; index < source.length; index += 1) {
    hash ^= source.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36).slice(0, 6).toUpperCase();
}

function referenceSourceLabel(text) {
  const listedFiles = String(text || "").match(/REFERENCE_SOURCE_FILES:\s*([^\n]+)/i)?.[1];
  if (listedFiles) return listedFiles.trim().slice(0, 80);
  const fileName = String(text || "").match(/Source HTML file:\s*([^\n<]+)/i)?.[1];
  if (fileName) return fileName.trim().slice(0, 80);
  const title = extractFirstMatch(String(text || ""), [
    /(?:Amazon\.com\s*:\s*)?([^|]{12,120})(?:\s*\||\s*Amazon\.com|$)/i,
  ]);
  return title ? title.trim().slice(0, 80) : `uploaded reference ${textFingerprint(text)}`;
}

function referenceLayoutCues(text) {
  const source = String(text || "");
  const cues = [];
  const add = (value) => {
    if (value && !cues.includes(value)) cues.push(value);
  };
  if (/main image|hero image|white background|纯白|主图|首图/i.test(source)) add("main hero framing");
  if (/lifestyle|scene|model|wearing|beach|pool|shower|bathroom|hotel|travel|户外|场景|真人|穿着|沙滩|浴室|泳池|酒店|旅行/i.test(source)) add("lifestyle scene slot");
  if (/infographic|callout|label|icon|badge|diagram|参数|卖点图|说明图|图标|标注|箭头/i.test(source)) add("infographic callout layout");
  if (/size chart|measurement|dimension|尺码|尺寸|测量|规格/i.test(source)) add("size or measurement chart");
  if (/close.?up|detail|texture|material|sole|tread|macro|细节|特写|材质|鞋底|纹理/i.test(source)) add("detail close-up slot");
  if (/multi.?angle|front|side|back|top view|底视|侧面|正面|背面|多角度/i.test(source)) add("multi-angle product view");
  if (/collage|grid|panel|四宫格|拼图|组合/i.test(source)) add("multi-panel collage rhythm");
  if (/step|how to|fold|foldable|storage|pack|收纳|折叠|步骤|使用方法/i.test(source)) add("process or storage demonstration");
  return cues.slice(0, 5);
}

function referenceProofCues(text) {
  const source = String(text || "");
  const cues = [];
  const add = (value) => {
    if (value && !cues.includes(value)) cues.push(value);
  };
  if (/non.?slip|anti.?slip|grip|traction|防滑|止滑|抓地/i.test(source)) add("grip-proof slot");
  if (/lightweight|light weight|轻便|轻量|轻巧/i.test(source)) add("lightweight proof slot");
  if (/quick.?dry|water|shower|pool|beach|dry|防水|速干|浴室|泳池|沙滩/i.test(source)) add("wet-use or quick-dry proof slot");
  if (/compact|portable|travel|fold|pack|storage|便携|旅行|折叠|收纳/i.test(source)) add("portable storage proof slot");
  if (/soft|comfort|cushion|flexible|柔软|舒适|缓震|弹性/i.test(source)) add("comfort or flexibility proof slot");
  if (/durable|wear.?resistant|thick|reinforced|耐用|耐磨|加厚|加固/i.test(source)) add("durability detail slot");
  if (/material|eva|rubber|silicone|foam|材质|材料|橡胶|硅胶/i.test(source)) add("material texture proof slot");
  return cues.slice(0, 5);
}

function firstPatternIndex(source, patterns) {
  let best = -1;
  patterns.forEach((pattern) => {
    const match = String(source || "").match(pattern);
    if (!match) return;
    const index = match.index ?? -1;
    if (index < 0) return;
    if (best < 0 || index < best) best = index;
  });
  return best;
}

function referenceBlueprintCandidates(text) {
  const source = String(text || "");
  const definitions = [
    {
      key: "hero",
      patterns: [/main image|hero image|white background|纯白|主图|首图/i],
      role: "Product-only hero image",
      composition: "dominant centered product, clean white or very light studio background, reference shot distance and view count",
      proof: "prove product form, color, silhouette, material surface, and selected option without props or people",
      text: "no added text",
    },
    {
      key: "structure",
      patterns: [/infographic|callout|label|diagram|structure|结构|说明图|标注|箭头|拆卸|折叠/i],
      role: "Structure explanation image",
      composition: "clean instructional layout with sparse callouts, arrows, or 2-3 inset details following the reference rhythm",
      proof: "explain only verified visible structure from the current product data",
      text: "short English labels allowed",
    },
    {
      key: "measurement",
      patterns: [/size chart|measurement|dimension|尺码|尺寸|测量|规格|参数/i],
      role: "Size or parameter infographic",
      composition: "measurement-first layout, ruler arrows or size table only when verified values exist, clean Amazon chart spacing",
      proof: "show current product option and verified size/spec fields; omit unverified competitor numbers",
      text: "concise English measurement labels only",
    },
    {
      key: "detail",
      patterns: [/close.?up|detail|texture|material|sole|tread|macro|细节|特写|材质|鞋底|纹理/i],
      role: "Material and detail proof image",
      composition: "one accurate product view plus macro close-up insets following the reference crop/spacing",
      proof: "prove current product material, surface texture, edge, sole, stitching, or construction details",
      text: "2-4 word labels max",
    },
    {
      key: "feature",
      patterns: [/feature|benefit|selling point|badge|icon|卖点|功能|图标/i],
      role: "Functional benefit image",
      composition: "single benefit-led product visual with restrained icons/callouts matching the reference hierarchy",
      proof: "prove one verified current-product benefit through realistic visual evidence",
      text: "short benefit label, no slogans",
    },
    {
      key: "lifestyle",
      patterns: [/lifestyle|scene|model|wearing|beach|pool|shower|bathroom|hotel|travel|户外|场景|真人|穿着|沙滩|浴室|泳池|酒店|旅行/i],
      role: "Lifestyle use scene",
      composition: "real use environment with reference crop, prop density, lighting mood, and product visibility",
      proof: "show current product only in source-verified use context; if none exists, keep a neutral product-first environment without copying the reference scene",
      text: "no text or one tiny scene label",
    },
    {
      key: "multi-angle",
      patterns: [/multi.?angle|front|side|back|top view|底视|侧面|正面|背面|多角度/i],
      role: "Multi-angle product view",
      composition: "several clean product angles arranged with reference spacing, product-only or minimal props",
      proof: "show current product shape from multiple views while preserving selected color and structure",
      text: "no text",
    },
    {
      key: "collage",
      patterns: [/collage|grid|panel|四宫格|拼图|组合/i],
      role: "Multi-panel usage collage",
      composition: "exactly four equal-size panels in a clean 2x2 grid; no oversized hero panel, no sidebar stack, no masonry collage; selected product stays readable in every panel, usually about 12-15% of each panel rather than tiny or cramped",
      proof: "each panel proves a distinct verified use scene for the current product; no product-only detail, storage, flat-lay, or display panel",
      text: "no text labels, captions, badges, arrows, or callouts",
    },
    {
      key: "process",
      patterns: [/step|how to|fold|foldable|storage|pack|收纳|折叠|步骤|使用方法/i],
      role: "Process or storage demonstration",
      composition: "step sequence or storage scene following the reference order and spacing",
      proof: "show only verified folding, packing, storage, or use method from current product facts",
      text: "numbered labels allowed only for verified steps",
    },
  ];
  return definitions
    .map((definition) => ({ ...definition, index: firstPatternIndex(source, definition.patterns) }))
    .filter((definition) => definition.index >= 0)
    .sort((left, right) => left.index - right.index);
}

function defaultReferenceBlueprint() {
  return [
    {
      key: "hero",
      role: "Product-only hero image",
      composition: "dominant current product on pure white or very light studio background",
      proof: "show exact product form, selected option, color, material, and silhouette",
      text: "no added text",
    },
    {
      key: "structure",
      role: "Structure explanation image",
      composition: "clean callout layout with sparse arrows or detail insets",
      proof: "explain verified visible structure only",
      text: "short English labels allowed",
    },
    {
      key: "detail",
      role: "Material and detail proof image",
      composition: "full product plus 1-2 macro detail close-ups",
      proof: "prove material, edge, sole, texture, or construction details",
      text: "2-4 word labels max",
    },
    {
      key: "feature",
      role: "Functional benefit image",
      composition: "one clear visual proof around the strongest verified benefit",
      proof: "prove one verified benefit without borrowing competitor claims",
      text: "short benefit label only",
    },
    {
      key: "lifestyle",
      role: "Lifestyle use scene",
      composition: "source-verified use environment if available; otherwise neutral product-first environment; selected product occupies at least 30% of the image area",
      proof: "show only extracted scene/use facts; if none exist, show product placement without inferred lifestyle claims",
      text: "no text or one tiny scene label",
    },
    {
      key: "summary",
      role: "Summary or closing image",
      composition: "clean Amazon final image with product hero and 2-3 non-repeated proof points",
      proof: "summarize only current verified product benefits",
      text: "short labels, no long copy",
    },
  ];
}

function referenceBlueprintSlots(text) {
  const candidates = referenceBlueprintCandidates(text);
  const defaults = defaultReferenceBlueprint();
  const used = new Set();
  const pick = (preferredKeys, fallbackIndex) => {
    const candidate = candidates.find((item) => preferredKeys.includes(item.key) && !used.has(item.key))
      || candidates.find((item) => !used.has(item.key))
      || defaults[fallbackIndex];
    if (candidate?.key) used.add(candidate.key);
    return candidate;
  };
  return [
    pick(["hero", "multi-angle"], 0),
    pick(["structure", "process", "measurement"], 1),
    pick(["detail", "measurement"], 2),
    pick(["feature", "detail"], 3),
    pick(["lifestyle", "process", "collage"], 4),
    pick(["collage", "lifestyle", "multi-angle"], 5),
  ].map((slot, index) => ({
    ...defaults[index],
    ...slot,
    slotNumber: index + 1,
  }));
}

function referenceBlueprintSlot(typeId = "") {
  const index = Math.max(0, Math.min(5, Number.parseInt(typeId, 10) - 1 || 0));
  return referenceBlueprintSlots(sourcePayload.competitor || "")[index] || defaultReferenceBlueprint()[index];
}

function referenceBlueprintText(typeId = "") {
  const slot = referenceBlueprintSlot(typeId);
  return compactPromptItems([
    `Reference blueprint slot ${slot.slotNumber}: ${slot.role}`,
    `Reference-derived composition: ${slot.composition}`,
    `Reference-derived proof method: ${slot.proof}`,
    `Reference text density: ${slot.text}`,
  ], "", 4);
}

function referenceLinkInsightText(typeId = "") {
  const source = sourcePayload.competitor || "";
  if (!source) return "";
  const blueprint = referenceBlueprintSlot(typeId);
  const layout = referenceLayoutCues(source);
  const proof = referenceProofCues(source);
  const typeFocus = {
    "1": "apply reference hero framing only",
    "2": "apply reference structure/callout rhythm only",
    "3": "apply reference detail-proof rhythm only",
    "4": "apply reference feature-proof rhythm only",
    "5": "apply reference lifestyle/storage scene role only",
    "6": "apply reference human-use or environment framing only",
  }[typeId] || "apply reference image order and composition rhythm only";
  return compactPromptItems([
    `Current uploaded reference: ${referenceSourceLabel(source)} (${textFingerprint(source)})`,
    referenceBlueprintText(typeId),
    `Reference layout cues: ${layout.length ? layout.join(", ") : "use visible image order, shot distance, and composition rhythm from current uploaded reference"}`,
    proof.length ? `Reference proof-slot cues: ${proof.join(", ")}; rewrite using only current product verified benefits` : "",
    `Blueprint role for this image: ${blueprint.role}; ${typeFocus}`,
  ], "", 4);
}

function specModulePrompt(typeId, facts) {
  const dimensionLine = [
    facts.dimension1 && `Dimension 1: ${facts.dimension1}`,
    facts.dimension2 && `Dimension 2: ${facts.dimension2}`,
    facts.dimension3 && `Dimension 3: ${facts.dimension3}`,
    facts.weightOrCapacity && `Weight / Capacity: ${facts.weightOrCapacity}`,
  ].filter(Boolean).join(" / ");
  const summarySideLabels = uniquePromptItems([
    facts.material,
    facts.structure,
    facts.feature1,
  ]).slice(0, 3);
  const summaryBottomLabels = uniquePromptItems([
    facts.feature2,
    facts.color,
    visibleDetailParameter(facts.detailParameter),
  ], [
    ...summarySideLabels,
    facts.titleSpec,
    facts.selectedSpec,
    facts.pack,
    facts.cupRange,
  ]).slice(0, 4);
  const option = facts.titleSpec || facts.selectedSpec;
  const optionCount = facts.pack ? `Product count/set: ${facts.pack}.` : "";
  const dimensions = dimensionLine ? `Verified dimensions: ${dimensionLine}.` : "No unverified dimensions.";
  const featureLabels = compactPromptItems(sellingPointCandidates(facts, 4), "verified benefits", 4);
  const sceneUse = useSceneText(facts, neutralProductSceneFallback(), 4);
  const sellingPointGroup1 = sellingPointGroups(facts, 0);

  const modules = {
    "1": {
      basic: basicImageRequirements("spec", "1"),
      details: productDetailText(facts, [option, facts.color], 6),
      style: overallStyleText(facts, "1", `Premium product-first hero scene; ${sceneMainProductScaleRule()} product is the primary visual subject; no added title, no added labels, no added overlay text; keep authentic product markings.`),
    },
    "2": {
      basic: basicImageRequirements("spec", "2"),
      details: productDetailText(facts, [sceneUse], 6),
      style: overallStyleText(facts, "2", `Realistic lifestyle use scene: ${sceneUse}; ${sceneMainProductScaleRule()} Product stays clear and accurate.`),
    },
    "3A": {
      basic: basicImageRequirements("spec", "3A"),
      details: productDetailText(facts, [sceneUse], 6),
      style: overallStyleText(facts, "3A", `3-4 clean panels showing different product-matched use scenes: ${sceneUse}.`),
    },
    "3B": {
      basic: basicImageRequirements("spec", "3B"),
      details: productDetailText(facts, [useSceneText(facts, "", 2)], 6),
      style: overallStyleText(facts, "3B", `Simple 3-4 step usage infographic for ${facts.productName}; number markers and added captions allowed; added captions must stay short.`),
    },
    "4": {
      basic: "Size/range infographic, 1:1 Amazon image, 4K, clean layout with concise verified text.",
      details: productDetailText(facts, [
        shortOptionText(facts) || option,
        optionCount,
        facts.cupRange ? `Range: ${facts.cupRange}` : "",
        dimensions,
      ], 8),
      style: overallStyleText(facts, "4", "Clean size reference layout; added title can be \"Size Reference\"; no unverified measurements; preserve authentic product markings.", { includeHumanRule: false }),
    },
    "5": {
      basic: basicImageRequirements("spec", "5"),
      details: productDetailText(facts, [
        facts.bundleComponents ? `Included bundle components: ${facts.bundleComponents}` : `Verified options: ${compactVariantText(facts)}`,
      ], 7),
      style: overallStyleText(
        facts,
        "5",
        facts.bundleComponents
          ? bundleComponentsShowcaseRule(facts)
          : "Product option comparison grid; show only verified options; small added option tags only; preserve authentic product markings.",
        { includeHumanRule: false }
      ),
    },
    "6": {
      basic: basicImageRequirements("spec", "6"),
      details: productDetailText(facts, [], 5),
      style: overallStyleText(facts, "6", sellingPointImageTemplateRule(sellingPointGroup1, facts, "Spec template Image 6")),
    },
    "7": {
      basic: basicImageRequirements("spec", "7"),
      details: productDetailText(facts, [`Macro focus: ${detailTextureText(facts, "material or structure")}`], 7),
      style: overallStyleText(facts, "7", "Macro close-up detail; sharp texture, clean edges, optional small magnifier inset.", { includeHumanRule: false }),
    },
    "8": {
      basic: basicImageRequirements("spec", "8"),
      details: productDetailText(facts, [`Summary points: ${compactPromptItems(sellingPointCandidates(facts, 5), featureLabels, 5)}`], 8),
      style: overallStyleText(facts, "8", "Summary layout with product centered and 3-4 visual proof insets/icons; labels are optional 3-5 word locators only; no dense added specification table; preserve authentic product markings."),
    },
  };
  const selected = modules[typeId] || modules["1"];

  return buildPromptSections({
    facts,
    templateId: "spec",
    typeId,
    basic: selected.basic,
    details: selected.details,
    style: selected.style,
    negative: negativePrompt(facts),
  });
}

function uniquePromptItems(items, exclusions = []) {
  const excluded = exclusions
    .filter(Boolean)
    .map((item) => comparablePromptItem(item));
  const seen = new Set();
  return items
    .filter(Boolean)
    .map((item) => String(item).trim())
    .filter((item) => {
      const lower = comparablePromptItem(item);
      if (!lower) return false;
      if (excluded.some((excludedItem) => excludedItem && (lower.includes(excludedItem) || excludedItem.includes(lower)))) return false;
      if (seen.has(lower)) return false;
      seen.add(lower);
      return true;
    });
}

function specTemplatePrompt(typeId, sku, data) {
  const facts = promptFacts(sku, data);
  return specModulePrompt(typeId, facts);
}

function sceneQualityRule() {
  return "Premium realistic scene lighting; product details crisp, scale readable, naturally integrated with the environment.";
}

function sceneTextureLine(facts) {
  const texture = visibleTextureDetails(facts);
  return `Texture: ${texture}; realistic surface detail, clean edges, natural shadows.`;
}

function sceneCategoryStyleRule(facts) {
  const sceneText = cleanFieldDisplayValue(facts?.scene || "");
  return sceneText
    ? `Verified source scene: ${sceneText}.`
    : `No verified use scene extracted; select scenes from the current product facts: ${recommendedUseSceneText(facts)}.`;
}

function sceneOverallStyleText(facts, typeId, extra = "") {
  return compactPromptItems([
    sceneCategoryStyleRule(facts),
    sceneQualityRule(),
    extra,
  ], "", 4);
}

function multiSceneLifestyleStyleText(facts, sceneList) {
  const hasVerifiedSceneList = hasVerifiedUseContext(facts);
  const globalSceneLines = [
    `Exactly 4 distinct complete real-life use scenes for ${sceneList}; each scene is one equal quadrant in a clean 2x2 grid.`,
    multiSceneEqualPanelRule(),
    scenePhraseInterpretationRule(),
    multiSceneProductScaleRule(),
    "Each panel should leave enough room for the current product's natural use posture, placement, handling, scale, and surrounding environment; do not crop so tight that the action becomes awkward.",
    "Every panel must be a complete human-scale lifestyle use scene, not a product display, detail, storage, or decor panel.",
    "No product-only close-up, top-down display shot, flat lay, studio shot, macro detail, option grid, storage display, basket display, or cropped cutout.",
    "Product clear and recognizable in every panel, and each panel still reads as a complete lifestyle scene.",
  ];
  return [
    sceneCategoryStyleRule(facts),
    "Four complete lifestyle scenes only; not an infographic or product grid.",
    ...globalSceneLines,
    hasVerifiedSceneList
      ? "Use only the Use Scene field currently shown on the left; do not add other scenes."
      : "Use only the current-product scene selection task above; do not add unrelated scenes or unverified claims.",
    "No added selling-point text, no scene title labels, no captions, no callout labels, no badges, no arrows, no feature icons, no product-spec explanation, no inset close-up panels.",
  ].filter(Boolean).join(" / ");
}

function sceneMultiSceneDetails(facts, sceneList) {
  if (!isFootwearCategory(facts)) return sceneContextProductDetailText(facts, [sceneList], 5);
  return sceneContextProductDetailText(facts, [
    footwearStructureReferenceText(facts),
    `Use scenes: ${sceneList}`,
    "Use state in every panel: worn on feet or naturally on stable ground inside the scene; no display-only, storage, basket, flat-lay, top-down, or isolated detail panels.",
  ], 8);
}

function sceneMultiSceneStyleText(facts, sceneList) {
  const base = multiSceneLifestyleStyleText(facts, sceneList);
  if (!isFootwearCategory(facts)) return base;
  return [
    base,
    "Every panel preserves source slipper/slide/sandal construction; scenes must not change upper band or strap layout/count/width, sole outline, toe area, or fold/hinge.",
    footwearUsePlausibilityRule(),
    footwearMultiSceneUseRule(),
    "If the user-provided scene list explicitly contains market, cafe/coffee, or beach, interpret it as a footwear-appropriate environment only: market uses normal floor/pavement beside stalls, never produce; cafe/coffee uses floor/pavement with coffee only as optional background or hand prop, never floating beside a cup; beach uses sand, towel, deck, or feet. Do not add these scenes when they are not provided.",
    isThongFlipFlopFacts(facts) ? `Across all panels, ${thongFlipFlopShortLockText()}` : "",
  ].filter(Boolean).join(" / ");
}

function userProvidedSceneList(facts) {
  return useSceneText(facts, recommendedUseSceneText(facts, "", 4), 4);
}

function sceneMultiAngleDetails(facts, physicalDetails) {
  if (!isFootwearCategory(facts)) return sceneProductDetailText(facts, [physicalDetails, visibleTextureDetails(facts)], 7);
  return sceneProductDetailText(facts, [
    footwearStructureReferenceText(facts),
    physicalDetails,
    visibleTextureDetails(facts),
  ], 10);
}

function sceneMultiAngleStyleText(facts) {
  const base = "Product-only multi-angle display: front, side, back/top, and one detail view on clean light studio background; no text/annotations.";
  if (!isFootwearCategory(facts)) return base;
  return [
    base,
    "All angles show the same exact product and reveal upper band or strap layout/count/width, toe area, sole outline/thickness, edge profile, and fold/hinge if present.",
    isThongFlipFlopFacts(facts) ? `For every angle, ${thongFlipFlopShortLockText()}` : "",
  ].filter(Boolean).join(" ");
}

function sceneExplanationDetails(facts, physicalDetails) {
  const infoText = [
    "Main title required: Product Information.",
    "Use 2-3 short English info labels for verified material, structure, texture, size/range, or visible detail only.",
    "Premium text hierarchy: large title plus 2-3 short 3-5 word labels, aligned rows, crisp typography, spacing, no dense paragraphs.",
  ];
  if (!isFootwearCategory(facts)) return sceneProductDetailText(facts, [...infoText, physicalDetails, visibleTextureDetails(facts)], 9);
  return sceneProductDetailText(facts, [
    ...infoText,
    footwearStructureReferenceText(facts),
    physicalDetails,
    visibleTextureDetails(facts),
    "Callouts may label only verified visible structure/material details without changing the product shape.",
  ], 10);
}

function sceneExplanationStyleText(facts) {
  const base = [
    "Premium product information infographic with large high-contrast title \"Product Information\" or \"Product Details\".",
    "Product centered; 2-3 verified 3-5 word callouts for material, structure, texture, size/range, or visible details.",
    "Polished typography, aligned label blocks, subtle dividers/icons, generous white space, soft shadows, restrained premium accents.",
    "No dense paragraphs, long claims, cluttered tables, or unsupported specs.",
    "No human model, hands, body parts, wearing model, lifestyle action, or use-scene composition.",
  ].join(" ");
  if (!isFootwearCategory(facts)) return base;
  return [
    base,
    "Callouts point to source-accurate structure, not a redesigned version.",
    isThongFlipFlopFacts(facts) ? thongFlipFlopShortLockText() : "",
  ].filter(Boolean).join(" ");
}

function productFirstOptionalHumanRule() {
  return "Product-first proof scene; any human presence stays secondary.";
}

function premiumStudioRenderRule() {
  return "Premium commercial studio rendering: refined softbox lighting, subtle gradient shadow on white, crisp edges, realistic material highlights, tasteful negative space, and polished Amazon hero-image finish.";
}

function premiumLifestyleHeroRule(sceneText) {
  return `Premium lifestyle hero photography: show the product actively being used in ${sceneText}; cinematic natural light, realistic depth of field, upscale props and environment, clear product silhouette, emotional but uncluttered composition, editorial-quality color grading.`;
}

function sceneHeroBasicRequirements(facts, heroVariant = "product") {
  const variantRule = heroVariant === "human"
    ? "person/model may demonstrate use, but the selected product remains the primary visual subject and must not become a small accessory"
    : "product itself is the primary hero subject, with matching scene support";
  if (!isFootwearCategory(facts)) {
    return compactPromptItems([
      "1:1 Amazon lifestyle hero image",
      "4K clarity",
      "sharp realistic detail",
      "no added overlay text",
      "preserve authentic non-Chinese product/packaging markings only",
      variantRule,
      sceneMainProductScaleRule(),
      hasVerifiedUseContext(facts)
        ? `verified source scene/background: ${useSceneText(facts, neutralProductSceneFallback(), 2)}`
        : `current-product scene/background selection: ${recommendedUseSceneText(facts)}`,
    ], "", 8);
  }
  return compactPromptItems([
    "1:1 Amazon lifestyle hero image",
    "4K clarity",
    "sharp realistic detail",
    "no added overlay text",
    variantRule,
    sceneMainProductScaleRule(),
    hasVerifiedUseContext(facts) ? "use only the verified source scene/use context" : `use current-product lifestyle scene selection: ${recommendedUseSceneText(facts)}`,
    "medium environmental framing; not shoe-only close-up",
    "product clear, with scene atmosphere/props filling frame",
    "preserve authentic non-Chinese product/packaging markings only",
  ], "", 10);
}

function footwearStructureReferenceText(facts) {
  const isThong = isThongFlipFlopFacts(facts);
  return compactPromptItems([
    "Footwear reference lock: copy source geometry before adding scene/model/foot; reference overrides generic footwear assumptions.",
    "Keep upper band or strap layout/count/width, toe area, sole outline/thickness, edge profile, and fold/hinge if present.",
    isThong && thongFlipFlopStructureLockText(),
    facts.structure && `Source structure field: ${facts.structure}`,
    facts.color && `Source color field: ${facts.color}`,
    facts.material && `Source material field: ${facts.material}`,
  ], "", 7);
}

function footwearStructureNegativeText(facts) {
  if (!isFootwearCategory(facts)) return "";
  return compactPromptItems([
    "No changed footwear construction, upper band or strap layout/count/width, toe area, sole outline/thickness, or fold/hinge",
    "no added heel/back/ankle strap or second parallel strap",
    isThongFlipFlopFacts(facts) && "no slide sandals, wide-band shower slides, two-strap sandals, sealed triangular vamp, closed/filled front, covered footbed, missing front slit/open hole, missing Y strap, missing central toe post, or closed heel",
    "no invented decoration, wrong material texture, wrong color, or extra brand logo",
  ], "", 9);
}

function sceneHeroProductDetails(facts, mainScene, heroVariant = "product") {
  const variantDetail = heroVariant === "human"
    ? "Main template B: show the selected product being used or worn by a natural person in the matched scene; product remains the main visual subject, while human action/posture only explains scale and use."
    : "Main template A: product itself is the dominant subject; use the matched scene as context, props, depth, and atmosphere around the product.";
  if (!isFootwearCategory(facts)) {
    return sceneProductDetailText(facts, [variantDetail, mainScene, visibleTextureDetails(facts)], 8);
  }
  return sceneProductDetailText(facts, [
    footwearStructureReferenceText(facts),
    variantDetail,
    `Hero lifestyle context: ${mainScene}`,
    hasVerifiedUseContext(facts)
      ? "Scene appeal uses only source-verified props/context; natural light, depth, negative space."
      : `Scene appeal uses recommended product-category context: ${recommendedUseSceneText(facts)}.`,
    visibleTextureDetails(facts),
  ], 10);
}

function sceneHeroStyleText(facts, mainScene, heroVariant = "product") {
  const productFirstRule = [
    `Main template A: product-first hero in ${mainScene}.`,
    sceneMainProductScaleRule(),
    "Product is the largest visual subject and the first thing noticed; scene, props, natural light, foreground/background, and negative space support the product.",
    "Show product clearly with premium lifestyle atmosphere; avoid turning it into a plain product-only close-up or isolated studio shot.",
  ].join(" ");
  const humanUseRule = [
    `Main template B: human-use hero in ${mainScene}.`,
    sceneMainProductScaleRule(),
    "A natural person may use, wear, hold, or interact with the product, but the product remains the hero subject.",
    "Use close or medium-close framing so the product is clearly inspectable; human posture, scene context, props, light, and environment explain use without overpowering the product.",
  ].join(" ");
  if (isFootwearCategory(facts)) {
    return sceneOverallStyleText(facts, "1", [
      heroVariant === "human"
        ? `Main template B: show the exact selected slippers/slides/sandals being worn or stepped with in ${mainScene}; crop close enough that the footwear is the hero subject, while foot/lower-leg use state only supports scale and use.`
        : `Main template A: place the exact selected slippers/slides/sandals as the dominant product hero in ${mainScene}; model feet/lower legs optional and secondary.`,
      hasVerifiedUseContext(facts)
        ? "Medium environmental framing with only source-verified story, props, and depth; not only shoes/feet."
        : `Medium environmental framing based on current-product scene selection: ${recommendedUseSceneText(facts)}; not only shoes/feet.`,
      footwearUsePlausibilityRule(),
      heroVariant === "human"
        ? "Footwear leads the image; person-use state stays secondary, and footwear structure must stay clear; leave environment, light, texture, and negative space."
        : "Product clear and desirable, at least 30% of frame; leave environment, light, texture, negative space.",
      isThongFlipFlopFacts(facts) ? thongFlipFlopShortLockText() : "Preserve true color, upper band/strap shape, sole thickness/outline, toe area, and fold/hinge if visible.",
      "If the scene angle would hide or distort key structure, adjust camera/placement instead of changing the slipper.",
    ].join(" "));
  }
  return sceneOverallStyleText(facts, "1", heroVariant === "human" ? humanUseRule : productFirstRule);
}

function featureSceneStoryRule(facts, sceneText, points) {
  return compactPromptItems([
    `Combine real use scene with visible product benefits in ${sceneText}.`,
    `Visual proof focus: ${sellingPointSceneGuide(points, facts)}.`,
    "Use 2-3 elegant mini inset close-ups, icons, arrows, or subtle 3-5 word callouts only where they explain the feature; keep the scene itself dominant and premium.",
    "Avoid flat poster layout; create depth, foreground/background layering, natural shadows, and a clear product-use story.",
  ], "", 4);
}

function parameterIllustrationRule() {
  return "Size-reference parameter infographic like a premium Amazon measurement chart: include a clear 2-4 word top title such as \"Size Reference\" or \"Product Details\"; the main product must dominate the center, with verified dimensions drawn directly on or beside the product using clear ruler arrows, dashed guide lines, and bold numeric labels. Use premium studio rendering with realistic material highlights, soft shadows, clean depth, polished typography, and subtle category-matched background props. Do not replace core measurements with floating feature cards. Optional small benefit icons may appear only after the core dimensions are clearly shown; each icon label must be 3-5 words max. Mini illustrations or close-up crops are secondary and must support the measured parameter, not replace the measurement diagram.";
}

function summaryPosterStyleRule() {
  return [
    `${productFirstOptionalHumanRule()} Polished feature summary poster in a premium Amazon lifestyle style.`,
    "Use the approved layout: left side is one large warm lifestyle hero photo occupying about 60-65% width; right side is a vertical column occupying about 35-40% width with 3-4 rounded rectangular product-detail or use-detail inset windows.",
    "Add an optional circular or softly rounded product cutout inset overlapping the lower-left area of the hero photo, showing one current selling unit clearly on a clean light background; do not duplicate the product, do not show two sets, and do not imply a 2-pack unless the pack count is explicitly verified.",
    "Top headline may be a large elegant 2-4 word seasonal/product mood phrase; feature labels sit on small warm rounded tabs inside or near each right-side inset, 1-3 English words max.",
    "Each right inset must show a real visual proof subject from the current product: use scene, decoration, material/texture, lightweight/comfort, or style match; keep product clear and source-accurate.",
    "Keep the poster airy and editorial, with soft sunlight, rounded windows, cream/white dividers, warm neutral label color, and no dense table, bullets, long captions, arrows, hard-sell badges, or text stacking.",
  ].join(" ");
}

function optionShowcaseRule() {
  return "Premium option showcase: add an English title such as \"Choose Your Color\" or \"Choose Your Style\"; use a refined comparison layout with one realistic product render per option, tasteful swatches, soft studio shadows, subtle background depth, consistent scale, elegant typography, and a clear current-option highlight.";
}

function bundleComponentsShowcaseRule(facts) {
  if (!facts.bundleComponents) return "";
  return "Bundle included-components showcase: add an English title such as \"What You Get\" or \"Complete Set\"; show every included component as a separate source-accurate physical item in one coordinated layout, with short component labels only. Do not present components as alternative options, do not merge them into one redesigned item, and do not add unverified accessories.";
}

function sceneSellingPointItems(facts, points, fallback) {
  const sellingPoints = limitedSellingPoints(points, 2);
  const sellingPointText = sellingPoints.join(" + ") || fallback;
  const support = compactSpecificPromptItems([
    facts.structure && !promptItemsOverlap(sellingPointText, facts.structure) ? facts.structure : "",
    facts.material && !promptItemsOverlap(sellingPointText, facts.material) ? facts.material : "",
    facts.color && !promptItemsOverlap(sellingPointText, facts.color) ? facts.color : "",
  ], "", 2);
  return [support].filter(Boolean);
}

function summaryInsetGuide(facts, points) {
  const guideItems = uniqueSellingPoints(points, 4).map((point) => {
    const key = sellingPointKey(point);
    if (key === "filtration") return "working-performance close-up";
    if (key === "material") return "material texture close-up";
    return `${point} source-verified detail close-up`;
  });
  return compactPromptItems([
    ...guideItems,
    facts.color && "reference color swatch or product color detail",
  ], "3-4 verified product detail close-ups", 4);
}

function sceneModulePrompt(typeId, facts) {
  const physicalDetails = compactSpecificPromptItems([
    facts.structure,
    facts.material,
    facts.color,
  ], "visible product structure, material texture, and true color", 3);
  const sceneList = userProvidedSceneList(facts);
  const mainScene = useSceneText(facts, neutralProductSceneFallback(), 3);
  const sellingPointSet = sellingPointCandidates(facts, 6);
  const sellingPointGroup1 = sellingPointGroups(facts, 0);
  const sellingPointGroup2 = sellingPointGroups(facts, 1);
  const summaryPoints = compactSpecificPromptItems([
    useSceneText(facts, "", 2),
    ...sellingPointSet,
  ], "main scene / multi-use / key selling points", 4);
  const summaryInsetText = summaryInsetGuide(facts, sellingPointSet);
  const modules = {
    "1A": {
      basic: sceneHeroBasicRequirements(facts, "product"),
      details: sceneHeroProductDetails(facts, mainScene, "product"),
      style: sceneHeroStyleText(facts, mainScene, "product"),
    },
    "1B": {
      basic: sceneHeroBasicRequirements(facts, "human"),
      details: sceneHeroProductDetails(facts, mainScene, "human"),
      style: sceneHeroStyleText(facts, mainScene, "human"),
    },
    "2": {
      basic: `1:1 Amazon listing image, 4K clarity, sharp realistic detail, equal 2x2 multi-panel complete-use-scene collage. ${multiSceneEqualPanelRule()} ${multiSceneProductScaleRule()}`,
      details: sceneMultiSceneDetails(facts, sceneList),
      style: sceneMultiSceneStyleText(facts, sceneList),
    },
    "3": {
      basic: "1:1 Amazon multi-angle product image, 4K clarity, sharp realistic detail, product-only layout, no added text, labels, callouts, badges, captions, or arrows.",
      details: sceneMultiAngleDetails(facts, physicalDetails),
      style: sceneMultiAngleStyleText(facts),
    },
    "4": {
      basic: "1:1 Amazon product explanation image, 4K clarity, sharp realistic detail, product-only layout, clean light studio background.",
      details: sceneExplanationDetails(facts, physicalDetails),
      style: sceneExplanationStyleText(facts),
    },
    "5": {
      basic: basicImageRequirements("scene", "5"),
      details: sceneProductDetailText(facts, sceneSellingPointItems(facts, sellingPointGroup1, "the primary verified benefit"), 7),
      style: sceneOverallStyleText(facts, "5", `${productFirstOptionalHumanRule()} ${sellingPointImageTemplateRule(sellingPointGroup1, facts, "Scene template Image 5")}`),
    },
    "6": {
      basic: basicImageRequirements("scene", "6"),
      details: sceneProductDetailText(facts, sceneSellingPointItems(facts, sellingPointGroup2, "the secondary verified benefit"), 6),
      style: sceneOverallStyleText(facts, "6", `${productFirstOptionalHumanRule()} ${sellingPointImageTemplateRule(sellingPointGroup2, facts, "Scene template Image 6")} Distinct from Image 5.`),
    },
    "7": {
      basic: basicImageRequirements("scene", "7"),
      details: sceneProductDetailText(facts, [
        `Summary points: ${summaryPoints}`,
        `Detail inset subjects: ${summaryInsetText}`,
      ], 8),
      style: sceneOverallStyleText(facts, "7", summaryPosterStyleRule()),
    },
  };
  const selected = modules[typeId] || modules["1A"];

  return buildPromptSections({
    facts,
    templateId: "scene",
    typeId,
    basic: selected.basic,
    details: selected.details,
    style: selected.style,
    negative: negativePrompt(facts),
  });
}

function sceneTemplatePrompt(typeId, sku, data) {
  const facts = promptFacts(sku, data);
  return sceneModulePrompt(typeId, facts);
}

function featureModulePrompt(typeId, facts) {
  const sceneUse = useSceneText(facts, neutralProductSceneFallback(), 4);
  const sceneList = userProvidedSceneList(facts);
  const mainScene = useSceneText(facts, neutralProductSceneFallback(), 3);
  const optionText = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  const dimensionLine = dimensionText(facts);
  const optionCount = facts.pack ? `Product count/set: ${facts.pack}.` : "";
  const dimensions = dimensionLine ? `Verified dimensions: ${dimensionLine}.` : "No unverified dimensions.";
  const productInfo = compactSpecificPromptItems([
    facts.productName && `Product: ${facts.productName}`,
    (optionText || facts.titleSpec || facts.selectedSpec) && `Current option: ${optionText || facts.titleSpec || facts.selectedSpec}`,
    optionCount,
    facts.cupRange && `Size / range: ${facts.cupRange}`,
    dimensions,
    specificPromptValue(facts.material, "") && `Material: ${facts.material}`,
    specificPromptValue(facts.structure, "") && `Structure: ${facts.structure}`,
  ], "", 8);
  const detailInfo = compactSpecificPromptItems([
    detailTextureText(facts, ""),
    visibleDetailParameter(facts.detailParameter),
    facts.color && `True color: ${facts.color}`,
  ], "verified visible product details", 4);
  const sellingPointGroup1 = sellingPointGroups(facts, 0);
  const sellingPointGroup2 = sellingPointGroups(facts, 1);
  const sellingPointSet = sellingPointCandidates(facts, 6);
  const summaryPoints = compactSpecificPromptItems([
    useSceneText(facts, "", 2),
    ...sellingPointSet,
    facts.material,
    facts.structure,
    facts.surfaceFinish,
  ], verifiedProductDetailFallback(), 6);
  const sceneSummaryPoints = compactSpecificPromptItems([
    useSceneText(facts, "", 2),
    ...sellingPointSet,
  ], verifiedProductDetailFallback(), 4);
  const summaryInsetText = summaryInsetGuide(facts, sellingPointSet);
  const modules = {
    "1": {
      basic: "1:1 Amazon listing image, 4K clarity, sharp realistic detail, pure white background, no added overlay text, product occupies about 85% of the frame.",
      details: sceneProductDetailText(facts, [visibleTextureDetails(facts)], 7),
      style: `Pure white Amazon main image: show only the product itself, centered, no hands, no people, no body parts, no props, no furniture, no room, no outdoor scene, no lifestyle background, no added title, no added labels. ${premiumStudioRenderRule()}`,
    },
    "2": {
      basic: `1:1 Amazon lifestyle hero image, 4K clarity, sharp realistic detail, premium real-use scene, no added overlay text, ${sceneMainProductScaleRule()} product clearly visible and actively used.`,
      details: sceneProductDetailText(facts, [mainScene, visibleTextureDetails(facts)], 7),
      style: sceneOverallStyleText(facts, "1", hasVerifiedUseContext(facts)
        ? `${premiumLifestyleHeroRule(mainScene)} ${sceneMainProductScaleRule()} Product must be in active use, not just placed as a prop; composition uses only source-verified context.`
        : `${premiumLifestyleHeroRule(mainScene)} ${sceneMainProductScaleRule()} Product must be in active use, not just placed as a prop; scene choices are recommended from product identity and category, without adding unsupported performance claims.`),
    },
    "3": {
      basic: `1:1 Amazon listing image, 4K clarity, sharp realistic detail, premium equal 2x2 multi-scene lifestyle collage. ${multiSceneEqualPanelRule()} ${multiSceneProductScaleRule()}`,
      details: sceneContextProductDetailText(facts, [
        `Use scenes: ${sceneList}`,
        `Scene-implied benefits only: ${compactSpecificPromptItems(sellingPointSet, verifiedProductDetailFallback(), 4)}`,
      ], 6),
      style: multiSceneLifestyleStyleText(facts, sceneList),
    },
    "4": {
      basic: "Size-reference product parameter infographic, 1:1 Amazon image, 4K, clear measurement-first layout with concise verified English text.",
      details: productDetailText(facts, [
        productInfo,
        dimensionLine && `Mandatory measurement labels on image: ${dimensionLine}`,
      ], 8),
      style: overallStyleText(facts, "4", `${parameterIllustrationRule()} For umbrella products, show the open umbrella as the main measured object and the folded umbrella as a smaller measured object, with Open Diameter, Open Height, Folded Size, and Weight visibly labeled. Show only extracted measurements and verified option facts; no dense table, no filler fields, no unverified measurements.`, { includeHumanRule: false }),
    },
    "5": {
      basic: basicImageRequirements("spec", "5"),
      details: compactSpecificPromptItems([
        `Product: ${facts.productName}`,
        referenceColorLockText(),
        `Current selected option: ${facts.productName || optionText || facts.selectedSpec}`,
        facts.bundleComponents ? `Included bundle components: ${facts.bundleComponents}` : `Verified options: ${compactVariantText(facts)}`,
        facts.pack && `Count / set label: ${facts.pack}`,
      ], "", 8),
      style: overallStyleText(
        facts,
        "5",
        facts.bundleComponents
          ? bundleComponentsShowcaseRule(facts)
          : `${optionShowcaseRule()} Show only verified options and short English option tags; do not create unavailable colors, sizes, counts, bundles, or raw purchase-spec fragments.`,
        { includeHumanRule: false }
      ),
    },
    "6": {
      basic: basicImageRequirements("feature", "6"),
      details: productDetailText(facts, [], 5),
      style: overallStyleText(facts, "6", `Core function demo. ${sellingPointImageTemplateRule(sellingPointGroup1, facts, "Feature template Image 6")} Product remains clear and accurate.`),
    },
    "7": {
      basic: basicImageRequirements("feature", "7"),
      details: productDetailText(facts, [
        `Detail fields: ${detailInfo}`,
      ], 8),
      style: overallStyleText(facts, "7", `Detail/material feature display with macro close-ups or structure proof. ${sellingPointImageTemplateRule(sellingPointGroup2, facts, "Feature template Image 7")} Distinct from Image 6; no unsupported claims.`, { includeHumanRule: false }),
    },
    "8": {
      basic: basicImageRequirements("scene", "7"),
      details: productDetailText(facts, [
        `Summary points: ${sceneSummaryPoints || summaryPoints}`,
        `Detail inset subjects: ${summaryInsetText}`,
      ], 8),
      style: sceneOverallStyleText(facts, "7", summaryPosterStyleRule()),
    },
  };
  const selected = modules[typeId] || modules["1"];
  return buildPromptSections({
    facts,
    templateId: "feature",
    typeId,
    basic: selected.basic,
    details: selected.details,
    style: selected.style,
    negative: negativePrompt(facts),
  });
}

function featureTemplatePrompt(typeId, sku, data) {
  const facts = promptFacts(sku, data);
  return featureModulePrompt(typeId, facts);
}

function plantTieUseSceneText(facts) {
  return compactSpecificPromptItems([
    facts.scene,
  ], "garden plant support, potted plants, climbing vines, trellis, greenhouse, nursery", 4);
}

function plantTieIdentityRule(facts) {
  return compactPromptItems([
    "Plant tie template: product must remain the exact selected plant tie / garden tie item from the source.",
    "Show plant tying, stem support, vine training, bundling, or garden organization only when compatible with verified product use.",
    "Do not turn the product into rope, tape dispenser, cable tie, ribbon, wire, hose, strap hardware, or unrelated gardening accessory.",
    facts.material && `Verified material: ${facts.material}`,
    facts.structure && `Verified structure: ${facts.structure}`,
    facts.color && `Verified color: ${facts.color}`,
  ], "", 6);
}

function plantTieDetailInfo(facts) {
  const dimensionLine = dimensionText(facts);
  const optionText = compactSkuOptionText(facts.skuOption || shortOptionText(facts), facts);
  return compactSpecificPromptItems([
    facts.productName && `Product: ${facts.productName}`,
    optionText && `Current option: ${optionText}`,
    facts.pack && `Count / set: ${facts.pack}`,
    facts.cupRange && `Size / range: ${facts.cupRange}`,
    dimensionLine && `Mandatory measurement labels on image: ${dimensionLine}`,
    facts.material && `Material: ${facts.material}`,
    facts.structure && `Structure: ${facts.structure}`,
    facts.surfaceFinish && `Technology: ${facts.surfaceFinish}`,
    visibleDetailParameter(facts.detailParameter) && `Detail: ${visibleDetailParameter(facts.detailParameter)}`,
  ], "", 8);
}

function plantTieMainSceneStyle(facts, sceneText) {
  return sceneOverallStyleText(facts, "1", [
    plantTieIdentityRule(facts),
    `Main scene: product-first realistic plant support scene in ${sceneText}.`,
    sceneMainProductScaleRule(),
    "Use healthy real plants, stems, vines, trellis, garden bed, greenhouse, or potted-plant context as appropriate.",
    "A person/model appears only if actual product use needs a human action; if present, hands or gardener action stays secondary and the plant tie remains the hero subject.",
    "No added overlay text; product use must look natural, clean, and Amazon-ready.",
  ].join(" "));
}

function plantTieWhiteBackgroundStyle(facts) {
  return [
    "Pure white Amazon main image: show only the current plant tie product itself, centered and source-accurate.",
    "No plant, stem, soil, pot, hand, person, tool, trellis, garden scene, props, added title, or added labels.",
    "Product occupies about 85% of the frame; preserve true color, material texture, packaging, and authentic non-Chinese markings only.",
    premiumStudioRenderRule(),
    plantTieIdentityRule(facts),
  ].join(" ");
}

function plantTieMultiSceneStyle(facts, sceneText) {
  return [
    multiSceneLifestyleStyleText(facts, sceneText),
    plantTieIdentityRule(facts),
    "Every panel must show the plant tie visibly supporting, training, bundling, or organizing real plants without damaging stems.",
    "Use plant-support scenes first; avoid unrelated household cable management unless explicitly verified.",
  ].join(" / ");
}

function plantTieModulePrompt(typeId, facts) {
  const sceneText = plantTieUseSceneText(facts);
  const sellingPointGroup = sellingPointGroups(facts, 0);
  const productInfo = plantTieDetailInfo(facts);
  const modules = {
    "1": {
      basic: `1:1 Amazon main scene image, 4K clarity, sharp realistic detail, no added overlay text, ${sceneMainProductScaleRule()} plant support use scene, person/model optional only when product use requires it.`,
      details: sceneProductDetailText(facts, [
        plantTieIdentityRule(facts),
        `Use scene: ${sceneText}`,
        visibleTextureDetails(facts),
      ], 8),
      style: plantTieMainSceneStyle(facts, sceneText),
    },
    "2": {
      basic: "1:1 Amazon white-background product image, 4K clarity, sharp realistic detail, pure white background, no added overlay text, product occupies about 85% of the frame.",
      details: sceneProductDetailText(facts, [
        plantTieIdentityRule(facts),
        visibleTextureDetails(facts),
      ], 7),
      style: plantTieWhiteBackgroundStyle(facts),
    },
    "3": {
      basic: `1:1 Amazon multi-scene usage image, 4K clarity, sharp realistic detail, exactly 4 complete plant-use scenes, equal clean 2x2/four-panel collage. ${multiSceneEqualPanelRule()} ${multiSceneProductScaleRule()}`,
      details: sceneContextProductDetailText(facts, [
        plantTieIdentityRule(facts),
        `Use scenes: ${sceneText}`,
        "Scene purpose: show different verified plant support, vine training, stem fixing, garden tying, or potted-plant organization uses.",
      ], 7),
      style: plantTieMultiSceneStyle(facts, sceneText),
    },
    "4": {
      basic: basicImageRequirements("plantTie", "4"),
      details: productDetailText(facts, [
        plantTieIdentityRule(facts),
      ], 7),
      style: sceneOverallStyleText(facts, "4", [
        plantTieIdentityRule(facts),
        sellingPointImageTemplateRule(sellingPointGroup, facts, "Plant tie template Image 4"),
        "Use plant-support visual proof first: show the tie holding stems, training vines, preventing droop, organizing growth, or proving verified material/structure benefits.",
      ].join(" ")),
    },
    "5": {
      basic: "1:1 Amazon product detail information image, 4K clarity, sharp realistic detail, verified dimensions/material/structure/specification details only.",
      details: productDetailText(facts, [
        plantTieIdentityRule(facts),
        productInfo,
      ], 9),
      style: overallStyleText(facts, "5", [
        parameterIllustrationRule(),
        sceneExplanationStyleText(facts),
        "Product detail image: reuse existing product detail / product information rules; focus on verified size, material, structure, count/set, texture, and specification information.",
        "Use 2-3 concise English information labels plus visible ruler arrows or detail callouts only when verified; no dense table or invented specs.",
      ].join(" "), { includeHumanRule: false }),
    },
  };
  const selected = modules[typeId] || modules["1"];

  return buildPromptSections({
    facts,
    templateId: "plantTie",
    typeId,
    basic: selected.basic,
    details: selected.details,
    style: selected.style,
    negative: negativePrompt(facts),
  });
}

function plantTieTemplatePrompt(typeId, sku, data) {
  const facts = promptFacts(sku, data);
  return plantTieModulePrompt(typeId, facts);
}

function referenceLinkGlobalRule(facts, typeId = "") {
  return compactPromptItems([
    "Current product identity is the top priority; reference layout must adapt to the current product, never the reverse.",
    "Reference-link template: borrow only the image order, layout role, shot distance, composition rhythm, and visual proof method from the uploaded reference.",
    referenceLinkInsightText(typeId),
    "Current product fields always override the reference product: product type, color, material, structure, dimensions, scene, and verified benefits.",
    "If the reference product shape conflicts with the current product, keep the current product structure and adapt only the layout.",
    "Do not copy the reference brand, exact text, typography, people, image assets, product markings, or unsupported claims.",
    isFootwearCategory(facts) ? footwearStructureReferenceText(facts) : productIdentityBasicRule(facts),
  ], "", 7);
}

function referenceLinkModulePrompt(typeId, facts) {
  const blueprint = referenceBlueprintSlot(typeId);
  const blueprintRoute = referenceBlueprintText(typeId);
  const mainProduct = compactSpecificPromptItems([
    facts.productName,
    facts.color,
    facts.material,
    facts.structure,
  ], "current verified product appearance", 5);
  const structureText = compactSpecificPromptItems([
    facts.structure,
    facts.detailParameter,
    facts.material,
  ], "verified visible product structure", 4);
  const sceneUse = useSceneText(facts, neutralProductSceneFallback(), 4);
  const materialDetail = compactSpecificPromptItems([
    facts.material,
    facts.surfaceFinish,
    facts.detailParameter,
    facts.structure,
  ], "verified material or structure detail", 4);
  const featurePoint = compactSpecificPromptItems([
    ...sellingPointCandidates(facts, 4),
  ], verifiedProductDetailFallback(), 4);
  const referenceInsight = referenceLinkInsightText(typeId);
  const referenceRule = referenceLinkGlobalRule(facts, typeId);
  const blueprintBasic = `1:1 Amazon reference-blueprint image ${typeId}, 4K clarity, sharp realistic detail, route: ${blueprint.role}.`;
  const blueprintMainScale = /hero|multi-angle|product-only/i.test(blueprint.key)
    ? "Product-only reference hero scale: current product remains the main visual subject and should occupy most of the frame."
    : sceneMainProductScaleRule();
  const blueprintPanelScale = /collage|grid|panel/i.test(`${blueprint.key} ${blueprint.composition}`)
    ? multiSceneProductScaleRule()
    : "";
  const modules = {
    "1": {
      basic: blueprintBasic,
      details: productDetailText(facts, [
        blueprintRoute,
        `Product form: ${mainProduct}`,
        referenceInsight,
        "Execute this exact reference slot with the current product; do not add extra views, scenes, claims, or callouts unless the current reference slot calls for them.",
      ], 7),
      style: overallStyleText(facts, "1", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. ${blueprintMainScale} Current product shape, color, material, and structure must stay exact.`, { includeHumanRule: !/hero|multi-angle|product-only/i.test(blueprint.key) }),
    },
    "2": {
      basic: blueprintBasic,
      details: productDetailText(facts, [
        blueprintRoute,
        `Structure focus: ${structureText}`,
        referenceInsight,
        "If this slot is not a structure slot, use the structure facts only as product-accuracy constraints, not as the main composition.",
        "Use the reference slot layout; labels/arrows/insets must explain only verified current-product facts.",
        "Do not invent folding, detachable parts, straps, openings, holes, hinges, or steps that are not in current product data.",
      ], 7),
      style: overallStyleText(facts, "2", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. Keep text density as: ${blueprint.text}. Product geometry stays unchanged.`),
    },
    "3": {
      basic: blueprintBasic,
      details: productDetailText(facts, [
        blueprintRoute,
        `Detail proof: ${materialDetail}`,
        referenceInsight,
        "If this slot is not a detail slot, use material/detail facts as supporting constraints while following the reference blueprint role.",
        "Macro close-ups or insets must come from the current product's verified material, surface, edge, texture, or construction.",
        "If a referenced detail is not verified for the current product, replace it with a verified current-product detail.",
      ], 7),
      style: overallStyleText(facts, "3", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. Visual proof first; no certification badges or unverified claims.`),
    },
    "4": {
      basic: blueprintBasic,
      details: productDetailText(facts, [
        blueprintRoute,
        referenceInsight,
        "Use the reference blueprint proof method; do not force bending, stretching, waterproofing, non-slip, portability, or other claims unless verified.",
      ], 7),
      style: overallStyleText(facts, "4", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. ${sellingPointImageTemplateRule(sellingPointGroups(facts, 0), facts, "Reference template Image 4")} Blueprint proof method: ${blueprint.proof}.`),
    },
    "5": {
      basic: blueprintBasic,
      details: sceneProductDetailText(facts, [
        blueprintRoute,
        `Scene proof: ${sceneUse}`,
        `Benefit focus: ${featurePoint}`,
        referenceInsight,
        "Use the reference blueprint scene role, crop, prop density, and lighting mood; adapt environment to current product category and verified use.",
      ], 7),
      style: sceneOverallStyleText(facts, "5", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. ${sceneMainProductScaleRule()} ${blueprintPanelScale} Product stays prominent and source-accurate; no forced travel/folding/packing scene unless verified.`),
    },
    "6": {
      basic: blueprintBasic,
      details: sceneProductDetailText(facts, [
        blueprintRoute,
        `Use-scene proof: ${sceneUse}`,
        `Lifestyle benefit: ${featurePoint}`,
        referenceInsight,
        "Use the reference blueprint closing role; human/model use is optional and must not hide, shrink, or alter the current product structure.",
      ], 7),
      style: sceneOverallStyleText(facts, "6", `${referenceRule} Execute slot composition exactly: ${blueprint.composition}. ${sceneMainProductScaleRule()} ${blueprintPanelScale} Do not copy the reference person, floor, exact pose, text style, or product shape.`),
    },
  };
  const selected = modules[typeId] || modules["1"];

  return buildPromptSections({
    facts,
    templateId: "reference",
    typeId,
    basic: selected.basic,
    details: selected.details,
    style: selected.style,
    negative: negativePrompt(facts),
  });
}

function referenceLinkTemplatePrompt(typeId, sku, data) {
  const facts = promptFacts(sku, data);
  return referenceLinkModulePrompt(typeId, facts);
}

function promptFor(templateId, typeId, sku, data) {
  const facts = promptFacts(sku, data);

  if (templateId === "spec") {
    return specTemplatePrompt(typeId, sku, data);
  }

  if (templateId === "scene") {
    return sceneTemplatePrompt(typeId, sku, data);
  }

  if (templateId === "reference") {
    return referenceLinkTemplatePrompt(typeId, sku, data);
  }

  if (templateId === "plantTie") {
    return plantTieTemplatePrompt(typeId, sku, data);
  }

  return featureTemplatePrompt(typeId, sku, data);
}

function sellingPointGroupForImageTitle(templateId, typeId, facts) {
  if (templateId === "spec" && typeId === "6") return sellingPointGroups(facts, 0);
  if (templateId === "scene" && typeId === "5") return sellingPointGroups(facts, 0);
  if (templateId === "scene" && typeId === "6") return sellingPointGroups(facts, 1);
  if (templateId === "feature" && typeId === "6") return sellingPointGroups(facts, 0);
  if (templateId === "feature" && typeId === "7") return sellingPointGroups(facts, 1);
  if (templateId === "plantTie" && typeId === "4") return sellingPointGroups(facts, 0);
  return [];
}

function promptImageDisplayTitle(template, type, facts) {
  const points = sellingPointGroupForImageTitle(template.id, type.id, facts);
  if (!points.length) return "";
  const prefix = String(type.name || "").match(/^\s*([0-9]+[A-Z]?\.\s*)/)?.[1] || "";
  const label = sellingPointDisplayText(points);
  return `${prefix}${label}`;
}

function renderFacts() {
  const sku = selectedSku();
  const template = selectedTemplate();
  byId("currentTitle").textContent = hasExtractedProducts() ? `${skuDisplayLabel(sku)} · ${template.name}` : `待解析 · ${template.name}`;
  byId("badges").innerHTML = [
    "只写已确认规格",
    "不借鉴参数",
    "模板决定图组",
    "一次性输出",
  ].map((label) => `<span class="badge">${label}</span>`).join("");
  renderProductPromptGrid();
}

function renderProductPromptGrid() {
  const grid = byId("productPromptGrid");
  if (!grid) return;

  const sku = selectedSku();
  const template = selectedTemplate();
  if (!hasExtractedProducts()) {
    promptStore = [];
    grid.innerHTML = `<p class="empty-state">请选择采购单、1688 HTML 和参考链接资料后点击解析。</p>`;
    return;
  }
  const data = currentPromptData(sku);
  const facts = promptFacts(sku, data);
  const displayLabel = skuDisplayLabel(sku, data);
  promptStore = template.imageTypes.map((type) => {
    const key = promptCardKey(sku, template, type);
    const language = promptLanguageByCard[key] || "en";
    const promptEn = bracketPromptVariables(promptFor(template.id, type.id, sku, data), facts, type.id);
    const prompt = promptTextForLanguage(promptEn, language);
    return { id: type.id, key, language, promptEn, prompt };
  });

  grid.innerHTML = template.imageTypes.map((type, index) => {
    const item = promptStore[index];
    const prompt = item.prompt;
    return `
      <article class="prompt-card">
        <div class="prompt-card-head">
          <div>
            <span>${escapeHtml(displayLabel)}</span>
            <h3>${escapeHtml(type.name)}</h3>
          </div>
          <div class="prompt-actions">
            <button type="button" class="copy-prompt" data-prompt-index="${index}">复制</button>
            <button type="button" class="language-toggle" data-prompt-index="${index}">${item.language === "zh" ? "切英文" : "切中文"}</button>
          </div>
        </div>
        <pre class="prompt-preview">${highlightPromptVariables(prompt, facts, type.id)}</pre>
      </article>
    `;
  }).join("");

  grid.querySelectorAll(".copy-prompt").forEach((button) => {
    button.addEventListener("click", () => {
      copyText(promptStore[Number(button.dataset.promptIndex)]?.prompt || "", "已复制该图提示词。", button);
    });
  });

  grid.querySelectorAll(".language-toggle").forEach((button) => {
    button.addEventListener("click", () => {
      const index = Number(button.dataset.promptIndex);
      const item = promptStore[index];
      const type = template.imageTypes[index];
      if (!item || !type) return;
      const nextLanguage = item.language === "zh" ? "en" : "zh";
      promptLanguageByCard[item.key] = nextLanguage;
      item.language = nextLanguage;
      item.prompt = promptTextForLanguage(item.promptEn, nextLanguage);
      const card = button.closest(".prompt-card");
      const preview = card?.querySelector(".prompt-preview");
      if (preview) preview.innerHTML = highlightPromptVariables(item.prompt, facts, type.id);
      button.textContent = nextLanguage === "zh" ? "切英文" : "切中文";
      byId("copyStatus").textContent = `已切换为${nextLanguage === "zh" ? "中文" : "英文"}提示词。`;
    });
  });
}

function renderPrompt() {
  renderProductPromptGrid();
}

function renderAll() {
  hydrateEmptyFieldInputsFromValues();
  renderProductParameters();
  renderSourceSummary();
  renderFacts();
  fieldSnapshot = currentFieldSignature();
}

function allPromptsForSku() {
  if (!hasExtractedProducts()) return "";
  const sku = selectedSku();
  const template = selectedTemplate();
  const data = currentPromptData(sku);
  const facts = promptFacts(sku, data);
  return template.imageTypes.map((type) => {
    const title = promptImageDisplayTitle(template, type, facts) || type.promptName || type.name;
    const key = promptCardKey(sku, template, type);
    const promptEn = bracketPromptVariables(promptFor(template.id, type.id, sku, data), facts, type.id);
    const prompt = promptTextForLanguage(promptEn, promptLanguageByCard[key] || "en");
    return `## ${title}\n\n${prompt}`;
  }).join("\n\n---\n\n");
}

function clearExtractedSourceState() {
  sourcePayload = {
    purchase: "",
    amazonTemplate: "",
    supplier: "",
    competitor: "",
  };
  extractedProducts = [];
  fieldOverrides = {};
  fieldOverridesBySku = {};
  appliedSellingPointOverridesBySku = {};
  promptLanguageByCard = {};
  sellingPointDraftDirty = false;
  promptStore = [];
  renderProductSelect();
  renderFields(true);
  renderAll();
}

function showCopyFeedback(button, state, label) {
  if (!button) return;

  const originalText = button.dataset.defaultText || button.textContent;
  button.dataset.defaultText = originalText;
  button.classList.remove("copy-success", "copy-failed");
  button.classList.add(state === "success" ? "copy-success" : "copy-failed");
  button.textContent = label || (state === "success" ? "Copied" : "Failed");
  button.setAttribute("aria-live", "polite");

  const card = button.closest(".prompt-card");
  if (card && state === "success") {
    card.classList.add("just-copied");
  }

  window.setTimeout(() => {
    button.classList.remove("copy-success", "copy-failed");
    button.textContent = originalText;
    card?.classList.remove("just-copied");
  }, 2400);
}

async function copyText(text, message, button) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      throw new Error("Clipboard API unavailable");
    }
    byId("copyStatus").textContent = message;
    showCopyFeedback(button, "success");
  } catch {
    const fallbackOk = fallbackCopyText(text);
    if (fallbackOk) {
      byId("copyStatus").textContent = message;
      showCopyFeedback(button, "success");
    } else {
      selectPromptTextForManualCopy(button);
      byId("copyStatus").textContent = button?.closest(".prompt-card")
        ? "复制失败，已选中该图提示词，可按 Cmd+C 手动复制。"
        : "复制失败，请手动选中文本复制。";
      showCopyFeedback(button, "failed", "Selected");
    }
  }
}

function selectPromptTextForManualCopy(button) {
  const preview = button?.closest(".prompt-card")?.querySelector(".prompt-preview");
  if (!preview) return;
  const range = document.createRange();
  range.selectNodeContents(preview);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
}

function fallbackCopyText(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.top = "-9999px";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  textarea.setSelectionRange(0, textarea.value.length);
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch {
    ok = false;
  }
  textarea.remove();
  return ok;
}

function init() {
  window.renderAll = renderAll;
  window.promptForSku = promptFor;
  fillSelects();
  renderFields(true);
  renderAll();
  startFieldWatcher();

  byId("skuSelect").addEventListener("change", () => {
    renderFields(true);
    renderAll();
  });
  byId("templateSelect").addEventListener("change", renderAll);
  byId("extractSources").addEventListener("click", () => {
    extractSources().catch((error) => {
      extractedProducts = [];
      appliedSellingPointOverridesBySku = {};
      sellingPointDraftDirty = false;
      renderProductSelect();
      renderFields(true);
      renderAll();
      byId("extractStatus").textContent = `解析失败：${error.message || "请检查文件格式"}`;
    });
  });
  ["purchaseFile", "purchaseImageFile", "amazonTemplateFile", "amazonSkuFilter", "supplierFile", "competitorFile"].forEach((id) => {
    const input = byId(id);
    const updateStatus = () => {
      clearExtractedSourceState();
      byId("extractStatus").textContent = "文件或筛选条件已更新，点击解析资料并提取产品信息。";
    };
    input.addEventListener("change", updateStatus);
    if (input.type === "text") input.addEventListener("input", updateStatus);
  });
  byId("resetFields").addEventListener("click", () => {
    const skuId = selectedSku()?.id || "";
    if (skuId) delete appliedSellingPointOverridesBySku[skuId];
    sellingPointDraftDirty = false;
    renderFields(true);
    renderAll();
  });
  byId("copyCurrent").addEventListener("click", () => {
    const text = allPromptsForSku();
    if (!text) {
      byId("copyStatus").textContent = "请先解析资料并选择产品。";
      return;
    }
    copyText(text, "已复制当前产品全部图组。", byId("copyCurrent"));
  });
}

init();
